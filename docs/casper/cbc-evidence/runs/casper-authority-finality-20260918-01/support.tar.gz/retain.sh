#!/usr/bin/env bash
set -euo pipefail
BASE=d871a2df83a69dbb0ddaafffef609612cf8388ea
RUN=docs/casper/cbc-evidence/runs/casper-authority-finality-20260918-01
LOCAL=target/task-017-5
STAGE=target/task-017-5-retention
[[ "$(git rev-parse HEAD)" == "$BASE" ]]
[[ ! -e "$RUN" && ! -e "$STAGE" ]]
[[ "$(<"$LOCAL/final-source/exit.txt")" == 0 ]]
[[ "$(<"$LOCAL/linux-source-build.exit")" == 0 ]]
[[ "$(<"$LOCAL/claim-001.exit")" == 0 && "$(<"$LOCAL/claim-002.exit")" == 4 ]]
shasum -a 256 --check "$LOCAL/final-source/source-after.sha256" >"$LOCAL/final-source-check.txt"
actual_binary=$(shasum -a 256 target/debug/casper-authority-finality | awk '{print $1}')
[[ "$actual_binary" == "$(jq -r .executable_sha256 "$LOCAL/final-source/identity.json")" ]]
mkdir -p "$RUN" "$STAGE/source" "$STAGE/evidence" "$STAGE/support"
awk '{print $2}' "$LOCAL/final-source/source-after.sha256" >"$STAGE/sources.txt"
printf '%s\n' Cargo.toml docs/work-logs/task-017-5-authority-finality.md >>"$STAGE/sources.txt"
sort -u "$STAGE/sources.txt" -o "$STAGE/sources.txt"
while IFS= read -r path; do mkdir -p "$STAGE/source/$(dirname "$path")"; cp "$path" "$STAGE/source/$path"; done <"$STAGE/sources.txt"
cp -R "$LOCAL/." "$STAGE/evidence/"
cp target/casper-task-017-4-finish/redact.rs "$STAGE/support/redact.rs"
cp "$0" "$STAGE/support/retain.sh"
git diff -- docs/ToDos.md docs/claims/casper-soak-authority-finality.md >"$STAGE/support/tracked.patch.txt"
target/casper-task-017-4-finish/redact-bin "$STAGE/evidence" "$PWD" "$HOME" >"$RUN/redactions.tsv"
if grep -R -F "$HOME" "$STAGE/source" "$STAGE/evidence" "$STAGE/support" >/dev/null; then printf 'A private home path remains.\n' >&2; exit 2; fi
(
    cd "$STAGE/source"
    find . -type f -print0 | LC_ALL=C sort -z | xargs -0 shasum -a 256
) >"$RUN/source-files.sha256"
(
    cd "$STAGE/evidence"
    find . -type f -print0 | LC_ALL=C sort -z | xargs -0 shasum -a 256
) >"$RUN/evidence-files.sha256"
(
    cd "$STAGE/evidence"
    find . -type l | while IFS= read -r link; do printf '%s\t%s\n' "$link" "$(readlink "$link")"; done
) >"$RUN/symlinks.tsv"
for part in source evidence support; do
    gtar --owner=0 --group=0 --numeric-owner --no-xattrs --no-acls -czf "$RUN/$part.tar.gz" -C "$STAGE/$part" .
done
cp "$STAGE/evidence/final-source/models/report.json" "$RUN/models.json"
cp "$STAGE/evidence/final-source/models/profile-model.json" "$RUN/model-layout.json"
cp "$STAGE/evidence/claim-001.json" "$RUN/claim-001.json"
cp "$STAGE/evidence/claim-002.json" "$RUN/claim-002.json"
cp "$STAGE/evidence/lsp.json" "$RUN/lsp.json"
find "$STAGE/evidence/final-source/fixtures" -name 'invocation-*.json' -print0 | xargs -0 jq -s '.' | jq 'flatten | {scope:"fixture-inventory-only",invocations:length,expected_exits:all(.actual_exit == .expected_exit),outcomes:(group_by(.expected_verdict)|map({verdict:.[0].expected_verdict,count:length}))}' >"$RUN/fixture-inventory.json"
jq -e '.invocations == 65 and .expected_exits' "$RUN/fixture-inventory.json" >/dev/null
sha() { shasum -a 256 "$1" | awk '{print $1}'; }
source_map=$(while IFS= read -r path; do printf '%s\t%s\n' "$path" "$(sha "$path")"; done <"$STAGE/sources.txt" | jq -Rn '[inputs|split("\t")|{key:.[0],value:.[1]}]|from_entries')
claim_sha=$(sha docs/claims/casper-soak-authority-finality.md)
verified_at=$(date -u +%Y-%m-%dT%H:%M:%SZ)
jq -n --arg base "$BASE" --arg at "$verified_at" --argjson source "$source_map" --arg spec "$claim_sha" --arg native "$actual_binary" --arg linux "$(sha target/aarch64-unknown-linux-musl/debug/casper-authority-finality)" --arg source_archive "$(sha "$RUN/source.tar.gz")" --arg evidence_archive "$(sha "$RUN/evidence.tar.gz")" --arg support_archive "$(sha "$RUN/support.tar.gz")" '{schema_version:1,run_id:"casper-authority-finality-20260918-01",claim_ids:["CLAIM-CASPER-SOAK-002"],status:"verification-passed-claim-pending",phase:"pre_pr216_merge",implementation_base:$base,commit_is_base:true,worktree_dirty:true,verified_at:$at,scope:"controlled-transcript-profile-and-bounded-refutation",node_execution:false,proof_execution:false,unbounded_proof:false,source_digests:$source,claim_digests:{"docs/claims/casper-soak-authority-finality.md":$spec},executables:{native_sha256:$native,linux_musl_sha256:$linux},archives:{"source.tar.gz":$source_archive,"evidence.tar.gz":$evidence_archive,"support.tar.gz":$support_archive},tiers:{refutation:"bounded-safety-pass",construction:"not-applicable",binding:"pending-review",soak:"pending"},checks:{rust_tests:8,fixture_cases:58,profile_invocations:65,threshold_cases:2000,clean_distinct_states:1681,clean_generated_states:3281,negative_controls:3,shared_host_regressions:11,linux_cross_build:"passed",linux_execution:"not-run-docker-unavailable",native_test_optimization:0,linux_test_optimization:1,java:"26.0.2.1",tlc:"2.19",tlc_jar_sha256:"936a262061c914694dfd669a543be24573c45d5aa0ff20a8b96b23d01e050e88",rustfmt:"passed",bash_syntax:"passed",ste_check:"passed",strict_claim_001_exit:0,strict_claim_002_exit:4},final_evidence:"evidence.tar.gz:final-source",failure_history:["missing-ft-red: exit 101","receipt-identity-red: exit 101","replay-receipt-red: exit 101","default Java: incompatible architecture","Docker socket unavailable","models-01/models-02/models-03: exit 255 for each TLC configuration","final-checks: dependency compilation failed with an LLVM target-feature error"],limits:["Human binding acceptance remains pending.","The new workflow mandatory tag remains unratified and unapplied.","Historical RED logs do not include every intermediate source snapshot.","One initial language-server check remained inconclusive.","Live adapters and post-merge interfaces remain blocked.","A synthetic passed scenario is not node evidence or a passing soak."],waiver:null}' >"$RUN/report.json"
report_sha=$(sha "$RUN/report.json")
awk '/^artifacts:/{on=1;next} on && /^  - /{sub(/^  - /,"");print;next} on{exit}' docs/claims/casper-soak-authority-finality.md >"$STAGE/claim-artifacts.txt"
while IFS= read -r artifact; do
    slug=$(printf '%s' "${artifact#.}" | tr '/._' '---')
    ledger="docs/casper/cbc-evidence/$slug.md"
    [[ ! -e "$ledger" && ! -e "docs/cbc-evidence/$slug.md" ]]
    metadata=$(jq -n --arg path "$artifact" --arg id "$slug" --arg base "$BASE" --arg digest "$(sha "$artifact")" --arg spec "$claim_sha" --arg ref "$RUN/report.json" --arg evidence "$report_sha" --arg at "$verified_at" '{artifact:{path:$path,id:$id,commit:$base,commit_is_base:true,sha256:$digest},claim:"docs/claims/casper-soak-authority-finality.md",claim_ids:["CLAIM-CASPER-SOAK-002"],claim_digests:{"docs/claims/casper-soak-authority-finality.md":$spec},adapter:"embedded",status:"pending",scope:"bounded-authority-finality-profile",evidence:{kind:"bounded-refutation-and-executable-fixtures",ref:$ref,sha256:$evidence},tiers:{refutation:"bounded-safety-pass",construction:"not-applicable",binding:"pending-review"},phase_status:{pre_pr216_merge:"pending",post_pr216_merge:"blocked"},soak:"pending",waiver:null,verified_at:$at}')
    printf '# CbC Evidence: %s\n\nThe bounded model and controlled fixtures pass. Human binding acceptance remains pending. This record does not discharge the claim.\n\n```json\n%s\n```\n' "$artifact" "$metadata" >"$ledger"
    ln -s "../casper/cbc-evidence/$slug.md" "docs/cbc-evidence/$slug.md"
done <"$STAGE/claim-artifacts.txt"
(cd "$RUN"; find . -maxdepth 1 -type f ! -name artifacts.sha256 -print0 | LC_ALL=C sort -z | xargs -0 shasum -a 256 >artifacts.sha256)
