#!/usr/bin/env bash
set -euo pipefail
LOCAL=target/casper-task-017-4-closure-WeRvXh
PACKAGE=docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01
SPEC=docs/claims/casper-soak-harness.md
REV=946743a7740e5dd3c0816263c3347e501f2d50d7
[[ "$(git rev-parse HEAD)" == "$REV" ]]
mkdir -p "$PACKAGE"
hash_file() { shasum -a 256 "$1" | awk '{print $1}'; }
slug() { printf '%s' "${1#.}" | tr '/._' '---'; }
if [[ ! -f "$PACKAGE/prior-ledgers.tar.gz" ]]; then
 : > "$LOCAL/prior-ledgers.txt"
 while IFS= read -r artifact; do
  ledger="docs/casper/cbc-evidence/$(slug "$artifact").md"
  [[ ! -L "$ledger" ]]
  if [[ -f "$ledger" ]]; then
   awk '/^```json$/{on=1;next} /^```$/{if(on)exit} on' "$ledger" | jq -e '.claim_ids==["CLAIM-CASPER-SOAK-001"] and .status=="pending" and .waiver==null' >/dev/null
   printf '%s\n' "$ledger" >> "$LOCAL/prior-ledgers.txt"
  fi
 done < "$LOCAL/claim-artifacts.txt"
 COPYFILE_DISABLE=1 gtar --no-xattrs --owner=0 --group=0 --numeric-owner -czf "$PACKAGE/prior-ledgers.tar.gz" -T "$LOCAL/prior-ledgers.txt"
 cp "$LOCAL/prior-ledgers.txt" "$PACKAGE/prior-ledgers.txt"
fi
if [[ ! -f "$PACKAGE/postcommit-evidence.tar.gz" ]]; then
 STAGE="$(mktemp -d)"
 trap 'rm -rf "$STAGE"' EXIT
 mkdir "$STAGE/run"
 COPYFILE_DISABLE=1 gtar --exclude=evidence.tar.gz -cf - -C "$LOCAL/committed-bindings" . | gtar -xf - -C "$STAGE/run"
 cp "$LOCAL/source-check.txt" "$STAGE/pre-format-source-check.txt"
 cp "$LOCAL/result.json" "$STAGE/pre-acceptance-gates.json"
 target/casper-task-017-4-finish/redact-bin "$STAGE" "$PWD" "$HOME" > "$PACKAGE/redactions.tsv"
 (cd "$STAGE" && find . -type f -exec shasum -a 256 {} + | sort) > "$PACKAGE/postcommit-files.sha256"
 COPYFILE_DISABLE=1 gtar --no-xattrs --owner=0 --group=0 --numeric-owner -czf "$PACKAGE/postcommit-evidence.tar.gz" -C "$STAGE" .
 rm -rf "$STAGE"
 trap - EXIT
fi
: > "$PACKAGE/source-digests.jsonl"
while IFS= read -r artifact; do
 jq -cn --arg path "$artifact" --arg digest "$(hash_file "$artifact")" '{key:$path,value:$digest}' >> "$PACKAGE/source-digests.jsonl"
done < "$LOCAL/claim-artifacts.txt"
jq -s 'from_entries' "$PACKAGE/source-digests.jsonl" > "$PACKAGE/source-digests.json"
rm "$PACKAGE/source-digests.jsonl"
CLAIM_SHA="$(hash_file "$SPEC")"
REVIEW_SHA="$(git show "$REV:docs/work-logs/task-017-4-final-checks.md" | shasum -a 256 | awk '{print $1}')"
PRIOR_SHA="$(hash_file "$PACKAGE/prior-ledgers.tar.gz")"
HISTORY=docs/casper/cbc-evidence/runs/casper-task-017-4-checks-20260918-01/report.json
jq -n --arg revision "$REV" --arg spec "$SPEC" --arg claim_sha "$CLAIM_SHA" --arg review_sha "$REVIEW_SHA" --arg history "$HISTORY" --arg history_sha "$(hash_file "$HISTORY")" --arg run_sha "$(hash_file "$PACKAGE/postcommit-evidence.tar.gz")" --arg prior_sha "$PRIOR_SHA" --slurpfile sources "$PACKAGE/source-digests.json" \
 '{schema_version:1,run_id:"casper-task-017-4-acceptance-01",claim_ids:["CLAIM-CASPER-SOAK-001"],claim_discharge:"discharged",phase:"pre_pr216_merge",scope:"bounded-harness-safety-and-binding-only",implementation_base:$revision,source_digests:$sources[0],claim_digests:{($spec):$claim_sha},reviewed_specification_sha256:"29709b0b86bcf1bc287582fa15410af0cc4d7381736c3d23576903db5ca66661",specification_change:"Acceptance metadata and bounded acceptance explanation only. The invariants are unchanged.",approval:{actor:"user",response:"approved",review:"docs/work-logs/task-017-4-final-checks.md",review_sha256:$review_sha,scope:"Bounded H01-H10 binding review with stated containment limits and profile/node verification pending."},tiers:{refutation:"bounded-safety-pass",binding:"passed",construction:"not-applicable"},bounds:{candidates:2,segments:2,iterations_total:4,children:1},historical_verification:{ref:$history,sha256:$history_sha},committed_source_verification:{archive:"postcommit-evidence.tar.gz",sha256:$run_sha,tests:22,driver_invocations:91,registered_cases:48,source_changes_from_original_package:"Five rustfmt-only changes. The committed source was verified again."},prior_ledgers:{archive:"prior-ledgers.tar.gz",sha256:$prior_sha},closure_validation:"validation.json records acceptance-state CI and completion checks separately.",provenance:"Artifact commit fields name the implementation base. commit_is_base=true identifies an explicit uncommitted acceptance-state packaging or legacy-ledger-name compatibility delta. SHA-256 binds the exact tested bytes.",soak:"pending",profile_claims:"pending",post_merge:"blocked",node_execution:false,waiver:null,proof_execution:false,limits:["No unbounded liveness or node-correctness discharge.","B44 and inherited containment assumptions remain unchanged.","Concurrent terminal writers use the transition lock.","Docker-boundary fixtures do not verify the Docker daemon.","Qualification, node dispatch, profile verification, and post-merge work remain separate."]}' > "$PACKAGE/report.json"
REPORT_SHA="$(hash_file "$PACKAGE/report.json")"
STAMP="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
while IFS= read -r artifact; do
 id="$(slug "$artifact")"
 ledger="docs/casper/cbc-evidence/$id.md"
 digest="$(hash_file "$artifact")"
 original="$(git show "$REV:$artifact" | shasum -a 256 | awk '{print $1}')"
 dirty=false
 [[ "$digest" == "$original" ]] || dirty=true
 previous=null
 if grep -Fxq "$ledger" "$PACKAGE/prior-ledgers.txt"; then
  previous="$(jq -cn --arg ref "$PACKAGE/prior-ledgers.tar.gz" --arg sha "$PRIOR_SHA" --arg member "$ledger" '{ref:$ref,sha256:$sha,member:$member}')"
 fi
 {
  printf '# CbC Evidence: %s\n\n' "$artifact"
  printf 'The user accepted the bounded H01–H10 binding review. This record discharges only CLAIM-CASPER-SOAK-001 in the pre-merge phase.\n\n'
  printf 'Profile verification, node soaks, post-merge work, and inherited containment limits remain separate. Earlier ledger bytes remain in the linked archive.\n\n```json\n'
  jq -n --arg path "$artifact" --arg id "$id" --arg commit "$REV" --arg sha "$digest" --arg spec "$SPEC" --arg claim_sha "$CLAIM_SHA" --arg ref "$PACKAGE/report.json" --arg report_sha "$REPORT_SHA" --arg stamp "$STAMP" --argjson dirty "$dirty" --argjson previous "$previous" \
   '{artifact:{path:$path,id:$id,commit:$commit,sha256:$sha,commit_is_base:$dirty},claim:$spec,claim_ids:["CLAIM-CASPER-SOAK-001"],claim_digests:{($spec):$claim_sha},adapter:"embedded",status:"discharged",scope:"bounded-harness-only",evidence:{kind:"accepted-bounded-refutation-and-binding",ref:$ref,sha256:$report_sha},previous_ledger:$previous,tiers:{refutation:"bounded-safety-pass",construction:"not-applicable",binding:"passed"},phase_status:{pre_pr216_merge:"discharged",post_pr216_merge:"blocked"},soak:"pending",waiver:null,verified_at:$stamp}'
  printf '```\n'
 } > "$ledger"
done < "$LOCAL/claim-artifacts.txt"
COPYFILE_DISABLE=1 gtar --no-xattrs --owner=0 --group=0 --numeric-owner -czf "$PACKAGE/source.tar.gz" -T "$LOCAL/claim-artifacts.txt" "$SPEC" formal/tlaplus/casper_soak/verification-plan.jsonc docs/work-logs/task-017-4-acceptance.md
printf 'Recorded bounded acceptance for 37 artifacts.\n'
