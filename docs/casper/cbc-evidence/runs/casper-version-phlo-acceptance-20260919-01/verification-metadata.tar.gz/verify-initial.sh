#!/usr/bin/env bash
set -euo pipefail
OUT=target/task-017-11-acceptance
EVIDENCE="$OUT/native"
PROFILE=formal/tlaplus/casper_soak/profiles/version_phlo
NEW=docs/casper/cbc-evidence/runs/casper-version-phlo-acceptance-20260919-01
sha() { shasum -a 256 "$1" | awk '{print $1}'; }
shasum -a 256 -c "$EVIDENCE/source-before.sha256" > "$OUT/fresh-source-check.txt"
cmp "$EVIDENCE/source-before.sha256" "$EVIDENCE/source-after.sha256"
[[ "$(wc -l < "$EVIDENCE/source-before.sha256" | tr -d ' ')" == 21 ]]
[[ "$(wc -l < "$EVIDENCE/actual-invocations.txt" | tr -d ' ')" == 103 ]]
find "$EVIDENCE/fixtures" -mindepth 3 -maxdepth 3 -name report.json -type f | LC_ALL=C sort > "$OUT/fresh-reports.txt"
[[ "$(wc -l < "$OUT/fresh-reports.txt" | tr -d ' ')" == 92 ]]
nested=0
while IFS= read -r report; do
 jq -r '((.retained_sources+.retained_inputs)[]|[.retained,.sha256]),["manifest.json",.manifest_sha256],["request.json",.request_sha256]|@tsv' "$report" > "$OUT/fresh-references.tsv"
 while IFS=$'\t' read -r path digest; do
  [[ "$path" != /* && "$path" != *..* && -f "$(dirname "$report")/$path" && ! -L "$(dirname "$report")/$path" ]]
  [[ "$(sha "$(dirname "$report")/$path")" == "$digest" ]]
  nested=$((nested+1))
 done < "$OUT/fresh-references.tsv"
 jq -e --slurpfile own "$EVIDENCE/identity.json" '.profile_binary_sha256==$own[0].executable_sha256 and .profile_identity.source_digests==$own[0].source_digests' "$report" >/dev/null
done < "$OUT/fresh-reports.txt"
[[ "$nested" == 1250 ]]
jq -e '.checks=="passed" and .required_rust_tests==15 and .required_cases==102 and .required_invocations==103 and .required_model_controls==4 and .exit==0 and .node_execution==false' "$EVIDENCE/summary.json" >/dev/null
jq -e '.status=="passed" and [.results[].exit]==[0,12,12,12] and [.results[].expected_property]==[null,"VersionLabelsSeparate","BothPhloFieldsCaptured","SettlementOutcomeClassified"] and [.results[].states_generated]==[1201,834,462,544] and [.results[].distinct_states]==[625,450,254,304] and all(.results[]; .outcome=="passed" and .exit==.expected_exit and .tlc_sha256=="936a262061c914694dfd669a543be24573c45d5aa0ff20a8b96b23d01e050e88")' "$EVIDENCE/models/report.json" >/dev/null
jq -r '.results[]|[.configuration,.configuration_sha256,.model_sha256,.log,.log_sha256,(.expected_property // "clean")]|@tsv' "$EVIDENCE/models/report.json" > "$OUT/fresh-models.tsv"
while IFS=$'\t' read -r cfg cfg_sha model_sha log log_sha property; do
 [[ "$(sha "$PROFILE/$cfg")" == "$cfg_sha" && "$(sha "$PROFILE/VersionPhlo.tla")" == "$model_sha" && "$(sha "$EVIDENCE/models/$log")" == "$log_sha" ]]
 if [[ "$property" == clean ]]; then
  grep -F 'Model checking completed. No error has been found.' "$EVIDENCE/models/$log" >/dev/null
  ! grep -q '^Error:' "$EVIDENCE/models/$log"
 else
  grep -Fx "Error: Invariant $property is violated." "$EVIDENCE/models/$log" >/dev/null
  grep -F 'State 1: <Initial predicate>' "$EVIDENCE/models/$log" >/dev/null
  awk -v expected="Error: Invariant $property is violated." '/^Error:/ && $0!=expected && $0!="Error: The behavior up to this point is:" {bad=1} END {exit bad}' "$EVIDENCE/models/$log"
 fi
done < "$OUT/fresh-models.tsv"
shared="$(awk '/^test result: ok\./ {count+=$5} END {print count}' "$OUT/shared-final.txt")"
[[ "$shared" == 11 && "$(<"$OUT/shared-final.exit")" == 0 ]]
CBC="${1:?Supply the shared CbC driver.}"
bash "$CBC" discharge --files "$(tr '\n' ' ' < "$OUT/artifact-files.txt")" --strict --json > "$OUT/artifact-gate.json"
jq -e --slurpfile review "$NEW/report.json" '.total==12 and .gaps==0 and all(.items[]; .status=="discharged") and ([.items[].path]|sort)==($review[0].artifact_inventory|sort)' "$OUT/artifact-gate.json" >/dev/null
count=0
while IFS= read -r artifact; do
 slug="$(printf '%s' "${artifact#.}"|tr '/._' '-')"
 ledger="docs/casper/cbc-evidence/$slug.md"
 [[ "$(readlink "docs/cbc-evidence/$slug.md")" == "../casper/cbc-evidence/$slug.md" ]]
 awk '/^```json$/{a=1;next} /^```$/{a=0} a{print}' "$ledger" | jq -e --arg before "$(sha "$OUT/previous-ledgers/$slug.md")" '.previous_ledger.member_sha256==$before and .status=="discharged" and .waiver==null' >/dev/null
 count=$((count+1))
done < "$OUT/artifact-files.txt"
[[ "$count" == 12 ]]
shasum -a 256 -c "$OUT/protected.sha256" > "$OUT/protected-final.txt"
jq -n --argjson nested "$nested" '{status:"accepted-binding-verification-passed",source_files:21,unchanged_implementation_files:20,artifacts:12,compatibility_links:12,tests:15,cases:102,invocations:103,reports:92,nested_references:$nested,model_controls:4,shared_tests:11,strict_claim007:0,strict_bundle:4,bundle_pending:["CLAIM-CASPER-SOAK-001"],artifact_gate:{total:12,gaps:0},retained_initial_shared_test:{exit:101,cause:"Claim metadata changed before ledger renewal. No source or assertion changed for the passing rerun."},workflow_tag_ratified:true,node_execution:false}' > "$OUT/verification.json"
printf 'Fresh evidence, exact12-artifact gate, links, and unrelated records verified.\n'
