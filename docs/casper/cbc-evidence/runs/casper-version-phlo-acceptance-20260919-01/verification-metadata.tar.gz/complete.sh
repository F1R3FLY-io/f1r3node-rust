#!/usr/bin/env bash
set -euo pipefail
HELPER="${1:?Supply the shared completion helper.}"
BASE=target/task-017-11-acceptance
OUT="$BASE/closure"
[[ ! -e "$OUT" && "$(shasum -a 256 "$HELPER"|awk '{print $1}')" == 924a1cde6ae61d15a72dda276687b0d63d9df0dd75d7b7f1aba4e8300f502d2e ]]
[[ "$(<"$BASE/verify-final-03.exit")" == 0 && "$(<"$BASE/claim-007.exit")" == 0 ]]
jq -e '.total==12 and .gaps==0 and all(.items[]; .status=="discharged")' "$BASE/artifact-gate.json" >/dev/null
mkdir "$OUT"
cp docs/ToDos.md "$OUT/ToDos.md"
cp docs/ToDos.md "$OUT/before.md"
DIRECTORY="$(cd "$(dirname "$HELPER")" && pwd)"
(cd "$DIRECTORY"; shasum -a 256 task-complete.sh lib/{integrity-walker,epic-parser,user-flow-parser,story-parser}.sh) > "$OUT/helper-inputs.sha256"
ln -s "$DIRECTORY/lib" "$OUT/lib"
awk 'BEGIN {n=0} $0=="main \"$@\"" {n++;next} {print} END {if(n!=1)exit 2}' "$HELPER" > "$OUT/helper.sh"
export TODOS_FILE="$OUT/ToDos.md" USER_FLOWS_FILE=docs/User-Flows.md USER_STORIES_FILE=docs/UserStories.md BF_TODO_PARSER_STRICT=0
source "$OUT/helper.sh"
epics="$(parse_epics "$TODOS_FILE")"
printf '%s\n' "$epics" > "$OUT/epics-before.json"
jq -e '[.[]|.tasks[]?|select(.id=="TASK-017-11")]|length==1 and .[0].status=="in_progress"' "$OUT/epics-before.json" >/dev/null
_set_task_field "$TODOS_FILE" TASK-017-11 binding_status passed
_set_task_field "$TODOS_FILE" TASK-017-11 workflow_tag_status ratified
_set_task_field "$TODOS_FILE" TASK-017-11 validation_evidence docs/casper/cbc-evidence/runs/casper-version-phlo-acceptance-20260919-01/report.json
_set_task_field "$TODOS_FILE" TASK-017-11 completion_blocker null
mark_task_complete TASK-017-11 scripts/casper-soak/tests/version_phlo.rs true false false > "$OUT/completion.txt" 2>&1
report="$(validate_task TASK-017-11)"
printf '%s\n' "$report" > "$OUT/integrity.json"
jq -e '.grade=="full" and (.gaps|length)==0' "$OUT/integrity.json" >/dev/null
epics="$(parse_epics "$TODOS_FILE")"
printf '%s\n' "$epics" > "$OUT/epics-after.json"
for phase in before after; do jq '[.[]|.tasks[]?|select(.id!="TASK-017-11")]' "$OUT/epics-$phase.json" > "$OUT/unrelated-$phase.json"; done
cmp "$OUT/unrelated-before.json" "$OUT/unrelated-after.json"
status=0
diff -u --label a/docs/ToDos.md --label b/docs/ToDos.md "$OUT/before.md" "$OUT/ToDos.md" > "$OUT/completion.patch" || status=$?
[[ "$status" == 1 ]]
printf 'Strict TASK01711 closure patch prepared. The real tracker and index remain unchanged.\n'
