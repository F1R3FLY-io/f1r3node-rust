#!/usr/bin/env bash
set -euo pipefail
OUT=target/task-017-11-acceptance
OLD=docs/casper/cbc-evidence/runs/casper-version-phlo-20260919-01
NEW=docs/casper/cbc-evidence/runs/casper-version-phlo-acceptance-20260919-01
SPEC=docs/claims/casper-soak-version-phlo.md
sha() { shasum -a 256 "$1" | awk '{print $1}'; }
[[ ! -e "$NEW" && "$(git rev-parse HEAD)" == "$(<"$OUT/base-revision.txt")" ]]
[[ "$(<"$OUT/native.exit")" == 0 ]]
shasum -a 256 -c "$OLD/artifacts.sha256" > "$OUT/review-recheck.txt"
shasum -a 256 -c "$OUT/protected.sha256" > "$OUT/protected-check.txt"
jq -r --arg spec "$SPEC" '.source_digests|del(.[$spec])|to_entries[]|"\(.value)  \(.key)"' "$OLD/report.json" > "$OUT/implementation.sha256"
shasum -a 256 -c "$OUT/implementation.sha256" > "$OUT/implementation-check.txt"
jq -e '.status=="uploaded-and-download-verified" and .draft and .existing_assets_unchanged and (.uploaded_assets|length)==2' "$OUT/upload/receipt.json" >/dev/null
mkdir "$NEW" "$OUT/accepted-ledgers"
COPYFILE_DISABLE=1 tar -czf "$NEW/previous-metadata.tar.gz" -C "$OUT" previous-ledgers prior
cp "$OUT/upload/receipt.json" "$NEW/upload-receipt.json"
TIME="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
SPEC_SHA="$(sha "$SPEC")"
PREVIOUS_SHA="$(sha "$NEW/previous-metadata.tar.gz")"
jq --arg spec "$SPEC" --arg spec_sha "$SPEC_SHA" --arg time "$TIME" --arg base "$(git rev-parse HEAD)" --arg old "$OLD/report.json" --arg old_sha "$(sha "$OLD/report.json")" --arg validation "$OLD/validation.json" --arg validation_sha "$(sha "$OLD/validation.json")" --arg previous "$NEW/previous-metadata.tar.gz" --arg previous_sha "$PREVIOUS_SHA" --arg receipt "$NEW/upload-receipt.json" --arg receipt_sha "$(sha "$NEW/upload-receipt.json")" --arg attributes_sha "$(sha .gitattributes)" --slurpfile native "$OUT/native/summary.json" --slurpfile models "$OUT/native/models/report.json" '{schema_version:1,status:"accepted-bounded-protocol-phlo-binding",claim_discharge:"discharged",claim_ids:["CLAIM-CASPER-SOAK-007"],phase:"pre_pr216_merge",scope:"harness-profile",recorded_at:$time,base_commit:$base,working_tree:true,source_digests:(.source_digests|.[$spec]=$spec_sha),claim_digests:{($spec):$spec_sha},artifact_inventory:.artifact_inventory,tiers:{refutation:"bounded-safety-pass",construction:"not-applicable",binding:"passed"},approval:{binding:"I accept Claim007’s bounded protocol/Phlo harness binding",workflow_tag:"ratify: .github/workflows/casper-version-phlo.yml cbc=mandatory cbc-weight=high",upload:"I authorize upload of the two sanitized evidence archives to the existing draft evidence release.",scope:"bounded-pre-merge-claim007-binding-and-exact-workflow-tag",recorded_at:$time},review:{report:$old,sha256:$old_sha,validation:$validation,validation_sha256:$validation_sha,previous_spec_sha256:.claim_digests[$spec],historical_hosted_head:.hosted.head_revision,retained_failures_preserved:true},previous_metadata:{path:$previous,sha256:$previous_sha,ledger_count:12,claim_member:"prior/claim.md",attributes_member:"prior/gitattributes"},workflow_tag:{path:".github/workflows/casper-version-phlo.yml",cbc:"mandatory",weight:"high",ratified:true,attributes_sha256:$attributes_sha},upload_receipt:{path:$receipt,sha256:$receipt_sha},fresh_native:{summary:$native[0],model_results:[$models[0].results[]|{configuration,exit,expected_property,model_sha256,configuration_sha256,log_sha256,states_generated,distinct_states}]},reviewed_artifacts_unchanged:true,metadata_only_specification_change:true,private_supplement:{binary_copies_retrieved_after_review:true,binary_sha256:["5bc527a1d424113bc4e902ca83c2fe34117f5eb1c8f3a94ecd71925b14fcf58d","4679aed3c217ea861825ef9e10d97b312c5a563105b3defa5699f70e5ac35e74"],uploaded:false,original_container_inspection:"not-retained"},other_claims:"outside-this-acceptance",task_closure:"requires-separate-strict-integrity-check",release_published:false,live_adapters:"unqualified",post_merge_execution:"blocked",policy_activation:false,node_execution:false,soak:"pending",waiver:null}' "$OLD/report.json" > "$NEW/report.json"
REPORT_SHA="$(sha "$NEW/report.json")"
: > "$OUT/ledgers.patch"
count=0
for prior in "$OUT"/previous-ledgers/*.md; do
 name="${prior##*/}"; current="docs/casper/cbc-evidence/$name"
 cmp "$prior" "$current"
 body="$(awk '/^```json$/{a=1;next} /^```$/{a=0} a{print}' "$current")"
 path="$(jq -r .artifact.path <<< "$body")"
 [[ "$(jq -r .artifact.sha256 <<< "$body")" == "$(sha "$path")" ]]
 {
  printf '# CbC Evidence: %s\n\nThe user accepted this bounded pre-merge binding and ratified the workflow tag. Node correctness and live execution remain outside this discharge.\n\n```json\n' "$path"
  jq --arg spec "$SPEC" --arg sha "$SPEC_SHA" --arg report "$NEW/report.json" --arg report_sha "$REPORT_SHA" --arg time "$TIME" --arg previous "$NEW/previous-metadata.tar.gz" --arg previous_sha "$PREVIOUS_SHA" --arg name "$name" --arg prior_sha "$(sha "$prior")" '.status="discharged" | .claim_digests[$spec]=$sha | .tiers.binding="passed" | .phase_status.pre_pr216_merge="discharged" | .evidence.kind="accepted-bounded-refutation-and-controlled-fixtures" | .evidence.ref=$report | .evidence.sha256=$report_sha | .verified_at=$time | .previous_ledger={path:$previous,sha256:$previous_sha,member:("previous-ledgers/"+$name),member_sha256:$prior_sha} | .pending=[]' <<< "$body"
  printf '```\n'
 } > "$OUT/accepted-ledgers/$name"
 code=0
 diff -u --label "a/$current" --label "b/$current" "$current" "$OUT/accepted-ledgers/$name" >> "$OUT/ledgers.patch" || code=$?
 [[ "$code" == 1 ]]
 count=$((count+1))
done
[[ "$count" == 12 ]]
git apply --check "$OUT/ledgers.patch"
git apply "$OUT/ledgers.patch"
printf 'Acceptance report and twelve discharged ledgers recorded.\n'
