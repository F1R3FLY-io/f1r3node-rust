#!/usr/bin/env bash
set -euo pipefail
ROOT="$PWD"
WORK=target/task-017-6
STAGE=target/task-017-6-retention
PKG=docs/casper/cbc-evidence/runs/casper-publication-20260918-01
BASE=b5c24da0217465eeef5fb07e3d9126fb759a5b59
SPEC=docs/claims/casper-soak-publication.md
[[ ! -e "$STAGE" && ! -e "$PKG" ]]
mkdir -p "$STAGE/source" "$STAGE/support" "$PKG"
shasum -a 256 -c "$WORK/final-source/source-before.sha256" >"$WORK/final-source-check.txt"
git status --porcelain >"$WORK/git-status.txt"
git rev-parse HEAD >"$WORK/head.txt"
git diff --name-only "$BASE" >"$WORK/changed-tracked.txt"
bash -n scripts/casper-soak/check-publication.sh
rustfmt --edition 2021 --check scripts/casper-soak/src/bin/casper-publication.rs scripts/casper-soak/src/profiles/publication.rs scripts/casper-soak/tests/publication.rs >"$WORK/final-format.txt" 2>&1
git diff --check >"$WORK/final-diff.txt" 2>&1
cp "$WORK/final-source/source-before.sha256" "$PKG/source-files.sha256"
shasum -a 256 docs/work-logs/task-017-6-publication.md >>"$PKG/source-files.sha256"
while read -r digest path; do
    mkdir -p "$STAGE/source/$(dirname "$path")"
    cp "$path" "$STAGE/source/$path"
done <"$PKG/source-files.sha256"
cp -R "$WORK" "$STAGE/evidence"
cp target/casper-task-017-4-finish/redact.rs "$STAGE/support/redact.rs"
cp "$0" "$STAGE/support/retain.sh"
cp docs/ToDos.md "$STAGE/support/ToDos.md"
find "$STAGE/evidence" -type f -exec chmod u+w {} +
target/casper-task-017-4-finish/redact-bin "$STAGE/evidence" "$ROOT" "$HOME" >"$PKG/redactions.tsv"
find "$STAGE/evidence" -type l | sort | while read -r path; do printf '%s\t%s\n' "${path#"$STAGE/evidence/"}" "$(readlink "$path")"; done >"$PKG/symlinks.tsv"
(cd "$STAGE/evidence" && find . -type f -print0 | sort -z | xargs -0 shasum -a 256) >"$PKG/evidence-files.sha256"
for part in source evidence support; do
    gtar --owner=0 --group=0 --numeric-owner --no-xattrs --no-acls --sort=name -czf "$PKG/$part.tar.gz" -C "$STAGE/$part" .
done
cp "$STAGE/evidence/final-source/models/report.json" "$PKG/models.json"
cp "$STAGE/evidence/final-source/models/profile-model.json" "$PKG/model-layout.json"
cp "$STAGE/evidence/claim-001-final.json" "$PKG/claim-001.json"
cp "$STAGE/evidence/claim-003-final.json" "$PKG/claim-003.json"
cp "$WORK/lsp.json" "$PKG/lsp.json"
find "$STAGE/evidence/final-source/fixtures" -name 'invocation-*.json' -exec jq -c '{arguments,expected_exit,actual_exit,expected_verdict,observed_verdict:(.stdout|fromjson|.scenario_verdict)}' {} \; | jq -s 'sort_by(.arguments,.expected_verdict)' >"$PKG/fixture-inventory.json"
awk '{printf "{\"path\":\"%s\",\"sha256\":\"%s\"}\n",$2,$1}' "$PKG/source-files.sha256" | jq -s 'map({key:.path,value:.sha256})|from_entries' >"$STAGE/source-digests.json"
STAMP="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
SPEC_SHA="$(shasum -a 256 "$SPEC" | awk '{print $1}')"
LINUX_SHA="$(shasum -a 256 target/aarch64-unknown-linux-musl/debug/casper-publication | awk '{print $1}')"
jq -n --arg stamp "$STAMP" --arg base "$BASE" --arg spec "$SPEC" --arg spec_sha "$SPEC_SHA" --arg linux "$LINUX_SHA" --arg source "$(shasum -a 256 "$PKG/source.tar.gz" | awk '{print $1}')" --arg evidence "$(shasum -a 256 "$PKG/evidence.tar.gz" | awk '{print $1}')" --arg support "$(shasum -a 256 "$PKG/support.tar.gz" | awk '{print $1}')" --slurpfile source_digests "$STAGE/source-digests.json" --slurpfile identity "$WORK/final-source/identity.json" --slurpfile models "$PKG/models.json" '{schema_version:1,run_id:"casper-publication-20260918-01",claim_ids:["CLAIM-CASPER-SOAK-003"],status:"verification-passed-claim-pending",phase:"pre_pr216_merge",implementation_base:$base,commit_is_base:true,worktree_dirty:true,verified_at:$stamp,scope:"controlled-transcript-profile-and-bounded-refutation",node_execution:false,proof_execution:false,unbounded_proof:false,refutation_executed:true,source_digests:$source_digests[0],claim_digests:{($spec):$spec_sha},executables:{native_sha256:$identity[0].executable_sha256,linux_musl_sha256:$linux},archives:{"source.tar.gz":$source,"evidence.tar.gz":$evidence,"support.tar.gz":$support},tiers:{refutation:"bounded-safety-pass",construction:"not-applicable",binding:"pending-review",soak:"pending"},checks:{rust_tests:6,fixture_cases:57,profile_invocations:61,tuple_combinations:16,clean_distinct_states:1681,clean_generated_states:3281,negative_controls:3,existing_profile_tests:8,shared_host_regressions:11,linux_cross_build:"passed",linux_execution:"not-run-docker-unavailable",native_test_optimization:0,linux_test_optimization:1,java:"26.0.2.1",tlc:"2.19",tlc_jar_sha256:"936a262061c914694dfd669a543be24573c45d5aa0ff20a8b96b23d01e050e88",rustfmt:"passed",bash_syntax:"passed",ste_check:"passed",strict_claim_001_exit:0,strict_claim_003_exit:4},final_evidence:"evidence.tar.gz:final-source",failure_history:["initial-red: compilation failure, exit 101","receipt-red: wrong predecessor passed, exit 101","work-red: unknown inventory hid an observed loss, exit 101","qualification-red: wrong node binary qualification passed, exit 101","initial claim audit commands: unsupported flag, exit 2","Docker socket unavailable"],red_source_snapshots:["initial-source.tar.gz","receipt-red-source.tar.gz","work-red-source.tar.gz","qualification-red-source.tar.gz"],retention_transformations:["Exact workspace and home prefixes replaced in text with recorded before/after hashes.","Numeric archive owners, no xattrs, and no ACLs.","Evidence staging files have owner-write permission. Original filesystem modes are not claimed."],limits:["Human binding acceptance remains pending.","The new workflow mandatory tag remains unratified and unapplied.","Linux execution and hosted CI execution remain unverified.","All live, parallel-policy, and post-merge requests remain blocked.","The model abstracts valid auxiliary fields and excludes independent earlier failures.","Controlled transcripts do not prove process containment or node storage atomicity.","One informational Rust 2024 suggestion remains deferred for this Rust 2021 crate.","The index changed outside assistant commands and was preserved."],waiver:null}' >"$PKG/report.json"
REPORT_SHA="$(shasum -a 256 "$PKG/report.json" | awk '{print $1}')"
awk '/^artifacts:/{inside=1;next} inside && /^  - /{sub(/^  - /,""); print;next} inside {exit}' "$SPEC" >"$STAGE/artifacts.txt"
while read -r path; do
    slug="$(printf '%s' "${path#.}" | tr '/._' '---')"
    ledger="docs/casper/cbc-evidence/$slug.md"
    link="docs/cbc-evidence/$slug.md"
    [[ ! -e "$ledger" && ! -L "$ledger" && ! -e "$link" && ! -L "$link" ]]
    {
        printf '# CbC Evidence: %s\n\nThe bounded model and controlled fixtures pass. Human binding acceptance remains pending. This record does not discharge the claim.\n\n```json\n' "$path"
        jq -n --arg path "$path" --arg slug "$slug" --arg base "$BASE" --arg digest "$(shasum -a 256 "$path" | awk '{print $1}')" --arg spec "$SPEC" --arg spec_sha "$SPEC_SHA" --arg report "$PKG/report.json" --arg report_sha "$REPORT_SHA" --arg stamp "$STAMP" '{artifact:{path:$path,id:$slug,commit:$base,commit_is_base:true,sha256:$digest},claim:$spec,claim_ids:["CLAIM-CASPER-SOAK-003"],claim_digests:{($spec):$spec_sha},adapter:"embedded",status:"pending",scope:"bounded-publication-profile",evidence:{kind:"bounded-refutation-and-executable-fixtures",ref:$report,sha256:$report_sha},tiers:{refutation:"bounded-safety-pass",construction:"not-applicable",binding:"pending-review"},phase_status:{pre_pr216_merge:"pending",post_pr216_merge:"blocked"},soak:"pending",waiver:null,verified_at:$stamp}'
        printf '```\n'
    } >"$ledger"
    ln -s "../casper/cbc-evidence/$slug.md" "$link"
done <"$STAGE/artifacts.txt"
(cd "$PKG" && find . -maxdepth 1 -type f ! -name artifacts.sha256 -print0 | sort -z | xargs -0 shasum -a 256) >"$PKG/artifacts.sha256"
printf '%s\n' "$REPORT_SHA"
