crash_monitor() {
	local driver="$1" identity="$2" directory="$3" output="$4" status=0
	if ! host_control watch "$driver" "$identity" "$directory/ready"; then
		printf 'Driver exit monitoring is unconfirmed.\n' >"$output/writer-stop-failure.txt" 2>/dev/null || true
		stop_node_writers -q kill || true
		printf '2\n' >"$directory/exit-code.txt"
		exit 2
	fi
	if host_control handled "$directory/handled-exit" >/dev/null 2>&1; then exit 0; fi
	stop_node_writers -q kill || status=$?
	if [ "$status" -ne 0 ]; then
		printf 'Writer termination is unconfirmed after the driver exited.\n' >"$output/writer-stop-failure.txt" 2>/dev/null || true
	fi
	printf '%s\n' "$status" >"$directory/exit-code.txt"
	exit "$status"
}
