crash_monitor() {
	local driver="$1" identity="$2" directory="$3" output="$4" status=0 marker
	printf '%s\n' "$$" >"$directory/ready"
	until process_gone "$driver" "$identity"; do sleep 0.1; done
	marker="$(head -c 8 "$directory/handled-exit" 2>/dev/null; printf x)"
	[ "$marker" != $'handled\nx' ] || exit 0
	stop_node_writers -q kill || status=$?
	if [ "$status" -ne 0 ]; then
		printf 'Writer termination is unconfirmed after the driver exited.\n' >"$output/writer-stop-failure.txt" 2>/dev/null || true
	fi
	printf '%s\n' "$status" >"$directory/exit-code.txt"
	exit "$status"
}
