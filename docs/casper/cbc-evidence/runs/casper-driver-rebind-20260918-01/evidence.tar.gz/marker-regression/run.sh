#!/usr/bin/env bash
set -euo pipefail
version="$1"
source "/case/$version.sh"
process_gone() { return 0; }
host_control() {
 if [[ "$1" == watch ]]; then return 0; fi
 /case/casper-soak host-control "$@"
}
stop_node_writers() { printf 'stopped\n' >"$TEST_OUTPUT/stopped"; }
result=0
for kind in exact extra nul missing; do
 TEST_OUTPUT="/case/$version-$kind"
 mkdir -p "$TEST_OUTPUT/monitor"
 case "$kind" in
 exact) printf 'handled\n' >"$TEST_OUTPUT/monitor/handled-exit" ;;
 extra) printf 'handled\nextra' >"$TEST_OUTPUT/monitor/handled-exit" ;;
 nul) printf 'handled\n\0' >"$TEST_OUTPUT/monitor/handled-exit" ;;
 esac
 (crash_monitor 123 456 "$TEST_OUTPUT/monitor" "$TEST_OUTPUT")
 observed=false
 [[ ! -f "$TEST_OUTPUT/stopped" ]] || observed=true
 expected=true
 [[ "$kind" != exact ]] || expected=false
 printf '%s %s cleanup=%s expected=%s\n' "$version" "$kind" "$observed" "$expected"
 [[ "$observed" == "$expected" ]] || result=1
done
exit "$result"
