#!/usr/bin/env bash
set -euo pipefail
OUT="$PWD/target/casper-driver-rebind/host-controls-verified"
mkdir "$OUT"
IMAGE=sha256:7d402dd7f1922bcdbdbeb90d14cecf398fdd36bc5105242fa4a4dc1d1cd596c5
TEST="$(jq -rs '[.[] | select(.reason=="compiler-artifact" and .target.name=="casper-soak" and .profile.test==true and .executable!=null) | .executable] | last' target/casper-driver-rebind/build.jsonl)"
shasum -a 256 "$TEST" >"$OUT/executable.sha256"
find scripts/casper-soak/src -type f -exec shasum -a 256 {} \; >"$OUT/sources.sha256"
for USER in 65534:65534 0:0; do
 NAME="${USER%%:*}"
 EXTRA=()
 if [[ "$NAME" == 0 ]]; then EXTRA=(--include-ignored); fi
 C="$(docker create --pull=never --network none --cap-drop ALL --security-opt no-new-privileges --pids-limit 128 --memory 256m --cpus 1 --user "$USER" --entrypoint timeout "$IMAGE" --signal=TERM --kill-after=5 30 /case/test --test-threads=1 --nocapture "${EXTRA[@]}")"
 docker inspect "$C" >"$OUT/$NAME-container.json"
 jq -e '.[0] | (.Mounts|length)==0 and .HostConfig.NetworkMode=="none" and .HostConfig.Privileged==false and .HostConfig.PidMode=="" and .HostConfig.CapDrop==["ALL"]' "$OUT/$NAME-container.json" >/dev/null
 docker cp "$TEST" "$C:/case/test" >/dev/null
 status=0
 timeout --kill-after=5 40 docker start -a "$C" >"$OUT/$NAME-tests.txt" 2>&1 || status=$?
 printf '%s\n' "$status" >"$OUT/$NAME-exit.txt"
 docker inspect "$C" >"$OUT/$NAME-finished.json"
 docker rm -f "$C" >"$OUT/$NAME-cleanup.txt"
 [[ "$status" == 0 ]]
done
shasum -a 256 -c "$OUT/executable.sha256" >"$OUT/executable-check.txt"
shasum -a 256 -c "$OUT/sources.sha256" >"$OUT/source-check.txt"
