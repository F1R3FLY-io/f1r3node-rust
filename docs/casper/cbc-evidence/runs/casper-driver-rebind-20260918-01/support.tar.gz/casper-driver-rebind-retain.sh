#!/usr/bin/env bash
set -euo pipefail
ROOT="$PWD"
RUN=docs/casper/cbc-evidence/runs/casper-driver-rebind-20260918-01
STAGE=target/casper-driver-rebind-retention
SPEC=docs/claims/casper-soak-harness.md
[[ ! -e "$RUN" && ! -e "$STAGE" ]]
mkdir -p "$RUN/candidate-ledgers" "$STAGE/source" "$STAGE/evidence" "$STAGE/previous" "$STAGE/support"
awk '/^artifacts:$/ {selected=1;next} selected && /^  - / {sub(/^  - /, "");print;next} selected {exit}' "$SPEC" >"$STAGE/claimed-paths.txt"
slug() {
 local name="${1#.}"
 name="${name//\//-}"; name="${name//./-}"; name="${name//_/-}"
 [[ "$1" != scripts/casper-soak/Cargo.toml ]] || name=scripts-casper-soak-cargo-toml
 printf '%s' "$name"
}
while IFS= read -r path; do
 ledger="docs/casper/cbc-evidence/$(slug "$path").md"
 if [[ -f "$ledger" ]]; then
  mkdir -p "$STAGE/previous/$(dirname "$ledger")"
  cp "$ledger" "$STAGE/previous/$ledger"
 fi
done <"$STAGE/claimed-paths.txt"
{
 printf '%s\n' "$SPEC" docs/work-logs/casper-driver-source-rebind.md Cargo.toml Cargo.lock rust-toolchain.toml .cargo/config.toml .gitattributes
 printf '%s\n' formal/tlaplus/casper_soak/verification-plan.jsonc scripts/bench/collect-soak-metrics.sh scripts/bench/soak-metrics.json scripts/bench/run-bench-segment.sh scripts/bench/soak-disk-test.Dockerfile
 cat "$STAGE/claimed-paths.txt"
 find scripts/casper-soak/src scripts/casper-soak/tests -type f
 printf '%s\n' docs/claims/casper-soak-*.md
} | sort -u >"$STAGE/source-paths.txt"
while IFS= read -r path; do
 [[ -f "$path" && ! -L "$path" ]]
 mkdir -p "$STAGE/source/$(dirname "$path")"
 cp "$path" "$STAGE/source/$path"
done <"$STAGE/source-paths.txt"
cp -R target/casper-driver-rebind/. "$STAGE/evidence/"
mkdir -p "$STAGE/support/before-interruption-fix"
gtar -xzf target/casper-driver-rebind/before-interruption-fix.tar.gz -C "$STAGE/support/before-interruption-fix"
find "$STAGE/evidence" -name '*.tar.gz' -type f -delete
cp target/casper-driver-rebind-retain.sh target/casper-driver-rebind/{run-host-controls,run-profile-regressions,marker-regression}.sh target/casper-task-017-4-finish/redact.rs "$STAGE/support/"
find "$STAGE/evidence" -type l -print | while IFS= read -r link; do
 printf '%s\t%s\n' "${link#"$STAGE/"}" "$(readlink "$link")"
 rm "$link"
done >"$RUN/symlinks.tsv"
target/casper-task-017-4-finish/redact-bin "$STAGE" "$ROOT" "$HOME" >"$RUN/redactions.tsv"
(cd "$STAGE/source" && find . -type f | sort | while IFS= read -r path; do shasum -a 256 "${path#./}"; done) >"$RUN/source-files.sha256"
(cd "$STAGE/evidence" && find . -type f | sort | while IFS= read -r path; do shasum -a 256 "${path#./}"; done) >"$RUN/evidence-files.sha256"
(cd "$STAGE/previous" && find . -type f | sort | while IFS= read -r path; do shasum -a 256 "${path#./}"; done) >"$RUN/previous-ledgers.sha256"
for tree in source evidence previous support; do
 COPYFILE_DISABLE=1 gtar --owner=0 --group=0 --numeric-owner --no-xattrs --no-acls -czf "$RUN/$tree.tar.gz" -C "$STAGE/$tree" .
done
jq -Rn '[inputs | capture("^(?<sha>[0-9a-f]{64})  (?<path>.+)$")] | map({key:.path,value:.sha}) | from_entries' <"$RUN/source-files.sha256" >"$STAGE/source-digests.json"
for claim in 001 004; do
 status=0
 target/debug/check-casper-claims --root . --claim "CLAIM-CASPER-SOAK-$claim" --strict --output "$RUN/claim-$claim.json" >"$RUN/claim-$claim.txt" 2>&1 || status=$?
 [[ "$status" == 4 ]]
done
target/debug/check-casper-claims --root . --output "$RUN/bundle-audit.json" >"$RUN/bundle-audit.txt" 2>&1
BASE="$(git rev-parse HEAD)"
SPEC_HASH="$(shasum -a 256 "$SPEC" | awk '{print $1}')"
STAMP="$(date -u +%FT%TZ)"
jq -n --arg base "$BASE" --arg stamp "$STAMP" --arg spec "$SPEC" --arg spec_hash "$SPEC_HASH" \
 --slurpfile sources "$STAGE/source-digests.json" \
 --slurpfile counts target/casper-driver-rebind/bindings-verified/evidence/counts.json \
 --slurpfile model target/casper-driver-rebind/models-verified/report.json \
 '{schema_version:1,status:"verification-passed-binding-review-pending",claim_ids:["CLAIM-CASPER-SOAK-001"],claim_discharge:"pending",phase:"pre_pr216_merge",base_commit:$base,verified_at:$stamp,source_digests:$sources[0],claim_digests:{($spec):$spec_hash},tiers:{refutation:"bounded-safety-pass",construction:"not-applicable",binding:"pending-review"},scope:"bounded-harness-only",soak:"pending",waiver:null,user_acceptance:"not-recorded-for-repaired-source",historical_acceptance_preserved:true,node_launch_count:0,policy_activation:false,tests:{shared_existing:22,host_control_unprivileged:7,host_control_ignored_root_only:1,host_control_root:8,disk_scenarios:42,profile_regressions:21,registered_cases:$counts[0].registered_cases,driver_invocations:$counts[0].driver_invocations,matched_exits:$counts[0].matched_exits},refutation:{clean_distinct_states:$model[0].results[0].distinct_states,clean_generated_states:$model[0].results[0].states_generated,negative_controls:10},audits:{ordinary_bundle_exit:0,strict_claim_001_exit:4,strict_claim_004_exit:4},evidence:{bindings:"bindings-verified",host_control:"host-controls-verified",disk:"disk-verified",models:"models-verified",profiles:"profile-regressions",marker_red_green:"marker-verified"},failures_retained:["initial-unprivileged-oom-fixture","interruption-mock-missing-unit-artifact","stale-source-audit","published-crash-monitor-accepts-marker-suffix"],limits:["The initial OOM failure has logs but no complete source snapshot.","The marker regression uses an extracted function and controlled exit receipt.","The PID fixture does not force numeric PID reuse.","Host language-server checks exclude Linux-only code. Linux compilation and execution are retained separately.","The owner scan is not an atomic inventory of future processes.","B44 and inherited containment limits remain unresolved.","No hosted workflow or live node campaign ran."],retention:{text_transform:"Exact workspace and home prefixes become placeholders. Redaction records bind before and after hashes.",archive_metadata:"Numeric owner and group zero, no extended attributes or ACLs. Original filesystem modes are not asserted.",symlinks:"Evidence links are recorded in symlinks.tsv instead of archived as links.",duplicate_archives:"Nested duplicate evidence archives are omitted. The pre-interruption source archive is expanded in support."}}' >"$RUN/report.json"
REPORT_HASH="$(shasum -a 256 "$RUN/report.json" | awk '{print $1}')"
while IFS= read -r path; do
 name="$(slug "$path")"
 hash="$(shasum -a 256 "$path" | awk '{print $1}')"
 {
  printf '# Pending repair binding: %s\n\nThis candidate does not replace the canonical acceptance record. The repaired source requires binding acceptance.\n\n```json\n' "$path"
  jq -n --arg path "$path" --arg name "$name" --arg hash "$hash" --arg base "$BASE" --arg spec "$SPEC" --arg spec_hash "$SPEC_HASH" --arg report "$RUN/report.json" --arg report_hash "$REPORT_HASH" --arg stamp "$STAMP" \
   '{artifact:{path:$path,id:$name,commit:$base,commit_is_base:true,sha256:$hash},claim:$spec,claim_ids:["CLAIM-CASPER-SOAK-001"],claim_digests:{($spec):$spec_hash},adapter:"embedded",status:"pending",scope:"bounded-harness-only",evidence:{kind:"bounded-refutation-and-binding-candidate",ref:$report,sha256:$report_hash},tiers:{refutation:"bounded-safety-pass",construction:"not-applicable",binding:"pending-review"},phase_status:{pre_pr216_merge:"pending",post_pr216_merge:"blocked"},soak:"pending",waiver:null,verified_at:$stamp}'
  printf '```\n'
 } >"$RUN/candidate-ledgers/$name.md"
done <"$STAGE/claimed-paths.txt"
cp "$STAGE/claimed-paths.txt" "$RUN/claimed-paths.txt"
(cd "$RUN" && find . -type f ! -name artifacts.sha256 | sort | while IFS= read -r path; do shasum -a 256 "${path#./}"; done) >"$RUN/artifacts.sha256"
printf 'Retained %s\n' "$RUN"
