#!/usr/bin/env bash
set -euo pipefail
OUT="$PWD/target/casper-driver-rebind/marker-verified"
mkdir "$OUT"
for version in before after; do
 source=target/casper-driver-rebind/driver-before.sh
 [[ "$version" != after ]] || source=scripts/run-merge-recovery-soak.sh
 awk '/^crash_monitor\(\)/ {selected=1} selected {print} selected && /^}/ {exit}' "$source" >"$OUT/$version.sh"
done
cat >"$OUT/run.sh" <<'SH'
#!/usr/bin/env bash
set -euo pipefail
version="$1"
source "/case/$version.sh"
process_gone() { return 0; }
host_control() {
 if [[ "$1" == watch ]]; then return 0; fi
 /case/casper-soak host-control "$@"
}
stop_node_writers() { printf 'stopped\n' >"$TEST_OUTPUT/stopped"; }
result=0
for kind in exact extra nul missing; do
 TEST_OUTPUT="/case/$version-$kind"
 mkdir -p "$TEST_OUTPUT/monitor"
 case "$kind" in
 exact) printf 'handled\n' >"$TEST_OUTPUT/monitor/handled-exit" ;;
 extra) printf 'handled\nextra' >"$TEST_OUTPUT/monitor/handled-exit" ;;
 nul) printf 'handled\n\0' >"$TEST_OUTPUT/monitor/handled-exit" ;;
 esac
 (crash_monitor 123 456 "$TEST_OUTPUT/monitor" "$TEST_OUTPUT")
 observed=false
 [[ ! -f "$TEST_OUTPUT/stopped" ]] || observed=true
 expected=true
 [[ "$kind" != exact ]] || expected=false
 printf '%s %s cleanup=%s expected=%s\n' "$version" "$kind" "$observed" "$expected"
 [[ "$observed" == "$expected" ]] || result=1
done
exit "$result"
SH
IMAGE=sha256:7d402dd7f1922bcdbdbeb90d14cecf398fdd36bc5105242fa4a4dc1d1cd596c5
for version in before after; do
 C="$(docker create --pull=never --network none --cap-drop ALL --security-opt no-new-privileges --pids-limit 64 --memory 128m --cpus 1 --user 65534:65534 --entrypoint timeout "$IMAGE" --kill-after=5 20 bash /case/run.sh "$version")"
 docker inspect "$C" >"$OUT/$version-container.json"
 docker cp "$OUT/run.sh" "$C:/case/run.sh" >/dev/null
 docker cp "$OUT/$version.sh" "$C:/case/$version.sh" >/dev/null
 docker cp target/aarch64-unknown-linux-musl/debug/casper-soak "$C:/case/casper-soak" >/dev/null
 status=0
 timeout --kill-after=5 30 docker start -a "$C" >"$OUT/$version.txt" 2>&1 || status=$?
 printf '%s\n' "$status" >"$OUT/$version.exit"
 docker inspect "$C" >"$OUT/$version-finished.json"
 docker rm -f "$C" >"$OUT/$version-cleanup.txt"
done
shasum -a 256 scripts/run-merge-recovery-soak.sh target/casper-driver-rebind/driver-before.sh target/aarch64-unknown-linux-musl/debug/casper-soak >"$OUT/inputs.sha256"
