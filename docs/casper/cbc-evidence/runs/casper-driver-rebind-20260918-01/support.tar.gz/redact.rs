use std::{env, fs, path::Path, process::Command};
fn digest(path: &Path) -> String {
    let output = Command::new("shasum").args(["-a", "256"]).arg(path).output().unwrap();
    assert!(output.status.success());
    String::from_utf8(output.stdout).unwrap().split_whitespace().next().unwrap().to_owned()
}
fn walk(root: &Path, directory: &Path, workspace: &str, home: &str) {
    let mut entries: Vec<_> = fs::read_dir(directory).unwrap().map(|entry| entry.unwrap()).collect();
    entries.sort_by_key(|entry| entry.file_name());
    for entry in entries {
        let path = entry.path();
        let kind = entry.file_type().unwrap();
        if kind.is_dir() { walk(root, &path, workspace, home); }
        else if kind.is_file() {
            let Ok(text) = String::from_utf8(fs::read(&path).unwrap()) else { continue; };
            let updated = text.replace(workspace, "[WORKSPACE_ROOT]").replace(home, "[HOME]");
            if text != updated {
                let before = digest(&path);
                fs::write(&path, updated).unwrap();
                println!("{}\t{}\t{}", path.strip_prefix(root).unwrap().display(), before, digest(&path));
            }
        }
    }
}
fn main() {
    let args: Vec<_> = env::args().collect();
    assert_eq!(args.len(), 4);
    walk(Path::new(&args[1]), Path::new(&args[1]), &args[2], &args[3]);
}
