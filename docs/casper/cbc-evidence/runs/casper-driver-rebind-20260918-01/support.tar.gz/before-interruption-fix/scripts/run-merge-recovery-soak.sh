#!/usr/bin/env bash
set -uo pipefail

DURATION_SECONDS="${SOAK_DURATION_SECONDS:?SOAK_DURATION_SECONDS is required}"
SYSTEM_INTEGRATION_DIR="${SYSTEM_INTEGRATION_DIR:?SYSTEM_INTEGRATION_DIR is required}"
OUTPUT_DIR="${SOAK_OUTPUT_DIR:-/tmp/merge-recovery-soak}"
TARGET_REF="${SOAK_TARGET_REF:-unknown}"
TARGET_SHA="${SOAK_TARGET_SHA:-unknown}"
TRIGGER_SOURCE="${SOAK_TRIGGER_SOURCE:-manual}"
SLOT_DELAY_SECONDS="${SOAK_SLOT_DELAY_SECONDS:-0}"
if ! [[ "$SLOT_DELAY_SECONDS" =~ ^[0-9]+$ ]]; then
	SLOT_DELAY_SECONDS=0
fi
if ! [[ "$DURATION_SECONDS" =~ ^[1-9][0-9]*$ ]]; then
	printf 'SOAK_DURATION_SECONDS must be a positive integer\n' >&2
	exit 2
fi
PROVIDERS=(docker subprocess)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export SOAK_HARNESS_BIN="${SOAK_HARNESS_BIN:-$SCRIPT_DIR/../target/debug/casper-soak}"
host_control() {
	"$SOAK_HARNESS_BIN" host-control "$@"
}
CASPER_MANIFEST_DIGEST=""
CASPER_RUNTIME=0
CASPER_TERMINATION=completed
casper_runtime() {
	bash "$SCRIPT_DIR/bench/casper-soak.sh" "$@" --output "$OUTPUT_DIR"
}
if [ -n "${SOAK_INPUT_DIR:-}" ]; then
	CASPER_ADMISSION="$(casper_runtime admit)"
	CASPER_STATUS=$?
	if [ "$CASPER_STATUS" -ne 0 ]; then
		printf '%s\n' "$CASPER_ADMISSION" >&2
		exit "$CASPER_STATUS"
	fi
	CASPER_RUNTIME=1
	CASPER_LIMIT="$(printf '%s' "$CASPER_ADMISSION" | jq -er .iterations)" || exit 2
	CASPER_SEGMENT_LIMIT="$(printf '%s' "$CASPER_ADMISSION" | jq -er .iterations_per_segment)" || exit 2
	CASPER_PROVIDER="$(printf '%s' "$CASPER_ADMISSION" | jq -er .provider)" || exit 2
	CASPER_DEADLINE="$(printf '%s' "$CASPER_ADMISSION" | jq -er .deadline)" || exit 2
fi
if [ -n "${SOAK_MANIFEST_PATH:-}" ] || [ -e "$OUTPUT_DIR/.casper-manifest.json" ] || [ -L "$OUTPUT_DIR/.casper-manifest.json" ]; then
	CASPER_MANIFEST_DIGEST="$(bash "$SCRIPT_DIR/bench/casper-soak.sh" bind --manifest "${SOAK_MANIFEST_PATH:-}" --output "$OUTPUT_DIR")" || exit 2
fi

# A soak is run as one or more segments so results can be published part-way
# through: a single 22h invocation cannot be interrupted to publish, but three
# consecutive invocations sharing one output directory can be. Every segment
# after the first resumes from this state file, so counters, the original start
# time and iteration numbering continue rather than restarting — restarting
# them would make each segment overwrite the previous one's iteration
# directories and silently discard its metrics.
mkdir -p "$OUTPUT_DIR"
STATE_FILE="$OUTPUT_DIR/.soak-state"
MANIFEST_BOUND=0
RUNTIME_BOUND=0
if [ "$CASPER_RUNTIME" -eq 1 ]; then
	exec 9>"$OUTPUT_DIR/.casper-lock" || exit 2
	flock -n 9 || exit 2
fi
INFLIGHT_ITERATION=0
INFLIGHT_BENCHMARK=0
if [ -e "$STATE_FILE" ] || [ -L "$STATE_FILE" ]; then
	if [ ! -f "$STATE_FILE" ] || [ -L "$STATE_FILE" ] || [ "$(wc -c <"$STATE_FILE")" -gt 4096 ]; then
		printf 'The saved soak state must be a regular file of at most 4096 bytes.\n' >&2
		exit 2
	fi
	saved_keys=""
	while IFS= read -r saved_line || [ -n "$saved_line" ]; do
		saved_key="${saved_line%%=*}"
		saved_value="${saved_line#*=}"
		case "$saved_key" in
			STARTED_AT|ITERATIONS|FAILURES|SEGMENT|BENCH_SEGMENTS|BENCH_FAILURES|INFLIGHT_ITERATION|INFLIGHT_BENCHMARK|MANIFEST_BOUND|RUNTIME_BOUND) ;;
			*) printf 'The saved soak state contains an unknown field.\n' >&2; exit 2 ;;
		esac
		if [[ " $saved_keys " == *" $saved_key "* ]] ||
			! [[ "$saved_value" =~ ^(0|[1-9][0-9]*)$ ]] || [ "${#saved_value}" -gt 18 ]; then
			printf 'The saved soak state contains a duplicate or invalid numeric field.\n' >&2
			exit 2
		fi
		saved_keys+=" $saved_key"
		printf -v "$saved_key" '%s' "$saved_value"
	done <"$STATE_FILE"
	for saved_key in STARTED_AT ITERATIONS FAILURES SEGMENT; do
		if [[ " $saved_keys " != *" $saved_key "* ]]; then
			printf 'The saved soak state lacks a required field.\n' >&2
			exit 2
		fi
	done
	if [ "$STARTED_AT" -lt 1 ] || [ "$SEGMENT" -lt 1 ]; then
		printf 'The saved start time and segment must be positive.\n' >&2
		exit 2
	fi
	if { [ "$MANIFEST_BOUND" -ne 0 ] && [ "$MANIFEST_BOUND" -ne 1 ]; } ||
		{ [ "$MANIFEST_BOUND" -eq 1 ] && [ -z "$CASPER_MANIFEST_DIGEST" ]; } ||
		{ [ "$MANIFEST_BOUND" -eq 0 ] && [ -n "$CASPER_MANIFEST_DIGEST" ]; }; then
		printf 'The saved manifest binding is missing or invalid.\n' >&2
		exit 2
	fi
	if [ "$RUNTIME_BOUND" -ne "$CASPER_RUNTIME" ]; then
		printf 'The saved profile execution mode differs.\n' >&2
		exit 2
	fi
	SEGMENT="$((SEGMENT + 1))"
	printf 'resuming soak: segment %s, %s iterations so far, started %s\n' \
		"$SEGMENT" "$ITERATIONS" "$(date -d "@$STARTED_AT" '+%F %T %Z' 2>/dev/null || date -r "$STARTED_AT")"
else
	STARTED_AT="$(date +%s)"
	ITERATIONS=0
	FAILURES=0
	SEGMENT=1
fi
if ! [[ "$INFLIGHT_ITERATION" =~ ^[012]$ ]]; then
	printf 'The saved iteration state must be 0, 1, or 2.\n' >&2
	exit 2
fi
if ! [[ "$INFLIGHT_BENCHMARK" =~ ^[012]$ ]]; then
	printf 'The saved benchmark state must be 0, 1, or 2.\n' >&2
	exit 2
fi

# An absolute deadline lets the caller end a segment on a wall-clock boundary
# (a Pacific checkpoint) rather than after a fixed span. Without one, the
# deadline is the full requested duration measured from the original start, so
# a final segment needs no deadline of its own.
# Whether this segment ends on a checkpoint boundary. The caller publishes a
# checkpoint only when it passed a deadline, so this also decides whether an
# on-demand checkpoint is possible here at all — see the signal handling below.
HAS_CHECKPOINT_BOUNDARY=0
if [ -n "${SOAK_DEADLINE_EPOCH:-}" ]; then
	if ! [[ "$SOAK_DEADLINE_EPOCH" =~ ^[1-9][0-9]*$ ]]; then
		printf 'SOAK_DEADLINE_EPOCH must be a positive integer\n' >&2
		exit 2
	fi
	HAS_CHECKPOINT_BOUNDARY=1
	DEADLINE="$SOAK_DEADLINE_EPOCH"
	# Never run past the overall budget, whatever the caller asked for.
	if [ "$DEADLINE" -gt "$((STARTED_AT + DURATION_SECONDS))" ]; then
		DEADLINE="$((STARTED_AT + DURATION_SECONDS))"
	fi
else
	DEADLINE="$((STARTED_AT + DURATION_SECONDS))"
fi

# An earlier segment may have ended the soak deliberately — the branch under
# test advanced, so the pinned image is now testing history. Later segments
# must not restart it: without this each remaining segment would soak on to its
# own deadline, undoing the early exit and burning the runner time it was meant
# to save. The rollup below still runs, so the final segment produces a summary
# to publish.
if [ -f "$OUTPUT_DIR/early-exit.txt" ]; then
	printf 'soak already ended (%s); this segment does no work\n' \
		"$(head -1 "$OUTPUT_DIR/early-exit.txt" 2>/dev/null || echo 'reason unrecorded')"
	DEADLINE=0
fi

if [ "$CASPER_RUNTIME" -eq 0 ] && [ -n "$CASPER_MANIFEST_DIGEST" ] && [ "$(date +%s)" -lt "$DEADLINE" ]; then
	printf 'Casper profile dispatch remains blocked until its adapter is qualified.\n' >&2
	exit 2
fi

CASPER_SEGMENT_START="$ITERATIONS"
if [ "$CASPER_RUNTIME" -eq 1 ]; then
	if [ "$INFLIGHT_ITERATION" -eq 0 ]; then
		casper_runtime history --iteration "$ITERATIONS" --failures "$FAILURES" || exit 2
	fi
	[ "$CASPER_DEADLINE" -ge "$DEADLINE" ] || DEADLINE="$CASPER_DEADLINE"
	if [ -e "$OUTPUT_DIR/finalize-requested" ] || [ "$ITERATIONS" -ge "$CASPER_LIMIT" ]; then
		DEADLINE=0
	fi
fi

# Harness telemetry roots. Subprocess sessions write monitor artifacts and
# node logs under .subprocess-data/; docker sessions write them under
# log-archive/ (the provider's host-visible per-session dir —
# DockerProvider.monitor_output_dir in system-integration). The data/ root
# remains for harness versions that write logs there. Every search for monitor
# output, node logs, breach markers or SOAK_METRIC lines must cover all roots.
# Created up front so multi-root find never ENOENTs.
HARNESS_TELEMETRY_DIRS=(
	"$SYSTEM_INTEGRATION_DIR/integration-tests/data"
	"$SYSTEM_INTEGRATION_DIR/integration-tests/log-archive"
	"$SYSTEM_INTEGRATION_DIR/integration-tests/.subprocess-data"
)
mkdir -p "${HARNESS_TELEMETRY_DIRS[@]}"
RUN_BENCHMARKS="${SOAK_RUN_BENCHMARKS:-false}"
BENCH_EVERY="${SOAK_BENCH_EVERY:-4}"
BENCH_DURATION="${SOAK_BENCH_DURATION:-300}"
BENCH_RATE="${SOAK_BENCH_RATE:-2}"
NODE_REPO_DIR="${SOAK_NODE_REPO_DIR:-}"
# Carried over by the state file when resuming a later segment.
BENCH_SEGMENTS="${BENCH_SEGMENTS:-0}"
BENCH_FAILURES="${BENCH_FAILURES:-0}"
# Minimum seconds before a move of the branch under test may end the soak.
# 0 disables merge-triggered exit entirely (the weekend soak sets this).
MERGE_EXIT_MIN_SECONDS="${SOAK_MERGE_EXIT_MIN_SECONDS:-0}"
EARLY_EXIT_REASON=""

# Total-node-RSS watchdog ceiling passed to the harness (--rss-ceiling-mb).
# The harness default is 5000MB — sized for laptops, not the 32GB soak VM:
# the 6-node shard legitimately peaks ~10GB under test_load, and the default
# killed every iteration of run 30516534214 ~130s in. Size to the host
# instead, so the watchdog stays on to catch a real leak before swap-thrash
# freezes the VM without ever firing on normal load.
#
# The reserve is 12GB, not the 8GB first tried. 8GB permits a 24GB node
# working set on the 32GB VM, which puts the *kernel* OOM killer ahead of this
# watchdog: at that point the harness has not breached, so the kernel picks a
# victim by oom_score and Runner.Worker is a plausible one — a runner that
# vanishes mid-step with no log and no failed step, which is exactly what
# happened to run 30590630059. Reserving 12GB caps nodes at 20GB, still ~2x
# the observed 10.8GB peak, and keeps the attributable failure ahead of the
# unattributable one. SOAK_RSS_CEILING_MB overrides; 0 disables the watchdog.
HOST_RESERVE_MB="${SOAK_HOST_RESERVE_MB:-12288}"
if ! [[ "$HOST_RESERVE_MB" =~ ^[0-9]+$ ]]; then
	printf 'SOAK_HOST_RESERVE_MB must be a non-negative integer\n' >&2
	exit 2
fi
MEM_TOTAL_MB="$(awk '/^MemTotal:/ {print int($2 / 1024)}' /proc/meminfo 2>/dev/null || echo 0)"
RSS_CEILING_MB="${SOAK_RSS_CEILING_MB:-}"
if [ -n "$RSS_CEILING_MB" ]; then
	if ! [[ "$RSS_CEILING_MB" =~ ^[0-9]+$ ]]; then
		printf 'SOAK_RSS_CEILING_MB must be a non-negative integer\n' >&2
		exit 2
	fi
else
	RSS_CEILING_MB="$((MEM_TOTAL_MB - HOST_RESERVE_MB))"
	if [ "$RSS_CEILING_MB" -lt 5000 ]; then
		RSS_CEILING_MB=5000
	fi
fi

# Host-available-RAM floor passed to the harness (--host-free-floor-mb). The
# harness default of 2000MB only fires once the machine is already at the
# edge, by which point the kernel may have picked a victim first; 6000MB on the
# 32GB soak VM makes the harness kill the nodes and report an attributable
# breach while there is still room. This is a backstop to the RSS ceiling
# above, catching pressure the ceiling is blind to (docker overhead, the runner
# agent itself). Enforced on subprocess iterations only — docker iterations
# rely on the ceiling.
#
# Scaled to MemTotal/4 and capped at 6000, because a flat 6000 is incoherent on
# a small host: on an 8GB laptop it demands 6GB free while the ceiling still
# permits a 5GB shard, so the floor would breach on contact. Quartering keeps
# the same intent (fire well before the kernel does) at every size, and lands
# on 2048 at 8GB — effectively the harness's own 2000 default.
# SOAK_HOST_FREE_FLOOR_MB overrides; 0 disables the floor.
HOST_FREE_FLOOR_MB="${SOAK_HOST_FREE_FLOOR_MB:-}"
if [ -n "$HOST_FREE_FLOOR_MB" ]; then
	if ! [[ "$HOST_FREE_FLOOR_MB" =~ ^[0-9]+$ ]]; then
		printf 'SOAK_HOST_FREE_FLOOR_MB must be a non-negative integer\n' >&2
		exit 2
	fi
else
	HOST_FREE_FLOOR_MB="$((MEM_TOTAL_MB / 4))"
	if [ "$HOST_FREE_FLOOR_MB" -gt 6000 ]; then
		HOST_FREE_FLOOR_MB=6000
	fi
fi

DISK_INTEGER_MAX=9223372036854775807

disk_setting_decimal() {
	local LC_ALL=C value="$1"
	[[ "$value" =~ ^[0-9]+$ ]] || return 1
	value="${value#"${value%%[!0]*}"}"
	value="${value:-0}"
	if [ "${#value}" -gt 19 ] || { [ "${#value}" -eq 19 ] && [[ "decimal:$value" > "decimal:$DISK_INTEGER_MAX" ]]; }; then
		return 1
	fi
	printf '%s\n' "$value"
}

# Disk twin of the memory floor (issue #378). Weekend runs 33254400407 and
# 33278321865 filled the soak VM's default ~47GB boot volume 9-12h in: the
# runner worker died on ENOSPC writing its own _diag log, and the last
# iteration before death failed "121 deploy(s) not finalized within 45s" —
# a full disk masquerading as a finalization regression. Memory had a
# guardian, warn band and durable last words; disk had nothing.
# SOAK_DISK_FREE_FLOOR_MB overrides; 0 disables the floor.
if ! DISK_FREE_FLOOR_MB="$(disk_setting_decimal "${SOAK_DISK_FREE_FLOOR_MB:-4096}")"; then
	printf 'SOAK_DISK_FREE_FLOOR_MB must be a non-negative integer no larger than 9223372036854775807\n' >&2
	exit 2
fi
# Hygiene runs when free space sinks into floor+band, BEFORE the floor
# breaches: pruning between iterations is cheap, while a breach ends the run.
if ! DISK_HYGIENE_BAND_MB="$(disk_setting_decimal "${SOAK_DISK_HYGIENE_BAND_MB:-4096}")"; then
	printf 'SOAK_DISK_HYGIENE_BAND_MB must be a non-negative integer no larger than 9223372036854775807\n' >&2
	exit 2
fi
if [ "$DISK_HYGIENE_BAND_MB" -gt "$((DISK_INTEGER_MAX - DISK_FREE_FLOOR_MB))" ]; then
	printf 'SOAK_DISK_FREE_FLOOR_MB plus SOAK_DISK_HYGIENE_BAND_MB must not exceed 9223372036854775807\n' >&2
	exit 2
fi
# Where harness sessions leave their compose and genesis files (the
# `test-*` sweep below), and where the runner keeps _diag and _work. Both are
# overridable so the driver test can sweep and measure a private tree instead
# of the developer's real /tmp.
SOAK_TMP_ROOT="${SOAK_TMP_ROOT:-/tmp}"
SOAK_RUNNER_ROOT="${SOAK_RUNNER_ROOT:-/opt/actions-runner}"
DISK_STOP_SECONDS="${SOAK_DISK_STOP_SECONDS:-2}"
if ! [[ "$DISK_STOP_SECONDS" =~ ^[1-5]$ ]]; then
	printf 'SOAK_DISK_STOP_SECONDS must be an integer from 1 through 5\n' >&2
	exit 2
fi
GUARDIAN_MAX_SILENCE_SECONDS="${SOAK_GUARDIAN_MAX_SILENCE_SECONDS:-10}"
if ! [[ "$GUARDIAN_MAX_SILENCE_SECONDS" =~ ^([89]|[12][0-9]|30)$ ]]; then
	printf 'SOAK_GUARDIAN_MAX_SILENCE_SECONDS must be an integer from 8 through 30\n' >&2
	exit 2
fi
DISK_HYGIENE_SECONDS="${SOAK_DISK_HYGIENE_SECONDS:-10}"
if ! [[ "$DISK_HYGIENE_SECONDS" =~ ^([1-9]|[12][0-9]|30)$ ]]; then
	printf 'SOAK_DISK_HYGIENE_SECONDS must be an integer from 1 through 30\n' >&2
	exit 2
fi
DISK_DIAGNOSTIC_SECONDS="${SOAK_DISK_DIAGNOSTIC_SECONDS:-10}"
if ! [[ "$DISK_DIAGNOSTIC_SECONDS" =~ ^([1-9]|10)$ ]]; then
	printf 'SOAK_DISK_DIAGNOSTIC_SECONDS must be an integer from 1 through 10\n' >&2
	exit 2
fi
CONTAINMENT="${SOAK_CONTAINMENT:-unmanaged}"
if [ "$CONTAINMENT" != unmanaged ] && [ "$CONTAINMENT" != required ]; then
	printf 'SOAK_CONTAINMENT must be unmanaged or required\n' >&2
	exit 2
fi
RUN_DOMAIN_RECORD="${SOAK_RUN_DOMAIN_RECORD:-}"
EMERGENCY_DEADLINE_SECONDS="${SOAK_EMERGENCY_DEADLINE_SECONDS:-60}"
if ! [[ "$EMERGENCY_DEADLINE_SECONDS" =~ ^([5-9]|[1-9][0-9]|[1-5][0-9][0-9]|600)$ ]]; then
	printf 'SOAK_EMERGENCY_DEADLINE_SECONDS must be an integer from 5 through 600\n' >&2
	exit 2
fi
EMERGENCY_DEADLINE_EPOCH=""
emergency_start() {
	[ -n "$EMERGENCY_DEADLINE_EPOCH" ] && return 0
	EMERGENCY_DEADLINE_EPOCH="$(($(date +%s) + EMERGENCY_DEADLINE_SECONDS))"
	printf 'emergency response started; composed deadline %ss\n' "$EMERGENCY_DEADLINE_SECONDS" >"$OUTPUT_DIR/emergency-started.txt"
}
emergency_remaining() {
	local remaining
	if [ -z "$EMERGENCY_DEADLINE_EPOCH" ]; then
		printf '%s\n' "$EMERGENCY_DEADLINE_SECONDS"
		return 0
	fi
	remaining="$((EMERGENCY_DEADLINE_EPOCH - $(date +%s)))"
	[ "$remaining" -gt 0 ] || remaining=0
	printf '%s\n' "$remaining"
}
session_bounded() {
	local seconds="$1" pid watchdog status=0
	shift
	setsid "$@" &
	pid=$!
	setsid bash -c 'sleep "$1"; kill -TERM -- "-$2" 2>/dev/null; sleep 1; kill -KILL -- "-$2" 2>/dev/null' \
		bash "$seconds" "$pid" >/dev/null 2>&1 &
	watchdog=$!
	wait "$pid" || status=$?
	kill -KILL -- "-$watchdog" 2>/dev/null || true
	wait "$watchdog" 2>/dev/null || true
	return "$status"
}
publish_record() {
	local echo_record=0 target tmp
	if [ "$1" = -t ]; then
		echo_record=1
		shift
	fi
	target="$1"
	shift
	[ "$#" -gt 0 ] || return 2
	tmp="$target.tmp.$BASHPID"
	if ! "$@" >"$tmp"; then
		rm -f "$tmp"
		return 1
	fi
	[ "$echo_record" -eq 0 ] || cat "$tmp"
	mv -f "$tmp" "$target"
}
publication_budget() {
	local remaining
	if [ -n "$EMERGENCY_DEADLINE_EPOCH" ]; then
		remaining="$(emergency_remaining)"
		[ "$remaining" -le 5 ] || remaining=5
		[ "$remaining" -ge 1 ] || remaining=1
		printf '%s\n' "$remaining"
	else
		printf '30\n'
	fi
}
reap_publication() {
	local budget sp waited=0
	[ -n "$OUTPUT_DIR" ] || return 0
	budget="$(publication_budget)"
	sync "$OUTPUT_DIR" &
	sp=$!
	while kill -0 "$sp" 2>/dev/null && [ "$waited" -lt "$budget" ]; do
		sleep 1
		waited=$((waited + 1))
	done
	if kill -0 "$sp" 2>/dev/null; then
		printf 'durability_unconfirmed after %ss at %s\n' "$budget" "$(date -u +%FT%TZ)" >>"$OUTPUT_DIR/publication-unconfirmed.txt"
		return 3
	fi
	wait "$sp" 2>/dev/null || true
}
process_identity() {
	local stat
	IFS= read -r stat 2>/dev/null <"/proc/$1/stat" || return 1
	stat="${stat##*) }"
	# shellcheck disable=SC2086
	set -- $stat
	[ "$1" != Z ] || return 1
	[[ "${20}" =~ ^[0-9]+$ ]] || return 1
	printf '%s\n' "${20}"
}
run_domain_verified() {
	[ "$CONTAINMENT" = required ] || return 0
	host_control verify-domain "$RUN_DOMAIN_RECORD"
}

# Free MB on the filesystem the soak actually fills. OUTPUT_DIR, the harness
# session dirs and the runner's _diag all live on the one boot volume, so one
# probe stands for them all. Prints nothing and fails unless the probe yields
# a plain number: an unparseable df must read as "no sample", never feed
# arithmetic garbage into the guardian.
disk_free_mb() {
	local mb
	mb="$(timeout --signal=TERM --kill-after=1 2 df -Pm "$OUTPUT_DIR" 2>/dev/null |
		awk 'NR == 2 && $4 ~ /^[0-9]+$/ { print int($4) }')" || return 1
	[[ "$mb" =~ ^[0-9]+$ ]] || return 1
	printf '%s\n' "$mb"
}

guardian_clock_seconds() {
	local uptime _unused
	read -r uptime _unused </proc/uptime || return 1
	uptime="${uptime%%.*}"
	[[ "$uptime" =~ ^[0-9]{1,12}$ ]] || return 1
	printf '%s\n' "$((10#$uptime))"
}

guardian_record_progress() {
	local now
	now="$(guardian_clock_seconds)" || return 1
	printf '%s\n' "$now" >"$HOST_GUARDIAN_PROGRESS.tmp" &&
		mv -f "$HOST_GUARDIAN_PROGRESS.tmp" "$HOST_GUARDIAN_PROGRESS"
}

guardian_progress_fresh() {
	local now last
	now="$(guardian_clock_seconds)" || return 1
	last="$(<"$HOST_GUARDIAN_PROGRESS")" || return 1
	[[ "$last" =~ ^[0-9]{1,12}$ ]] || return 1
	last="$((10#$last))"
	[ "$last" -le "$now" ] && [ "$((now - last))" -le "$GUARDIAN_MAX_SILENCE_SECONDS" ]
}

stop_owned_host_writers() {
	host_control stop-owned "$SOAK_WRITER_OWNER"
}

mark_owned_oom_preferred() {
	host_control prefer-oom "$SOAK_WRITER_OWNER"
}

stop_node_writer_commands() {
	local selection="$1"
	shift
	local cid owner ids status=0
	stop_owned_host_writers || status=1
	ids="$(docker ps "$selection" --no-trunc --filter "label=io.f1r3fly.soak.owner=$SOAK_WRITER_OWNER" 2>/dev/null)" || return 1
	while IFS= read -r cid; do
		[ -n "$cid" ] || continue
		if ! [[ "$cid" =~ ^[a-f0-9]{64}$ ]]; then
			status=1
			continue
		fi
		owner="$(docker inspect --format '{{index .Config.Labels "io.f1r3fly.soak.owner"}}' "$cid" 2>/dev/null)" || {
			status=1
			continue
		}
		[ "$owner" = "$SOAK_WRITER_OWNER" ] || {
			status=1
			continue
		}
		docker "$@" "$cid" 2>/dev/null || status=1
	done <<<"$ids"
	return "$status"
}

stop_node_writers() (
	export SOAK_WRITER_OWNER
	export -f host_control stop_owned_host_writers stop_node_writer_commands
	timeout --signal=TERM --kill-after=1 "$DISK_STOP_SECONDS" \
		bash -c 'trap "" TERM; stop_node_writer_commands "$@"' bash "$@"
)

crash_monitor() {
	local driver="$1" identity="$2" directory="$3" output="$4" status=0
	if ! host_control watch "$driver" "$identity" "$directory/ready"; then
		printf 'Driver exit monitoring is unconfirmed.\n' >"$output/writer-stop-failure.txt" 2>/dev/null || true
		stop_node_writers -q kill || true
		printf '2\n' >"$directory/exit-code.txt"
		exit 2
	fi
	if host_control handled "$directory/handled-exit" >/dev/null 2>&1; then exit 0; fi
	stop_node_writers -q kill || status=$?
	if [ "$status" -ne 0 ]; then
		printf 'Writer termination is unconfirmed after the driver exited.\n' >"$output/writer-stop-failure.txt" 2>/dev/null || true
	fi
	printf '%s\n' "$status" >"$directory/exit-code.txt"
	exit "$status"
}

start_crash_monitor() {
	local directory monitor identity _attempt
	identity="$(process_identity "$$")" || return 1
	directory="$(mktemp -d "$OUTPUT_DIR/.crash-monitor.XXXXXXXX")" || return 1
	CRASH_MONITOR_DIR="$directory"
	(
		export SOAK_WRITER_OWNER DISK_STOP_SECONDS
		export -f host_control stop_owned_host_writers stop_node_writer_commands stop_node_writers crash_monitor
		exec setsid bash -c 'crash_monitor "$@"' soak-crash-monitor "$$" "$identity" "$directory" "$OUTPUT_DIR"
	) >"$directory/monitor.log" 2>&1 &
	monitor=$!
	CRASH_MONITOR_PID="$monitor"
	for _attempt in {1..100}; do
		kill -0 "$monitor" 2>/dev/null || return 1
		[ ! -s "$directory/ready" ] || return 0
		sleep 0.05
	done
	return 1
}

reclaim_disk_space_commands() {
	local before after status=0
	set -o pipefail
	before="$(disk_free_mb)" || before=""
	if command -v docker >/dev/null 2>&1; then
		docker ps -aq --filter status=exited --filter 'name=rnode.' 2>/dev/null |
			xargs -r docker inspect >/dev/null 2>&1 || {
			status=1
			printf 'disk hygiene: container inspection failed\n' >&2
		}
		docker network ls -q >/dev/null 2>&1 || {
			status=1
			printf 'disk hygiene: network inspection failed\n' >&2
		}
		docker image ls -q >/dev/null 2>&1 || {
			status=1
			printf 'disk hygiene: image inspection failed\n' >&2
		}
		docker system df >/dev/null 2>&1 || {
			status=1
			printf 'disk hygiene: storage inspection failed\n' >&2
		}
	fi
	printf 'disk hygiene: Docker resources and temporary sessions retained because ownership is unconfirmed\n'
	after="$(disk_free_mb)" || after=""
	printf 'disk hygiene: %sMB free -> %sMB free\n' "${before:-?}" "${after:-?}"
	return "$status"
}

reclaim_disk_space() (
	export OUTPUT_DIR SOAK_TMP_ROOT
	export -f disk_free_mb reclaim_disk_space_commands
	timeout --signal=TERM --kill-after=1 "$DISK_HYGIENE_SECONDS" \
		bash -c 'trap "" TERM; reclaim_disk_space_commands'
)

# Run a command under a wall-clock bound where timeout(1) exists, and bare
# where it does not (macOS without coreutils). Attribution is best-effort and
# must never hold up the guard it serves.
bounded() {
	local seconds="$1"
	shift
	if command -v timeout >/dev/null 2>&1; then
		timeout --foreground "$seconds" "$@"
	else
		"$@"
	fi
}

# Where the space went. df says how much is left; only du says who took it.
# Weekend runs 33939315110, 33978505238 and 34056342543 died of ENOSPC after
# the floor fired, and the last three hygiene passes before the third death
# reclaimed nothing (7956 -> 7956MB, 7596 -> 7596MB, 7355 -> 7355MB): the
# growth was outside everything reclaim_disk_space sweeps, and nothing on the
# terminated VM could say where. This prints on every hygiene pass (stdout
# reaches the workflow log even when the VM dies later), into the breach
# evidence on every disk stop, and from the guardian on a breach. Metadata
# walks of the harness and runner roots finish in seconds; docker's own
# accounting stands in for /var/lib/docker, which du would crawl for minutes.
disk_usage_roots() {
	printf '%s\n' "$OUTPUT_DIR" "${HARNESS_TELEMETRY_DIRS[@]}" \
		"$SOAK_RUNNER_ROOT/_diag" "$SOAK_RUNNER_ROOT/_work"
	find "$SOAK_TMP_ROOT" -maxdepth 1 -name 'test-*' 2>/dev/null || true
}

disk_usage_snapshot_data() {
	local root
	df -Pm "$OUTPUT_DIR" 2>/dev/null || true
	while IFS= read -r root; do
		[ -d "$root" ] || continue
		bounded 20 du -sm "$root" 2>/dev/null ||
			printf '?\t%s (du timed out)\n' "$root"
	done < <(disk_usage_roots)
	if command -v docker >/dev/null 2>&1; then
		bounded 20 docker system df 2>/dev/null || true
	fi
}

# One line of the same attribution, short enough to ride in an OCI freeform
# tag beside the guardian's last words (256 chars per value). Per-root
# timeouts are tight because this runs between killing the writers and the
# stamp: the VMs above died ~20s after the stamp, so every second spent here
# is a second the stamp may not get.
disk_usage_tag_summary() {
	local label root mb tmp_mb=0 summary=""
	for label in out:"$OUTPUT_DIR" data:"${HARNESS_TELEMETRY_DIRS[0]}" \
		arch:"${HARNESS_TELEMETRY_DIRS[1]}" sub:"${HARNESS_TELEMETRY_DIRS[2]}" \
		diag:"$SOAK_RUNNER_ROOT/_diag"; do
		root="${label#*:}"
		[ -d "$root" ] || continue
		mb="$(bounded 3 du -sm "$root" 2>/dev/null | awk '{ print $1 }')"
		[[ "$mb" =~ ^[0-9]+$ ]] || mb='?'
		summary="${summary}${label%%:*}=${mb}M,"
	done
	while IFS= read -r root; do
		mb="$(bounded 3 du -sm "$root" 2>/dev/null | awk '{ print $1 }')"
		[[ "$mb" =~ ^[0-9]+$ ]] && tmp_mb=$((tmp_mb + mb))
	done < <(find "$SOAK_TMP_ROOT" -maxdepth 1 -name 'test-*' 2>/dev/null || true)
	summary="${summary}tmp=${tmp_mb}M"
	if command -v docker >/dev/null 2>&1; then
		summary="${summary},dock=$(bounded 5 docker system df --format '{{.Type}}={{.Size}}' 2>/dev/null |
			tr -d ' ' | paste -sd '+' - || true)"
	fi
	printf '%s\n' "$summary"
}

disk_diagnostics_bounded() {
	local definitions
	definitions="$(
		declare -p OUTPUT_DIR HARNESS_TELEMETRY_DIRS SOAK_TMP_ROOT SOAK_RUNNER_ROOT
		declare -f bounded disk_usage_roots disk_usage_snapshot_data disk_usage_tag_summary disk_guardian_diagnostics
		declare -f guardian_stamp_health_tag || true
	)"
	local seconds remaining
	seconds="$DISK_DIAGNOSTIC_SECONDS"
	remaining="$(emergency_remaining)"
	[ "$remaining" -ge "$seconds" ] || seconds="$remaining"
	[ "$seconds" -gt 0 ] || return 1
	session_bounded "$seconds" bash -c "$definitions"$'\n''"$@"' bash "$@"
}

disk_usage_snapshot() {
	disk_diagnostics_bounded disk_usage_snapshot_data
}

disk_guardian_diagnostics() {
	guardian_stamp_health_tag disk-breach "$1" "$(disk_usage_tag_summary)"
	disk_usage_snapshot_data >"$OUTPUT_DIR/disk-breach-usage.txt" 2>/dev/null || true
}

# The floor is only as good as the probe behind it: an OUTPUT_DIR that df
# cannot stat would turn every later disk check into a silent no-op and the
# soak would run believing itself protected. Refuse to start instead;
# SOAK_DISK_FREE_FLOOR_MB=0 is the explicit opt-out.
if [ "$DISK_FREE_FLOOR_MB" -gt 0 ] && ! disk_free_mb >/dev/null; then
	printf 'cannot read free disk space for %s; fix the path or set SOAK_DISK_FREE_FLOOR_MB=0 to run without the disk floor\n' \
		"$OUTPUT_DIR" >&2
	exit 2
fi

printf 'Soak host protection: node RSS ceiling=%sMB; host free floor=%sMB; disk free floor=%sMB (hygiene band +%sMB)\n' \
	"$RSS_CEILING_MB" "$HOST_FREE_FLOOR_MB" "$DISK_FREE_FLOOR_MB" "$DISK_HYGIENE_BAND_MB"

if [ "$RUN_BENCHMARKS" = "true" ] && [ -z "$NODE_REPO_DIR" ]; then
	printf 'SOAK_NODE_REPO_DIR is required when SOAK_RUN_BENCHMARKS=true\n' >&2
	exit 2
fi

# Declared version of the code under test. The workflow passes the ref and the
# sha but not the version, and "which version was soaked" is what a reader of
# the dashboard actually wants — a sha answers "which commit", not "which
# release". This is the same value the Docker LABEL and the published image tag
# carry, so a dashboard row can be matched against a pulled image.
#
# Takes the first `version = "..."` line, which is the same line release.yml
# bumps (`0,/^version = ".*"/`), so the two cannot disagree about which one is
# the package version. Degrades to "unknown" and never fails: a missing version
# string must not abort a soak, and every consumer downstream treats it as
# optional.
#
# Deliberately NOT scripts/version.sh, which resolves the newest `v*` tag in the
# current repo. That answers "what is the latest release", not "what is this
# commit" — a dev soak would report a tag that postdates or has nothing to do
# with the code under test — and it needs tags present, which a shallow
# node-under-test checkout does not guarantee. Do not consolidate the two.
VERSION="unknown"
if [ -n "$NODE_REPO_DIR" ] && [ -f "$NODE_REPO_DIR/node/Cargo.toml" ]; then
	parsed_version="$(awk -F'"' '/^version = "/ { print $2; exit }' \
		"$NODE_REPO_DIR/node/Cargo.toml" 2>/dev/null || true)"
	[ -n "$parsed_version" ] && VERSION="$parsed_version"
fi

emit_soak_state() {
	if [ "$CASPER_RUNTIME" -eq 1 ]; then
		printf 'RUNTIME_BOUND=1\n'
	fi
	if [ -n "$CASPER_MANIFEST_DIGEST" ]; then
		printf 'MANIFEST_BOUND=1\n'
	fi
	printf 'STARTED_AT=%s\n' "$STARTED_AT"
	printf 'ITERATIONS=%s\n' "$ITERATIONS"
	printf 'INFLIGHT_ITERATION=%s\n' "$INFLIGHT_ITERATION"
	printf 'INFLIGHT_BENCHMARK=%s\n' "$INFLIGHT_BENCHMARK"
	printf 'FAILURES=%s\n' "$FAILURES"
	printf 'BENCH_SEGMENTS=%s\n' "$BENCH_SEGMENTS"
	printf 'BENCH_FAILURES=%s\n' "$BENCH_FAILURES"
	printf 'SEGMENT=%s\n' "$SEGMENT"
}

persist_soak_state() {
	local checkpoint_state="$OUTPUT_DIR/.soak-checkpoint-state.json"
	mkdir -p "$OUTPUT_DIR"
	publish_record "$STATE_FILE" emit_soak_state || return 1
	publish_record "$checkpoint_state" jq -n \
		--arg target_ref "$TARGET_REF" \
		--arg target_sha "$TARGET_SHA" \
		--arg trigger_source "$TRIGGER_SOURCE" \
		--arg manifest_digest "$CASPER_MANIFEST_DIGEST" \
		--argjson slot_delay "$SLOT_DELAY_SECONDS" \
		--arg version "$VERSION" \
		--argjson started_at "$STARTED_AT" \
		--argjson requested_seconds "$DURATION_SECONDS" \
		--argjson iterations "$ITERATIONS" \
		--argjson failures "$FAILURES" \
		--argjson bench_segments "$BENCH_SEGMENTS" \
		--argjson bench_failures "$BENCH_FAILURES" \
		'{target_ref: $target_ref, target_sha: $target_sha,
      trigger_source: $trigger_source, slot_delay_seconds: $slot_delay,
      manifest_digest: (if $manifest_digest == "" then null else $manifest_digest end),
      version: $version, started_at: $started_at,
      requested_seconds: $requested_seconds, iterations: $iterations,
      failures: $failures, bench_segments: $bench_segments,
      bench_failures: $bench_failures}'
}

if [ "$INFLIGHT_ITERATION" -eq 1 ]; then
	FAILURES="$((FAILURES + 1))"
	INFLIGHT_ITERATION=2
fi
if [ "$INFLIGHT_ITERATION" -eq 2 ]; then
	EARLY_EXIT_REASON="interrupted_iteration"
	DEADLINE=0
	publish_record "$OUTPUT_DIR/early-exit.txt" printf 'interrupted_iteration: iteration %s has no committed outcome. Writer termination is unconfirmed.\n' \
		"$ITERATIONS" || exit 2
fi
if [ "$INFLIGHT_BENCHMARK" -eq 1 ]; then
	FAILURES="$((FAILURES + 1))"
	BENCH_FAILURES="$((BENCH_FAILURES + 1))"
	INFLIGHT_BENCHMARK=2
fi
if [ "$INFLIGHT_BENCHMARK" -eq 2 ]; then
	EARLY_EXIT_REASON="interrupted_benchmark"
	DEADLINE=0
	publish_record "$OUTPUT_DIR/early-exit.txt" printf 'interrupted_benchmark: benchmark %s has no committed outcome. Writer termination is unconfirmed.\n' \
		"$BENCH_SEGMENTS" || exit 2
fi
persist_soak_state || exit 2

# Peak total node RSS for this iteration, from the newest harness
# resource-timeseries.csv written after the iteration's start marker
# (columns: elapsed_s,node,memory_mb,cpu_percent,memory_limit_mb; the
# __system__ row is host state, not node RSS). Empty output when absent.
iteration_rss_peak_mb() {
	local iteration_dir="$1" ts_csv="$1/resource-timeseries.csv"
	if [ ! -s "$ts_csv" ]; then
		ts_csv="$(find "${HARNESS_TELEMETRY_DIRS[@]}" \
			-name resource-timeseries.csv -newer "$iteration_dir/.started" -print0 2>/dev/null |
			xargs -0 -r ls -t 2>/dev/null | head -1 || true)"
		[ -n "$ts_csv" ] || return 0
		cp "$ts_csv" "$iteration_dir/resource-timeseries.csv" 2>/dev/null || true
	fi
	awk -F, 'NR > 1 && $2 != "__system__" { sum[$1] += $3 }
           END { max = 0; for (t in sum) if (sum[t] > max) max = sum[t]
                 if (max > 0) printf "%.0f\n", max }' "$ts_csv" 2>/dev/null || true
}

# Peak total node CPU (%) for this iteration, same resource-timeseries.csv as
# iteration_rss_peak_mb — reuses the copy that function already left in
# iteration_dir rather than re-finding and re-copying it. Must run after
# iteration_rss_peak_mb. Empty output when absent.
#
# Deliberately NOT the max of the per-node peaks below: this sums cpu_percent
# ACROSS nodes at each timestamp and peaks that total — "how hot did the whole
# shard run at once" — so its value can exceed every individual node's peak
# (two nodes at 10% and 20% in the same sample yield 30). The per-node
# extractor answers the different question "how hot did each node get".
#
# LC_ALL=C on every awk that prints "%.1f": a comma-decimal LC_NUMERIC locale
# would emit "30,0", which downstream jq rejects — and because these values
# ride --argjson into metrics.json, that would silently cost the iteration its
# entire metrics file, not just this field.
iteration_cpu_peak_percent() {
	local iteration_dir="$1" ts_csv="$iteration_dir/resource-timeseries.csv"
	[ -s "$ts_csv" ] || return 0
	LC_ALL=C awk -F, 'NR > 1 && $2 != "__system__" { sum[$1] += $4 }
           END { max = 0; for (t in sum) if (sum[t] > max) max = sum[t]
                 if (max > 0) printf "%.1f\n", max }' "$ts_csv" 2>/dev/null
}

# The same CSV split back out per node: each node's own peak cpu_percent over
# the iteration, as a JSON object {node: pct}. This is the dashboard CPU
# grid's AGGREGATE fallback — one "all cores combined" value per node — used
# by the summary rollup for nodes the per-core extractor below has no data
# for (pre-emission harness, provider without the per-core hook). The harness
# prefixes container names — historically "rnode.<network>.", today a bare
# per-iteration shard hash ("f6f7eb46.validator1") — so the node id is the
# name's final dot-segment. Stripping ONLY the historical form let the hash
# prefixes through, and because every iteration mints a fresh hash the run
# rollup unioned them into one grid column per (iteration × node): 42
# columns of unreadable axis soup on the published chart. Node names are then
# sanitized to a safe character class ([-A-Za-z0-9._], anything else becomes
# "_") so a hostile or malformed name can neither break the hand-built JSON
# nor silently collide with another name the way character DELETION could.
# '{}' when absent, and the caller validates the output is JSON before
# trusting it (fail-soft like every metric here).
iteration_cpu_peak_per_node_percent() {
	local iteration_dir="$1" ts_csv="$iteration_dir/resource-timeseries.csv"
	[ -s "$ts_csv" ] || {
		printf '{}'
		return 0
	}
	LC_ALL=C awk -F, 'NR > 1 { sub(/\r$/, "") }
	         NR > 1 && $2 != "__system__" && $4 ~ /^[0-9]+([.][0-9]+)?$/ {
	           n = $2; sub(/^.*\./, "", n); if (n == "") n = $2
	           if (!(n in peak) || $4 + 0 > peak[n]) peak[n] = $4 + 0 }
	         END { printf "{"; sep = ""
	               for (n in peak) {
	                 k = n; gsub(/[^A-Za-z0-9._-]/, "_", k)
	                 printf "%s\"%s\":%.1f", sep, k, peak[n]; sep = "," }
	               printf "}" }' "$ts_csv" 2>/dev/null || printf '{}'
}

# Real core rows for the same grid: the harness monitor's per-core telemetry
# (resource-percore-timeseries.csv, columns elapsed_s,node,core,cpu_percent —
# a separate file from resource-timeseries.csv precisely so the aggregate
# extractors above cannot double-count), reduced to each (node, core) cell's
# peak over the iteration as nested JSON {node: {core: pct}}. '{}' when the
# harness predates per-core emission or the provider has no per-core hook;
# the summary rollup then keeps that node's "all" fallback row. Same name
# prefix stripping and JSON validation contract as the per-node extractor.
iteration_cpu_peak_per_node_core_percent() {
	local iteration_dir="$1" pc_csv="$iteration_dir/resource-percore-timeseries.csv"
	[ -s "$pc_csv" ] || {
		printf '{}'
		return 0
	}
	# Same row discipline as the per-node extractor: __system__ is host
	# state, not a node, and must never become a grid column (a node with
	# per-core rows drops its "all" fallback, so a phantom node here would
	# distort the grid, not just add noise). Core ids are bare CPU indices
	# per the telemetry contract — anything non-numeric is a malformed row,
	# rejected rather than sanitized into a phantom core.
	#
	# The leading sub() strips a CR before the fields are tested: the harness
	# writes this CSV with Python csv.writer, whose default line terminator
	# is \r\n, so cpu_percent — the LAST column — arrives as "1.5\r" and
	# would fail the numeric check on every row (smoke run 31547587950
	# published an all-fallback grid exactly this way). The per-node
	# extractor above gets the same guard for symmetry, though its CSV
	# carries a 5th column that happened to absorb the CR.
	LC_ALL=C awk -F, 'NR > 1 { sub(/\r$/, "") }
	         NR > 1 && $2 != "__system__" && $3 ~ /^[0-9]+$/ &&
	           $4 ~ /^[0-9]+([.][0-9]+)?$/ {
	           n = $2; sub(/^.*\./, "", n); if (n == "") n = $2
	           cell = n SUBSEP $3
	           if (!(cell in peak) || $4 + 0 > peak[cell]) peak[cell] = $4 + 0 }
	         END { printf "{"; nsep = ""
	               for (cell in peak) { split(cell, parts, SUBSEP); nodes[parts[1]] = 1 }
	               for (n in nodes) {
	                 k = n; gsub(/[^A-Za-z0-9._-]/, "_", k)
	                 printf "%s\"%s\":{", nsep, k; nsep = ","
	                 csep = ""
	                 for (cell in peak) {
	                   split(cell, parts, SUBSEP)
	                   if (parts[1] != n) continue
	                   printf "%s\"%s\":%.1f", csep, parts[2], peak[cell]; csep = ","
	                 }
	                 printf "}"
	               }
	               printf "}" }' "$pc_csv" 2>/dev/null || printf '{}'
}

snapshot_iteration_monitor_outputs() {
	local iteration_dir="$1" started_epoch filename source tmp
	started_epoch="$(date +%s)"
	while :; do
		for filename in resource-timeseries.csv resource-percore-timeseries.csv node-metrics-timeseries.csv resource-summary.txt host-protection-breach.txt; do
			source="$(find "${HARNESS_TELEMETRY_DIRS[@]}" \
				-name "$filename" -newer "$iteration_dir/.started" -print0 2>/dev/null |
				xargs -0 -r ls -t 2>/dev/null | head -1 || true)"
			[ -n "$source" ] || continue
			tmp="$iteration_dir/.$filename.tmp"
			if cp "$source" "$tmp" 2>/dev/null; then
				mv "$tmp" "$iteration_dir/$filename"
			else
				rm -f "$tmp"
			fi
		done
		scrape_node_memory_timeseries "$iteration_dir" "$started_epoch"
		sleep "${SOAK_MONITOR_SNAPSHOT_SECONDS:-2}"
	done
}

# Per-node memory attribution for the RSS-runaway defect: joins each running
# rnode container's RSS (from the harness resource-timeseries.csv snapshot)
# with the replay-cache and block-processing gauges scraped from the node's
# own /metrics endpoint. This is what turns "total RSS breached the ceiling"
# into "validator3's replay cache retained N bytes at breach time". Appends to
# node-memory-timeseries.tsv in the iteration dir; every lookup is fail-soft
# so a node mid-restart or a missing gauge yields '-' columns, never a dead
# snapshot loop.
NODE_METRICS_HTTP_PORT="${SOAK_NODE_METRICS_HTTP_PORT:-40403}"
scrape_node_memory_timeseries() {
	local iteration_dir="$1" started_epoch="$2" tsv="$1/node-memory-timeseries.tsv" \
		node port_line host_port metrics_body elapsed rss
	command -v docker >/dev/null 2>&1 || return 0
	command -v curl >/dev/null 2>&1 || return 0
	while IFS= read -r node; do
		[ -n "$node" ] || continue
		port_line="$(docker port "$node" "$NODE_METRICS_HTTP_PORT" 2>/dev/null | head -1 || true)"
		host_port="${port_line##*:}"
		[[ "$host_port" =~ ^[0-9]+$ ]] || continue
		metrics_body="$(curl -fsS --max-time 5 "http://127.0.0.1:${host_port}/metrics" 2>/dev/null || true)"
		[ -n "$metrics_body" ] || continue
		elapsed="$(($(date +%s) - started_epoch))"
		rss="$(awk -F, -v node="$node" \
			'NR > 1 && $2 == node { v = $3 } END { if (v == "") v = "-"; print v }' \
			"$iteration_dir/resource-timeseries.csv" 2>/dev/null || printf '%s\n' '-')"
		if [ ! -s "$tsv" ]; then
			printf 'elapsed_s\tnode\tmemory_mb\treplay_cache_entries\treplay_cache_retained_bytes\tblock_processing_active\tblock_processing_parallel_limit\tblock_processing_queue_pending\n' >"$tsv"
		fi
		printf '%s\n' "$metrics_body" | awk -v elapsed="$elapsed" -v node="$node" -v rss="$rss" '
			/^replay_cache_entries/ { entries = $NF }
			/^replay_cache_retained_bytes/ { retained = $NF }
			/^block_processing_active/ { active = $NF }
			/^block_processing_parallel_limit/ { limit = $NF }
			/^block_processing_queue_pending/ { queued = $NF }
			END {
				if (entries == "") entries = "-"
				if (retained == "") retained = "-"
				if (active == "") active = "-"
				if (limit == "") limit = "-"
				if (queued == "") queued = "-"
				printf "%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n", elapsed, node, rss, entries, retained, active, limit, queued
			}' >>"$tsv"
	done < <(docker ps --filter 'name=rnode.' --format '{{.Names}}' 2>/dev/null || true)
}

# Drop content-duplicate files from a newline-separated list on stdin (first
# occurrence wins). The same log can appear under both telemetry roots when
# teardown archives a copy of a file that also lives under data/, and the
# counting metrics below (too-far-ahead, sample counts) would double without
# this. Hash content rather than compare paths: the roots' layouts differ,
# so the same file carries unrelated relative paths. Fail-soft — an
# unhashable file passes through rather than being dropped.
dedup_files_by_content() {
	local f digest
	declare -A seen_digests=()
	while IFS= read -r f; do
		[ -f "$f" ] || continue
		if command -v md5sum >/dev/null 2>&1; then
			digest="$(md5sum "$f" 2>/dev/null | awk '{print $1}')"
		else
			digest="$(md5 -q "$f" 2>/dev/null)"
		fi
		if [ -n "$digest" ]; then
			[ -n "${seen_digests[$digest]:-}" ] && continue
			seen_digests[$digest]=1
		fi
		printf '%s\n' "$f"
	done
}

# Finalization latency from the test_load.py phase report. Each iteration uses
# the phase with the highest p95. A p99 comparison resolves equal p95 values.
# Emits that phase's "p50_ms p95_ms p99_ms phase_count" or nothing.
iteration_finalization_latency() {
	local iteration_dir="$1"
	awk -F'|' '
      function trim(value) {
        gsub(/\r/, "", value)
        gsub(/^[[:space:]]+|[[:space:]]+$/, "", value)
        return value
      }
      {
        deploys = trim($2)
        finalization = trim($5)
        count = split(finalization, values, /[[:space:]]+/)
        if (deploys !~ /^[0-9]+$/ || count != 3) next
        if (values[1] !~ /^[0-9]+([.][0-9]+)?$/ ||
            values[2] !~ /^[0-9]+([.][0-9]+)?$/ ||
            values[3] !~ /^[0-9]+([.][0-9]+)?$/) next
        p50 = values[1] + 0
        p95 = values[2] + 0
        p99 = values[3] + 0
        if (phases == 0 || p95 > selected_p95 ||
            (p95 == selected_p95 && p99 > selected_p99)) {
          selected_p50 = p50
          selected_p95 = p95
          selected_p99 = p99
        }
        phases++
      }
      END {
        if (phases > 0)
          printf "%.0f %.0f %.0f %d\n", selected_p50 * 1000, selected_p95 * 1000, selected_p99 * 1000, phases
      }' "$iteration_dir/pytest.log" 2>/dev/null || true
}

# Count of proposal rejections logged as too far ahead of the last finalized
# block since the iteration started — the exact string casper emits at
# casper/src/rust/blocks/proposer/propose_result.rs:185. A rising count means
# the proposer is outrunning finalization badly enough to be rejected outright,
# distinct from the passive finalization_p95_ms latency this soak already
# tracks (that measures how slow finalization is, not how often it is refused).
iteration_too_far_ahead_errors() {
	local iteration_dir="$1"
	find "${HARNESS_TELEMETRY_DIRS[@]}" \
		-type f \( -name '*.log' -o -name '*.txt' \) -newer "$iteration_dir/.started" 2>/dev/null |
		dedup_files_by_content |
		xargs -r grep -h -o 'too far ahead of the last finalized block' 2>/dev/null |
		wc -l | tr -d ' '
}

iteration_lfb_spread() {
	local iteration_dir="$1"
	grep -oE 'All-node LFBs at drain:.*\(spread [0-9]+ blocks\)' \
		"$iteration_dir/pytest.log" 2>/dev/null |
		grep -oE 'spread [0-9]+ blocks' |
		grep -oE '[0-9]+' |
		tail -1 || true
}

# Parse the pytest terminal summary line ("== 1 failed, 64 passed, ... ==")
# and emit a per-iteration metrics.json with resource + latency samples.
# Metrics are additive: missing jq or an unparseable log must never fail
# the soak.
emit_iteration_metrics() {
	local iteration_dir="$1" iteration="$2" provider="$3" \
		iter_started="$4" iter_finished="$5" exit_code="$6"
	command -v jq >/dev/null || return 0
	local summary_line passed failed skipped errors rss_peak cpu_peak latency lat_p50 lat_p95 lat_p99 lat_n too_far_ahead
	summary_line="$(grep -E '^=+ .* in [0-9.]+s( \([^)]*\))? =+$' "$iteration_dir/pytest.log" 2>/dev/null | tail -1 || true)"
	passed="$(printf '%s' "$summary_line" | grep -oE '[0-9]+ passed' | grep -oE '[0-9]+' || echo 0)"
	failed="$(printf '%s' "$summary_line" | grep -oE '[0-9]+ failed' | grep -oE '[0-9]+' || echo 0)"
	skipped="$(printf '%s' "$summary_line" | grep -oE '[0-9]+ skipped' | grep -oE '[0-9]+' || echo 0)"
	errors="$(printf '%s' "$summary_line" | grep -oE '[0-9]+ error' | grep -oE '[0-9]+' || echo 0)"
	rss_peak="$(iteration_rss_peak_mb "$iteration_dir")"
	cpu_peak="$(iteration_cpu_peak_percent "$iteration_dir")"
	local cpu_per_node cpu_per_core
	cpu_per_node="$(iteration_cpu_peak_per_node_percent "$iteration_dir")"
	jq -e 'type == "object"' >/dev/null 2>&1 <<<"$cpu_per_node" || cpu_per_node='{}'
	cpu_per_core="$(iteration_cpu_peak_per_node_core_percent "$iteration_dir")"
	jq -e 'type == "object"' >/dev/null 2>&1 <<<"$cpu_per_core" || cpu_per_core='{}'
	latency="$(iteration_finalization_latency "$iteration_dir")"
	lat_p50="$(printf '%s' "$latency" | awk '{print $1}')"
	lat_p95="$(printf '%s' "$latency" | awk '{print $2}')"
	lat_p99="$(printf '%s' "$latency" | awk '{print $3}')"
	lat_n="$(printf '%s' "$latency" | awk '{print $4}')"
	too_far_ahead="$(iteration_too_far_ahead_errors "$iteration_dir")"
	# Registry-driven metrics (see scripts/bench/soak-metrics.json). Unlike the
	# bespoke extractors above, adding a metric here needs no code change: the
	# harness emits a SOAK_METRIC line and the registry declares it. Fail-soft
	# by the same contract — the collector yields {} rather than erroring.
	local registry_metrics metric_log_roots root
	metric_log_roots="$iteration_dir"
	for root in "${HARNESS_TELEMETRY_DIRS[@]-}"; do
		[ -n "$root" ] || continue
		metric_log_roots="${metric_log_roots}:$root"
	done
	registry_metrics="$("$SCRIPT_DIR/bench/collect-soak-metrics.sh" \
		"$iteration_dir/.started" "$metric_log_roots" \
		2>/dev/null || printf '{}')"
	jq -e . >/dev/null 2>&1 <<<"$registry_metrics" || registry_metrics='{}'
	local lfb_spread
	if ! jq -e '.lfb_spread.samples > 0' >/dev/null 2>&1 <<<"$registry_metrics"; then
		lfb_spread="$(iteration_lfb_spread "$iteration_dir")"
		if [[ "$lfb_spread" =~ ^[0-9]+$ ]]; then
			registry_metrics="$(jq -c --argjson value "$lfb_spread" \
				'. + {lfb_spread: {p50: $value, p95: $value, max: $value, min: $value, samples: 1}}' \
				<<<"$registry_metrics")"
		fi
	fi
	jq -n \
		--argjson metrics "$registry_metrics" \
		--argjson iteration "$iteration" \
		--arg provider "$provider" \
		--argjson started "$iter_started" \
		--argjson finished "$iter_finished" \
		--argjson exit_code "$exit_code" \
		--argjson passed "$passed" \
		--argjson failed "$failed" \
		--argjson skipped "$skipped" \
		--argjson errors "$errors" \
		--argjson rss_peak "${rss_peak:-null}" \
		--argjson cpu_peak "${cpu_peak:-null}" \
		--argjson cpu_per_node "$cpu_per_node" \
		--argjson cpu_per_core "$cpu_per_core" \
		--argjson lat_p50 "${lat_p50:-null}" \
		--argjson lat_p95 "${lat_p95:-null}" \
		--argjson lat_p99 "${lat_p99:-null}" \
		--argjson lat_n "${lat_n:-null}" \
		--argjson too_far_ahead "${too_far_ahead:-0}" \
		'{iteration: $iteration, provider: $provider,
      started_at: $started, finished_at: $finished,
      duration_s: ($finished - $started), exit_code: $exit_code,
      pytest: {passed: $passed, failed: $failed, skipped: $skipped, errors: $errors},
      rss_peak_mb: $rss_peak,
      cpu_peak_pct: $cpu_peak,
      cpu_peak_per_node_pct: (if ($cpu_per_node | length) > 0 then $cpu_per_node else null end),
      cpu_peak_per_node_core_pct: (if ($cpu_per_core | length) > 0 then $cpu_per_core else null end),
      finalization_latency: {p50_ms: $lat_p50, p95_ms: $lat_p95, p99_ms: $lat_p99, samples: ($lat_n // 0)},
      too_far_ahead_errors: $too_far_ahead,
      metrics: $metrics,
      ok: ($exit_code == 0)}' >"$iteration_dir/metrics.json" 2>/dev/null || true
}

# True once the branch under test has advanced past the SHA this soak pinned
# at checkout. The soak builds one image and tests it for the whole run, so
# after a merge the results describe code that is no longer the branch head,
# and the runner is better spent starting fresh against the new tip.
#
# Gated behind MERGE_EXIT_MIN_SECONDS so a merge landing shortly after launch
# cannot reduce a night to a token soak. Fail-soft in every direction: an
# unreachable remote, an unreadable ref or a missing SHA all mean "keep
# soaking", never "stop" — a network hiccup must not end a 22-hour run.
target_ref_moved() {
	[ "$MERGE_EXIT_MIN_SECONDS" -gt 0 ] || return 1
	[ -n "$NODE_REPO_DIR" ] && [ -d "$NODE_REPO_DIR" ] || return 1
	[ "$TARGET_SHA" != "unknown" ] && [ "$TARGET_REF" != "unknown" ] || return 1
	[ "$(($(date +%s) - STARTED_AT))" -ge "$MERGE_EXIT_MIN_SECONDS" ] || return 1
	local remote_sha
	remote_sha="$(git -C "$NODE_REPO_DIR" ls-remote origin "$TARGET_REF" 2>/dev/null |
		awk 'NR == 1 {print $1}')"
	[ -n "$remote_sha" ] || return 1
	[ "$remote_sha" != "$TARGET_SHA" ]
}

run_bench_segment() {
	# Benchmark segments are fail-soft for the soak itself: a broken segment is
	# recorded and counted, and the perf-report job decides pass/fail from the
	# collected metrics.
	local remaining="$((DEADLINE - $(date +%s)))"
	if [ "$remaining" -le "$((BENCH_DURATION + 600))" ]; then
		return 0
	fi
	if [ "$DISK_FREE_FLOOR_MB" -gt 0 ]; then
		local disk_mb
		disk_mb="$(disk_free_mb)"
		if [ -z "$disk_mb" ] || [ "$disk_mb" -lt "$((DISK_FREE_FLOOR_MB + DISK_HYGIENE_BAND_MB))" ]; then
			EARLY_EXIT_REASON="host_protection_breach"
			DEADLINE=0
			FAILURES="$((FAILURES + 1))"
			publish_record -t "$OUTPUT_DIR/protection-breach.txt" printf 'The disk sample does not permit benchmark admission. The driver refused work.\n'
			publish_record "$OUTPUT_DIR/early-exit.txt" printf 'host_protection_breach: benchmark disk sample %s MiB, required %s MiB\n' \
				"${disk_mb:-unavailable}" "$((DISK_FREE_FLOOR_MB + DISK_HYGIENE_BAND_MB))"
			return 1
		fi
	fi
	if [ ! -s "$HOST_GUARDIAN_BREACH" ] && ! run_domain_verified; then
		publish_record "$HOST_GUARDIAN_BREACH" printf 'The run domain is unverified before benchmark admission. The driver refused work.\n'
	fi
	if ! jobs -pr | grep -Fxq "$CRASH_MONITOR_PID" && [ ! -s "$HOST_GUARDIAN_BREACH" ]; then
		publish_record "$HOST_GUARDIAN_BREACH" printf 'The crash monitor failed its benchmark admission check. Workload termination is unconfirmed.\n'
	fi
	if [ -s "$HOST_GUARDIAN_BREACH" ] || { [ -n "$HOST_GUARDIAN_PID" ] && { ! kill -0 "$HOST_GUARDIAN_PID" 2>/dev/null || ! guardian_progress_fresh; }; }; then
		if [ ! -s "$HOST_GUARDIAN_BREACH" ]; then
			publish_record "$HOST_GUARDIAN_BREACH" printf 'The host guardian failed its benchmark admission check. Workload termination is unconfirmed.\n'
		fi
		EARLY_EXIT_REASON="host_protection_breach"
		DEADLINE=0
		FAILURES="$((FAILURES + 1))"
		publish_record -t "$OUTPUT_DIR/protection-breach.txt" head -1 "$HOST_GUARDIAN_BREACH"
		publish_record "$OUTPUT_DIR/early-exit.txt" printf 'host_protection_breach: %s\n' "$(head -1 "$HOST_GUARDIAN_BREACH")"
		return 1
	fi
	BENCH_SEGMENTS="$((BENCH_SEGMENTS + 1))"
	INFLIGHT_BENCHMARK=1
	persist_soak_state || exit 2
	local segment_dir
	segment_dir="$OUTPUT_DIR/bench-segment-$(printf '%05d' "$BENCH_SEGMENTS")"
	mkdir -p "$segment_dir"
	PATH="$SOAK_WORKLOAD_PATH" \
		SOAK_PROCESS_OWNER="$SOAK_WRITER_OWNER" \
		SOAK_WRITER_OWNER="$SOAK_WRITER_OWNER" \
		SOAK_DOCKER_REAL="$SOAK_DOCKER_REAL" \
		SOAK_DOCKER_OWNER_DIR="$SOAK_DOCKER_OWNER_DIR" \
		NODE_REPO_DIR="$NODE_REPO_DIR" \
		OUT_DIR="$segment_dir" \
		BENCH_DURATION="$BENCH_DURATION" \
		BENCH_RATE="$BENCH_RATE" \
		SEGMENT_INDEX="$BENCH_SEGMENTS" \
		SOAK_STARTED_AT="$STARTED_AT" \
		timeout --signal=TERM --kill-after=1 "$remaining" \
		bash -c 'trap "while :; do sleep 1; done" TERM; "$@"' bash \
		"$SCRIPT_DIR/bench/run-bench-segment.sh" >"$segment_dir/segment.log" 2>&1 &
	BENCHMARK_PID=$!
	local interrupted=0
	while kill -0 "$BENCHMARK_PID" 2>/dev/null; do
		if ! jobs -pr | grep -Fxq "$CRASH_MONITOR_PID" && [ ! -s "$HOST_GUARDIAN_BREACH" ]; then
			publish_record "$HOST_GUARDIAN_BREACH" printf 'The crash monitor exited during benchmark execution. Workload termination is unconfirmed.\n'
		fi
		if [ -n "$HOST_GUARDIAN_PID" ] && ! kill -0 "$HOST_GUARDIAN_PID" 2>/dev/null && [ ! -s "$HOST_GUARDIAN_BREACH" ]; then
			publish_record "$HOST_GUARDIAN_BREACH" printf 'The host guardian exited during benchmark execution. Workload termination is unconfirmed.\n'
		fi
		if [ -n "$HOST_GUARDIAN_PID" ] && ! guardian_progress_fresh && [ ! -s "$HOST_GUARDIAN_BREACH" ]; then
			publish_record "$HOST_GUARDIAN_BREACH" printf 'The host guardian has no recent progress during benchmark execution. Workload termination is unconfirmed.\n'
		fi
		if [ -s "$HOST_GUARDIAN_BREACH" ]; then
			interrupted=1
			stop_node_writers -q kill >/dev/null 2>&1 || true
			kill -TERM "$BENCHMARK_PID" 2>/dev/null || true
			break
		fi
		sleep "${SOAK_GUARDIAN_POLL_SECONDS:-2}"
	done
	wait "$BENCHMARK_PID" 2>/dev/null
	local status=$?
	BENCHMARK_PID=""
	if [ "$interrupted" -eq 1 ]; then
		EARLY_EXIT_REASON="host_protection_breach"
		DEADLINE=0
		FAILURES="$((FAILURES + 1))"
		publish_record -t "$OUTPUT_DIR/protection-breach.txt" head -1 "$HOST_GUARDIAN_BREACH"
		publish_record "$OUTPUT_DIR/early-exit.txt" printf 'host_protection_breach: %s\n' "$(head -1 "$HOST_GUARDIAN_BREACH")"
		status=1
	fi
	if [ "$status" -ne 0 ]; then
		BENCH_FAILURES="$((BENCH_FAILURES + 1))"
		printf '%s\n' "$status" >"$segment_dir/exit-code.txt"
		# The segment's output goes to files that die with the VM when the run is
		# lost — 30713818751's bench failed 100% silently for exactly that reason
		# (missing DEPLOYER_KEY, visible only in a bench.log nobody ever saw).
		printf 'bench segment %s failed (status %s); segment.log tail:\n' \
			"$BENCH_SEGMENTS" "$status" >&2
		tail -20 "$segment_dir/segment.log" >&2 || true
		if [ -s "$segment_dir/bench.log" ]; then
			printf 'bench.log tail:\n' >&2
			tail -20 "$segment_dir/bench.log" >&2 || true
		fi
	fi
	INFLIGHT_BENCHMARK=0
	persist_soak_state || exit 2
}

mkdir -p "$OUTPUT_DIR"

# Operator signal, polled between iterations.
#
# A soak publishes only at a segment boundary, and those boundaries are fixed
# Pacific instants (07:30 / 13:00). A run starting off that grid — a short
# restart window, an afternoon dispatch — can run for hours with nothing on the
# dashboard, and a 60h weekend run is dark for its first twelve. This makes a
# boundary reachable on demand. The signal file is written by the poller in the
# soak-segment action, which reads it from this instance's own OCI freeform
# tags; see .github/workflows/soak-signal.yml for the sender.
#
# Checked here rather than in the poller because only this loop knows where an
# iteration boundary is. Stopping mid-iteration would leave a half-finished
# iteration that the aggregator counts as a real one, skewing the very numbers
# the checkpoint exists to report.
#
#   checkpoint  End THIS segment now, so the caller's aggregate/upload/publish
#               steps run exactly as at a scheduled checkpoint. The next
#               segment resumes from the state file with counters, start time
#               and iteration numbering intact, and the run continues.
#
#               Only possible where a segment boundary exists. The caller gates
#               those publish steps on having passed a deadline, so in the
#               final segment the request is refused rather than silently
#               ending the run and publishing nothing -- which is what it would
#               do if this simply broke the loop. Zero-checkpoint runs are all
#               final segment, so that is the common case, not a corner.
#
#   finalize    End the run. The marker survives into the remaining segments,
#               which exit immediately, so the run drains to the normal
#               end-of-run publish and produces a real verdict and history
#               entry rather than a latest-* refresh.
SIGNAL_FILE="${SOAK_SIGNAL_FILE:-$OUTPUT_DIR/signal}"
FINALIZE_MARKER="$OUTPUT_DIR/finalize-requested"
if [ -e "$FINALIZE_MARKER" ]; then
	printf 'finalize requested in an earlier segment; segment %s does no work\n' "$SEGMENT"
	DEADLINE=0
fi

# Orchestrator-level host guardian, independent of the whole test stack.
#
# The harness's protections live inside or under pytest: the in-process
# ceiling dies with the pytest process, and the docker provider sets no
# per-container memory limit. On run 30713818751 the kernel OOM killer shot
# pytest itself (oom_score_adj 500) while the docker-provider node containers
# — not pytest children — ran on uncapped and unwatched until the VM froze
# and the runner was lost. This loop is a separate process of this script,
# not of pytest, so it survives exactly that: on a sustained free-RAM floor
# breach it SIGKILLs every node process and container, writes a breach
# marker, and the iteration loop below fails the soak closed.
HOST_GUARDIAN_BREACH="$OUTPUT_DIR/host-guardian-breach.txt"
if [ -s "$HOST_GUARDIAN_BREACH" ]; then
	EARLY_EXIT_REASON="host_protection_breach"
	DEADLINE=0
	if [ "$FAILURES" -eq 0 ]; then FAILURES=1; fi
	publish_record "$OUTPUT_DIR/protection-breach.txt" head -1 "$HOST_GUARDIAN_BREACH"
	publish_record "$OUTPUT_DIR/early-exit.txt" printf 'host_protection_breach: recovered guardian record: %s\n' \
		"$(head -1 "$HOST_GUARDIAN_BREACH")"
	persist_soak_state
	printf 'The previous guardian breach prevents this segment from starting work.\n'
fi
if ! host_control probe; then
	printf 'Host writer ownership requires the Rust harness and Linux pidfd support. The driver refused work.\n' >&2
	exit 2
fi
read -r SOAK_WRITER_OWNER </proc/sys/kernel/random/uuid || exit 2
[[ "$SOAK_WRITER_OWNER" =~ ^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$ ]] || exit 2
SOAK_DOCKER_REAL="$(command -v docker || true)"
SOAK_DOCKER_OOM_PREFERRED=0
if [ "$HOST_FREE_FLOOR_MB" -gt 0 ]; then SOAK_DOCKER_OOM_PREFERRED=1; fi
export SOAK_DOCKER_OOM_PREFERRED
SOAK_DOCKER_OWNER_DIR=""
SOAK_WORKLOAD_PATH="$PATH"
if [ -n "$SOAK_DOCKER_REAL" ]; then
	SOAK_DOCKER_OWNER_DIR="$(mktemp -d "$OUTPUT_DIR/.docker-owner.XXXXXXXX")" || exit 2
	cat >"$SOAK_DOCKER_OWNER_DIR/docker" <<'SH'
#!/usr/bin/env bash
set -euo pipefail
real="${SOAK_DOCKER_REAL:?}"
owner="${SOAK_WRITER_OWNER:?}"
prefer="${SOAK_DOCKER_OOM_PREFERRED:?}"
[[ "$prefer" == 0 || "$prefer" == 1 ]] || exit 2
[[ "$owner" =~ ^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$ ]] || exit 2
original=("$@")
case "${1:-}" in
run | create)
    command="$1"
    shift
    preference=()
    [[ "$prefer" == 0 ]] || preference=(--oom-score-adj 1000)
    exec "$real" "$command" --label "io.f1r3fly.soak.owner=$owner" "${preference[@]}" "$@"
    ;;
compose)
    prefix=(compose)
    shift
    while [[ $# -gt 0 ]]; do
        case "$1" in
        -f | --file | -p | --project-name | --project-directory | --env-file | --profile | --ansi | --progress)
            [[ $# -ge 2 ]] || exit 2
            prefix+=("$1" "$2")
            shift 2
            ;;
        --file=* | --project-name=* | --project-directory=* | --env-file=* | --profile=* | --ansi=* | --progress=*)
            prefix+=("$1")
            shift
            ;;
        up | create)
            labels="$(mktemp "${SOAK_DOCKER_OWNER_DIR:?}/labels.XXXXXXXX.json")"
            trap 'rm -f "$labels"' EXIT
            "$real" "${prefix[@]}" config --format json |
                jq --arg owner "$owner" --argjson prefer "$prefer" '{services: (.services | with_entries(.value = ({labels: {"io.f1r3fly.soak.owner": $owner}} + (if $prefer == 1 then {oom_score_adj: 1000} else {} end))))}' >"$labels"
            "$real" "${prefix[@]}" -f "$labels" "$@"
            exit "$?"
            ;;
        -*) exit 2 ;;
        *) break ;;
        esac
    done
    ;;
esac
exec "$real" "${original[@]}"
SH
	chmod 700 "$SOAK_DOCKER_OWNER_DIR/docker" || exit 2
	SOAK_WORKLOAD_PATH="$SOAK_DOCKER_OWNER_DIR:$PATH"
fi
CRASH_MONITOR_DIR=""
CRASH_MONITOR_PID=""
HOST_GUARDIAN_PID=""
HOST_GUARDIAN_PROGRESS="$OUTPUT_DIR/.host-guardian-progress"
BENCHMARK_PID=""
ITERATION_PID=""
ITERATION_TEE_PID=""
ITERATION_SNAPSHOT_PID=""
ITERATION_FIFO=""
cleanup_soak_processes() {
	[ -z "$HOST_GUARDIAN_PID" ] || kill "$HOST_GUARDIAN_PID" 2>/dev/null || true
	if [ -n "$BENCHMARK_PID" ]; then
		kill -TERM "$BENCHMARK_PID" 2>/dev/null || true
		wait "$BENCHMARK_PID" 2>/dev/null || true
	fi
	if [ -n "$ITERATION_PID" ]; then
		kill "$ITERATION_PID" 2>/dev/null || true
	fi
	[ -z "$ITERATION_TEE_PID" ] || kill "$ITERATION_TEE_PID" 2>/dev/null || true
	[ -z "$ITERATION_SNAPSHOT_PID" ] || kill "$ITERATION_SNAPSHOT_PID" 2>/dev/null || true
	[ -z "$ITERATION_FIFO" ] || rm -f "$ITERATION_FIFO"
	if [ -n "$BENCHMARK_PID" ] || [ -n "$ITERATION_PID" ]; then
		if ! stop_node_writers -q kill >/dev/null 2>&1; then
			printf 'Writer termination is unconfirmed because a writer stop failed or exceeded its budget.\n' >"$OUTPUT_DIR/writer-stop-failure.txt"
			publish_record "$OUTPUT_DIR/early-exit.txt" printf 'writer_stop_failed: Writer termination is unconfirmed.\n'
			if [ "$INFLIGHT_ITERATION" -eq 1 ]; then
				INFLIGHT_ITERATION=2
				FAILURES="$((FAILURES + 1))"
			elif [ "$INFLIGHT_BENCHMARK" -eq 1 ]; then
				INFLIGHT_BENCHMARK=2
				BENCH_FAILURES="$((BENCH_FAILURES + 1))"
				FAILURES="$((FAILURES + 1))"
			elif [ "$FAILURES" -eq 0 ]; then
				FAILURES=1
			fi
			persist_soak_state || return 1
		fi
	fi
	if [ -n "$CRASH_MONITOR_DIR" ]; then
		printf 'handled\n' >"$CRASH_MONITOR_DIR/handled-exit"
	fi
}
trap cleanup_soak_processes EXIT
if [ "$DEADLINE" -gt "$(date +%s)" ] && ! start_crash_monitor; then
	printf 'The crash monitor is unavailable. The driver refused work.\n' >&2
	exit 2
fi
if { [ "$HOST_FREE_FLOOR_MB" -gt 0 ] && [ -r /proc/meminfo ]; } || [ "$DISK_FREE_FLOOR_MB" -gt 0 ]; then
	if ! guardian_record_progress; then
		printf 'The host guardian progress record is unavailable. The driver refused work.\n' >&2
		exit 2
	fi
	(
		# Run 33136185540 (2026-08-28): the kernel OOM killer chose
		# Runner.Worker while this guardian's 3-sample window was still
		# open — the runner vanished mid-soak, the VM self-terminated
		# through the ephemeral exit path, and the night left no artifact.
		# Three hardenings, each aimed at that failure shape:
		#
		# 1. Every sample re-applies oom_score_adj 1000 to the node
		#    processes and node containers, so a kernel OOM that beats
		#    this guardian to the punch kills the WORKLOAD (a recorded
		#    breach) and never the runner (a vanished VM). Re-applied per
		#    sample because nodes restart across iterations.
		# 2. A hard floor at half the configured floor fires on a SINGLE
		#    sample: a fast plunge must not get 15s of grace.
		# 3. On warning or breach, the last-known memory state is stamped
		#    into the instance's freeform tags via the instance-principal
		#    CLI. Tags outlive termination (the 33136185540 post-mortem
		#    could read the dead VM's tags), so even a lost runner leaves
		#    durable last words. Stamped ONLY in the warning/breach band —
		#    a healthy run never writes tags, keeping the read-modify-write
		#    race with the soak-signal tag out of the normal path. The
		#    freeform-tag API replaces the whole map, so the remaining
		#    single-write race against a concurrent soak-signal writer is
		#    accepted by design: it exists only while the host is already
		#    dying, and last words outrank a checkpoint signal there.
		guardian_oom_mark_warned=0
		guardian_mark_workload_oom_preferred() {
			local failed=0
			export SOAK_WRITER_OWNER
			export -f host_control mark_owned_oom_preferred
			if ! timeout --signal=TERM --kill-after=1 "$DISK_STOP_SECONDS" bash -c 'mark_owned_oom_preferred'; then
				failed=1
			fi
			# One line for the whole guardian lifetime: a per-sample failure
			# would flood the log, silence would hide that the runner is NOT
			# protected from the kernel OOM killer.
			if [ "$failed" -eq 1 ] && [ "$guardian_oom_mark_warned" -eq 0 ]; then
				guardian_oom_mark_warned=1
				printf 'host guardian: could not apply oom_score_adj to some workload processes; the runner is not OOM-preferred over them\n' >&2
			fi
		}
		guardian_stamp_health_tag() {
			local state="$1" avail="$2" detail="${3:-}" iid tags
			command -v oci >/dev/null 2>&1 || return 0
			iid="$(curl -fsS --max-time 5 -H 'Authorization: Bearer Oracle' \
				http://169.254.169.254/opc/v2/instance/id 2>/dev/null)" || return 0
			case "$iid" in ocid1.instance.*) ;; *) return 0 ;; esac
			# Every remote call is deadline-bounded: this function runs while
			# the host is under memory pressure, and a hung CLI here must not
			# stall the guardian whose whole job is reacting fast.
			tags="$(timeout --foreground 15 oci --auth instance_principal compute instance get \
				--instance-id "$iid" --query 'data."freeform-tags"' \
				--output json 2>/dev/null)" || return 0
			# An OCI freeform tag value holds 256 chars; the attribution detail
			# is optional and trimmed to whatever fits after the last words.
			tags="$(printf '%s' "$tags" | jq -c --arg health "$state:$(date +%s):avail=${avail}MB${detail:+:$detail}" \
				'(. // {}) + {"soak-health": $health[:256]}')" || return 0
			[ -n "$tags" ] || return 0
			timeout --foreground 15 oci --auth instance_principal compute instance update \
				--instance-id "$iid" --freeform-tags "$tags" --force \
				>/dev/null 2>&1 || true
		}
		over=0
		hard_floor_mb=$((HOST_FREE_FLOOR_MB / 2))
		[ "$hard_floor_mb" -ge 1 ] || hard_floor_mb=1
		warn_floor_mb=$((HOST_FREE_FLOOR_MB + ${SOAK_HOST_WARN_BAND_MB:-4096}))
		disk_over=0
		disk_hard_floor_mb=$((DISK_FREE_FLOOR_MB / 2))
		[ "$disk_hard_floor_mb" -ge 1 ] || disk_hard_floor_mb=1
		last_stamp=0
		sample_n=0
		while :; do
			sleep 5
			if [ "$DISK_FREE_FLOOR_MB" -gt 0 ]; then
				disk_mb="$(disk_free_mb)"
				if [ -z "$disk_mb" ]; then
					publish_record "$HOST_GUARDIAN_BREACH" printf 'The disk probe is unavailable during execution. Workload termination is unconfirmed.\n'
					stop_node_writers -q kill || true
					exit 0
				fi
				if [ -n "$disk_mb" ]; then
					if [ "$disk_mb" -ge "$DISK_FREE_FLOOR_MB" ]; then
						disk_over=0
					else
						disk_over=$((disk_over + 1))
						if [ "$disk_mb" -lt "$disk_hard_floor_mb" ] || [ "$disk_over" -ge 3 ]; then
							publish_record "$HOST_GUARDIAN_BREACH" printf 'The disk guardian detected %s MiB below floor %s MiB (hard floor %s MiB, consecutive samples %s). Workload termination is unconfirmed.\n' \
								"$disk_mb" "$DISK_FREE_FLOOR_MB" "$disk_hard_floor_mb" "$disk_over"
							stop_node_writers -q kill || true
							# Who filled it rides in the tag: on weekend runs
							# 33939315110, 33978505238 and 34056342543 the VM
							# was gone ~20s after this stamp and the tag was
							# the only evidence that survived. The full
							# snapshot follows for the case where the runner
							# lives long enough to upload it.
							disk_diagnostics_bounded disk_guardian_diagnostics "$disk_mb" || true
							exit 0
						fi
					fi
				fi
			fi
			guardian_record_progress || exit 1
			if [ "$HOST_FREE_FLOOR_MB" -le 0 ]; then
				continue
			fi
			free_mb="$(awk '/^MemAvailable:/ {print int($2 / 1024)}' /proc/meminfo 2>/dev/null)"
			[ -n "$free_mb" ] || continue
			# Every 3rd sample (15s): fresh nodes appear at iteration
			# boundaries, not per second, and the docker inspect round trip
			# is not free at a 5s cadence.
			sample_n=$((sample_n + 1))
			[ $((sample_n % 3)) -eq 1 ] && guardian_mark_workload_oom_preferred
			if [ "$free_mb" -ge "$HOST_FREE_FLOOR_MB" ]; then
				over=0
				# The warning stamp runs ONLY on the healthy side of the
				# breach checks and in the background, so a slow tag write
				# can never delay the emergency kill below.
				if [ "$free_mb" -lt "$warn_floor_mb" ]; then
					now="$(date +%s)"
					if [ $((now - last_stamp)) -ge 60 ]; then
						guardian_stamp_health_tag warning "$free_mb" &
						last_stamp="$now"
					fi
				fi
				continue
			fi
			over=$((over + 1))
			if [ "$free_mb" -ge "$hard_floor_mb" ] && [ "$over" -lt 3 ]; then
				continue
			fi
			publish_record "$HOST_GUARDIAN_BREACH" printf 'orchestrator host guardian: host available RAM %sMB < floor %sMB (hard floor %sMB, consecutive %s); writer termination is unconfirmed\n' \
				"$free_mb" "$HOST_FREE_FLOOR_MB" "$hard_floor_mb" "$over"
			stop_node_writers -q kill >/dev/null 2>&1 || true
			guardian_stamp_health_tag breach "$free_mb"
			exit 0
		done
	) &
	HOST_GUARDIAN_PID=$!
	printf 'orchestrator host guardian watching MemAvailable floor %sMB (hard floor %sMB, warn %sMB) and disk free floor %sMB (hard floor %sMB); pid %s\n' \
		"$HOST_FREE_FLOOR_MB" "$((HOST_FREE_FLOOR_MB / 2))" "$((HOST_FREE_FLOOR_MB + 4096))" \
		"$DISK_FREE_FLOOR_MB" "$((DISK_FREE_FLOOR_MB / 2))" "$HOST_GUARDIAN_PID"
fi

# Only on the first segment: this is the run's opening baseline measurement,
# and repeating it at every resume would add segments the cadence never asked
# for and skew the run's active-benchmark averages.
if [ "$RUN_BENCHMARKS" = "true" ] && [ "$SEGMENT" -eq 1 ] &&
	[ ! -s "$OUTPUT_DIR/host-guardian-breach.txt" ]; then
	run_bench_segment
	persist_soak_state
fi

while [ "$(date +%s)" -lt "$DEADLINE" ]; do
	if [ "$CASPER_RUNTIME" -eq 1 ]; then
		if [ -e "$FINALIZE_MARKER" ] || [ -L "$FINALIZE_MARKER" ]; then
			CASPER_TERMINATION=cancelled
			break
		fi
		[ "$ITERATIONS" -lt "$CASPER_LIMIT" ] || break
		[ "$((ITERATIONS - CASPER_SEGMENT_START))" -lt "$CASPER_SEGMENT_LIMIT" ] || break
		casper_runtime history --iteration "$ITERATIONS" --failures "$FAILURES" || exit 2
	fi
	# The orchestrator guardian can fire outside a failing iteration — during a
	# bench segment, or after an iteration that still exited 0. Never start new
	# work once the host has been defended.
	if [ -s "$HOST_GUARDIAN_BREACH" ]; then
		EARLY_EXIT_REASON="host_protection_breach"
		printf 'orchestrator host guardian fired; ending soak (fail-closed)\n'
		publish_record -t "$OUTPUT_DIR/protection-breach.txt" head -1 "$HOST_GUARDIAN_BREACH"
		publish_record "$OUTPUT_DIR/early-exit.txt" printf 'host_protection_breach: %s\n' "$(head -1 "$HOST_GUARDIAN_BREACH")"
		FAILURES="$((FAILURES + 1))"
		break
	fi
	# Iteration-boundary disk hygiene (issue #378): reclaim per-iteration
	# leftovers while free space is merely low, so the guardian floor above
	# is the backstop and not the routine outcome. If hygiene cannot lift
	# free space back OUT OF THE BAND, end the run here — cleanly, with df
	# and du evidence — rather than start an iteration whose nodes will write
	# into a nearly full disk and fail with a misleading consensus verdict.
	#
	# Out of the band, not merely over the floor. The first cut compared
	# against the floor, and weekend runs 33939315110, 33978505238 and
	# 34056342543 all walked through it: hygiene reclaimed nothing at 7956MB,
	# 7596MB and 7355MB free, each pass was still 3GB over the floor, so each
	# started another iteration; the iteration crossed the floor mid-run, the
	# guardian fired, and the runner was dead ~20s later with no report. A
	# pass that ends inside the band has already proven that nothing it
	# sweeps is what is growing, and the next iteration only moves the
	# breach into the guardian's window. Every observed pass that did
	# recover space cleared the band (8054 -> 14381MB, 8047 -> 14265MB).
	if [ "$DISK_FREE_FLOOR_MB" -gt 0 ]; then
		DISK_MB="$(disk_free_mb)"
		if [ -n "$DISK_MB" ] && [ "$DISK_MB" -lt "$((DISK_FREE_FLOOR_MB + DISK_HYGIENE_BAND_MB))" ]; then
			printf 'free disk %sMB inside hygiene band (floor %sMB + band %sMB); reclaiming\n' \
				"$DISK_MB" "$DISK_FREE_FLOOR_MB" "$DISK_HYGIENE_BAND_MB"
			if ! reclaim_disk_space; then
				if [ ! -s "$HOST_GUARDIAN_BREACH" ]; then
					publish_record "$HOST_GUARDIAN_BREACH" printf 'Disk hygiene failed or exceeded its command budget. Cleanup termination is unconfirmed.\n'
				fi
				EARLY_EXIT_REASON="host_protection_breach"
				publish_record -t "$OUTPUT_DIR/protection-breach.txt" head -1 "$HOST_GUARDIAN_BREACH"
				publish_record "$OUTPUT_DIR/early-exit.txt" printf 'host_protection_breach: disk hygiene incomplete\n'
				FAILURES="$((FAILURES + 1))"
				break
			fi
			# The guardian may have fired while hygiene ran (a builder prune
			# can outlast the soft floor's 15s window), and it exits after
			# firing — space recovered afterwards does not un-fire it or
			# bring it back. Fail closed here rather than start an iteration
			# that would run unguarded until its watcher trips on the marker.
			if [ -s "$HOST_GUARDIAN_BREACH" ]; then
				EARLY_EXIT_REASON="host_protection_breach"
				printf 'orchestrator host guardian fired during disk hygiene; ending soak (fail-closed)\n'
				publish_record -t "$OUTPUT_DIR/protection-breach.txt" head -1 "$HOST_GUARDIAN_BREACH"
				publish_record "$OUTPUT_DIR/early-exit.txt" printf 'host_protection_breach: %s\n' "$(head -1 "$HOST_GUARDIAN_BREACH")"
				FAILURES="$((FAILURES + 1))"
				break
			fi
			DISK_MB="$(disk_free_mb)"
			if [ -n "$DISK_MB" ] && [ "$DISK_MB" -lt "$((DISK_FREE_FLOOR_MB + DISK_HYGIENE_BAND_MB))" ]; then
				EARLY_EXIT_REASON="host_protection_breach"
				publish_record -t "$OUTPUT_DIR/protection-breach.txt" printf 'orchestrator disk floor: free disk %sMB still inside hygiene band (floor %sMB + band %sMB) after hygiene; ending soak (fail-closed)\n' \
					"$DISK_MB" "$DISK_FREE_FLOOR_MB" "$DISK_HYGIENE_BAND_MB"
				publish_record "$OUTPUT_DIR/early-exit.txt" printf 'host_protection_breach: disk floor: free %sMB still inside hygiene band (floor %sMB + band %sMB) after hygiene\n' \
					"$DISK_MB" "$DISK_FREE_FLOOR_MB" "$DISK_HYGIENE_BAND_MB"
				FAILURES="$((FAILURES + 1))"
				persist_soak_state || true
				disk_usage_snapshot >"$OUTPUT_DIR/disk-floor-breach.txt" 2>/dev/null || true
				break
			fi
			disk_usage_snapshot 2>/dev/null | sed 's/^/disk usage: /'
		fi
		if [ -z "$DISK_MB" ]; then
			EARLY_EXIT_REASON="host_protection_breach"
			publish_record -t "$OUTPUT_DIR/protection-breach.txt" printf 'The disk probe is unavailable before admission. The driver refused work.\n'
			publish_record "$OUTPUT_DIR/early-exit.txt" printf 'host_protection_breach: disk probe unavailable before admission\n'
			FAILURES="$((FAILURES + 1))"
			break
		fi
	fi
	if [ ! -s "$HOST_GUARDIAN_BREACH" ] && ! run_domain_verified; then
		publish_record "$HOST_GUARDIAN_BREACH" printf 'The run domain is unverified before iteration admission. The driver refused work.\n'
	fi
	if ! jobs -pr | grep -Fxq "$CRASH_MONITOR_PID" && [ ! -s "$HOST_GUARDIAN_BREACH" ]; then
		publish_record "$HOST_GUARDIAN_BREACH" printf 'The crash monitor failed its iteration admission check. Workload termination is unconfirmed.\n'
	fi
	if [ -s "$HOST_GUARDIAN_BREACH" ] || { [ -n "$HOST_GUARDIAN_PID" ] && { ! kill -0 "$HOST_GUARDIAN_PID" 2>/dev/null || ! guardian_progress_fresh; }; }; then
		if [ ! -s "$HOST_GUARDIAN_BREACH" ]; then
			publish_record "$HOST_GUARDIAN_BREACH" printf 'The host guardian failed its iteration admission check. Workload termination is unconfirmed.\n'
		fi
		EARLY_EXIT_REASON="host_protection_breach"
		publish_record -t "$OUTPUT_DIR/protection-breach.txt" head -1 "$HOST_GUARDIAN_BREACH"
		publish_record "$OUTPUT_DIR/early-exit.txt" printf 'host_protection_breach: %s\n' "$(head -1 "$HOST_GUARDIAN_BREACH")"
		FAILURES="$((FAILURES + 1))"
		break
	fi
	if [ -e "$SIGNAL_FILE" ]; then
		SIGNAL="$(tr -d '[:space:]' <"$SIGNAL_FILE" 2>/dev/null || true)"
		# Consumed either way: an unread signal re-fires on every later iteration
		# and every later segment.
		rm -f "$SIGNAL_FILE"
		case "$SIGNAL" in
		checkpoint)
			if [ "$HAS_CHECKPOINT_BOUNDARY" -eq 1 ]; then
				printf 'checkpoint signalled after iteration %s; ending segment %s\n' "$ITERATIONS" "$SEGMENT"
				printf '%s\n' "checkpoint signalled after iteration $ITERATIONS" \
					>"$OUTPUT_DIR/signalled-checkpoint.txt"
				break
			fi
			printf 'checkpoint signalled, but segment %s is the final segment and publishes no checkpoint; ignoring. Use finalize to end the run and publish a full verdict.\n' \
				"$SEGMENT" >&2
			;;
		finalize)
			printf 'finalize signalled after iteration %s; ending the run\n' "$ITERATIONS"
			if [ "$CASPER_RUNTIME" -eq 1 ]; then
				casper_runtime stop || exit 2
			else
				printf '%s\n' "finalize signalled after iteration $ITERATIONS" >"$FINALIZE_MARKER"
			fi
			break
			;;
		'')
			;;
		*)
			printf 'ignoring unrecognised soak signal: %s\n' "$SIGNAL" >&2
			;;
		esac
	fi
	PROVIDER="${PROVIDERS[$((ITERATIONS % ${#PROVIDERS[@]}))]}"
	if [ "$CASPER_RUNTIME" -eq 1 ]; then PROVIDER="$CASPER_PROVIDER"; fi
	ITERATIONS="$((ITERATIONS + 1))"
	INFLIGHT_ITERATION=1
	persist_soak_state || exit 2
	ITERATION_DIR="$OUTPUT_DIR/iteration-$(printf '%05d' "$ITERATIONS")-$PROVIDER"
	mkdir "$ITERATION_DIR" || exit 2
	REMAINING="$((DEADLINE - $(date +%s)))"
	if [ "$REMAINING" -le 0 ]; then
		INFLIGHT_ITERATION=0
		break
	fi

	ITER_STARTED="$(date +%s)"
	touch "$ITERATION_DIR/.started"
	ITERATION_FIFO="$ITERATION_DIR/.pytest-output.fifo"
	rm -f "$ITERATION_FIFO"
	mkfifo "$ITERATION_FIFO"
	tee "$ITERATION_DIR/pytest.log" <"$ITERATION_FIFO" &
	ITERATION_TEE_PID=$!
	(
		cd "$SYSTEM_INTEGRATION_DIR"
		export SOAK_WRITER_OWNER SOAK_DOCKER_REAL SOAK_DOCKER_OWNER_DIR
		export SOAK_PROCESS_OWNER="$SOAK_WRITER_OWNER"
		export PATH="$SOAK_WORKLOAD_PATH"
		if [ "$CASPER_RUNTIME" -eq 1 ]; then
			exec timeout --signal=TERM --kill-after=30 "${REMAINING}s" \
				bash "$SCRIPT_DIR/bench/casper-soak.sh" run --output "$OUTPUT_DIR" \
				--directory "$ITERATION_DIR" --iteration "$ITERATIONS" --segment "$SEGMENT"
		fi
		exec timeout --signal=TERM --kill-after=30 "${REMAINING}s" \
			poetry run pytest \
			integration-tests/test/tests/custom/test_load.py \
			--provider="$PROVIDER" \
			--monitor \
			--rss-ceiling-mb "$RSS_CEILING_MB" \
			--host-free-floor-mb "$HOST_FREE_FLOOR_MB" \
			-v --tb=short --instafail --maxfail=20 \
			--timeout=1200
	) >"$ITERATION_FIFO" 2>&1 &
	ITERATION_PID=$!
	if [ "$CASPER_RUNTIME" -eq 0 ]; then
		snapshot_iteration_monitor_outputs "$ITERATION_DIR" &
		ITERATION_SNAPSHOT_PID=$!
	fi
	GUARDIAN_INTERRUPTED=0
	while kill -0 "$ITERATION_PID" 2>/dev/null; do
		if ! jobs -pr | grep -Fxq "$CRASH_MONITOR_PID" && [ ! -s "$HOST_GUARDIAN_BREACH" ]; then
			publish_record "$HOST_GUARDIAN_BREACH" printf 'The crash monitor exited during iteration execution. Workload termination is unconfirmed.\n'
		fi
		if [ -n "$HOST_GUARDIAN_PID" ] && ! kill -0 "$HOST_GUARDIAN_PID" 2>/dev/null && [ ! -s "$HOST_GUARDIAN_BREACH" ]; then
			publish_record "$HOST_GUARDIAN_BREACH" printf 'The host guardian exited during execution. Workload termination is unconfirmed.\n'
		fi
		if [ -n "$HOST_GUARDIAN_PID" ] && ! guardian_progress_fresh && [ ! -s "$HOST_GUARDIAN_BREACH" ]; then
			publish_record "$HOST_GUARDIAN_BREACH" printf 'The host guardian has no recent progress during execution. Workload termination is unconfirmed.\n'
		fi
		if [ -s "$HOST_GUARDIAN_BREACH" ]; then
			GUARDIAN_INTERRUPTED=1
			emergency_start
			EARLY_EXIT_REASON="host_protection_breach"
			publish_record "$OUTPUT_DIR/protection-breach.txt" head -1 "$HOST_GUARDIAN_BREACH"
			publish_record "$OUTPUT_DIR/early-exit.txt" printf 'host_protection_breach: iteration %s: %s\n' "$ITERATIONS" "$(head -1 "$HOST_GUARDIAN_BREACH")"
			kill -TERM "$ITERATION_PID" 2>/dev/null || true
			term_wait="$(emergency_remaining)"
			[ "$term_wait" -le 15 ] || term_wait=15
			for _ in $(seq 1 "$term_wait"); do
				kill -0 "$ITERATION_PID" 2>/dev/null || break
				sleep 1
			done
			kill -KILL "$ITERATION_PID" 2>/dev/null || true
			break
		fi
		sleep "${SOAK_GUARDIAN_POLL_SECONDS:-2}"
	done
	wait "$ITERATION_PID" 2>/dev/null
	STATUS=$?
	if [ "$GUARDIAN_INTERRUPTED" -eq 0 ] && [ -s "$HOST_GUARDIAN_BREACH" ]; then
		GUARDIAN_INTERRUPTED=1
		emergency_start
		EARLY_EXIT_REASON="host_protection_breach"
		publish_record "$OUTPUT_DIR/protection-breach.txt" head -1 "$HOST_GUARDIAN_BREACH"
		publish_record "$OUTPUT_DIR/early-exit.txt" printf 'host_protection_breach: iteration %s: %s\n' "$ITERATIONS" "$(head -1 "$HOST_GUARDIAN_BREACH")"
	fi
	if [ "$GUARDIAN_INTERRUPTED" -eq 1 ]; then
		STATUS=1
		if [ "$CASPER_RUNTIME" -eq 1 ]; then
			stop_node_writers -q kill >/dev/null 2>&1 || true
		else
			stop_node_writers -aq rm -f >/dev/null 2>&1 || true
		fi
	fi
	if [ "$CASPER_RUNTIME" -eq 1 ]; then
		stop_node_writers -q kill >/dev/null 2>&1 || true
	fi
	if [ -n "$EMERGENCY_DEADLINE_EPOCH" ]; then
		while kill -0 "$ITERATION_TEE_PID" 2>/dev/null && [ "$(emergency_remaining)" -gt 0 ]; do
			sleep 0.2
		done
		kill "$ITERATION_TEE_PID" 2>/dev/null || true
	fi
	wait "$ITERATION_TEE_PID" 2>/dev/null || true
	if [ -n "$ITERATION_SNAPSHOT_PID" ]; then
		kill "$ITERATION_SNAPSHOT_PID" 2>/dev/null || true
		wait "$ITERATION_SNAPSHOT_PID" 2>/dev/null || true
	fi
	rm -f "$ITERATION_FIFO"
	ITERATION_PID=""
	ITERATION_TEE_PID=""
	ITERATION_SNAPSHOT_PID=""
	ITERATION_FIFO=""
	# No `set -e` restore: this script never enables errexit (line 2 is
	# `set -uo pipefail`), and turning it on here made the first failed
	# iteration fatal — the metric pipelines return nonzero when a failed
	# iteration leaves nothing to sample, which killed every segment mid-loop
	# before the state file or rollup could be written (run 30516534214).
	ITER_FINISHED="$(date +%s)"
	if [ "$CASPER_RUNTIME" -eq 1 ]; then
		CASPER_TERMINATION=completed
		if [ "$GUARDIAN_INTERRUPTED" -eq 1 ]; then CASPER_TERMINATION=resource_stop;
		elif [ "$STATUS" -eq 124 ]; then CASPER_TERMINATION=deadline;
		elif [ "$STATUS" -ne 0 ]; then CASPER_TERMINATION=tool_error; fi
		casper_runtime finish --directory "$ITERATION_DIR" --iteration "$ITERATIONS" \
			--segment "$SEGMENT" --status "$STATUS" --termination "$CASPER_TERMINATION"
		CASPER_STATUS=$?
		INFLIGHT_ITERATION=0
		if [ "$CASPER_STATUS" -ne 0 ]; then FAILURES="$((FAILURES + 1))"; fi
		if [ "$CASPER_STATUS" -gt 1 ]; then INFLIGHT_ITERATION=2; fi
		if [ "$CASPER_TERMINATION" != completed ]; then
			printf '%s\n' "$CASPER_TERMINATION" >"$OUTPUT_DIR/early-exit.txt"
		fi
		persist_soak_state || exit 2
		if [ "$CASPER_STATUS" -gt 1 ] || [ "$CASPER_TERMINATION" != completed ]; then break; fi
		if ! jq -e '.capture_complete == true' "$OUTPUT_DIR/casper-history/$(printf '%08d' "$ITERATIONS").json" >/dev/null; then break; fi
		continue
	fi
	emit_iteration_metrics "$ITERATION_DIR" "$ITERATIONS" "$PROVIDER" \
		"$ITER_STARTED" "$ITER_FINISHED" "$STATUS" || true
	INFLIGHT_ITERATION=0

	if [ "$STATUS" -eq 124 ] && [ "$(date +%s)" -ge "$DEADLINE" ]; then
		printf '%s\n' "deadline reached during iteration $ITERATIONS" >"$ITERATION_DIR/deadline.txt"
		break
	fi
	if [ "$STATUS" -ne 0 ]; then
		FAILURES="$((FAILURES + 1))"
		persist_soak_state
		printf '%s\n' "$STATUS" >"$ITERATION_DIR/exit-code.txt"
		for evidence_root in "${HARNESS_TELEMETRY_DIRS[@]}"; do
			[ -d "$evidence_root" ] || continue
			# Evidence only — logs, CSVs, configs. A full `cp -a` drags the nodes'
			# LMDB data along, which ran to a silent half-hour stall between
			# iterations on run 30713818751 (19:16→19:45 with zero output) and
			# would bloat the results artifact past uploadable size.
			COPY_STARTED="$(date +%s)"
			evidence_name="$(basename "$evidence_root")"
			printf 'preserving failure evidence from integration-tests/%s (iteration %s)\n' \
				"$evidence_name" "$ITERATIONS"
			mkdir -p "$ITERATION_DIR/$evidence_name"
			copy_budget="$(emergency_remaining)"
			if [ -n "$EMERGENCY_DEADLINE_EPOCH" ] && [ "$copy_budget" -le 0 ]; then
				printf 'failure-evidence copy of %s skipped: the emergency deadline expired\n' "$evidence_name" |
					tee -a "$OUTPUT_DIR/emergency-skipped.txt" >&2
				continue
			fi
			session_bounded "$copy_budget" bash -c '
				cd "$1" &&
					find . -type f \( -name "*.log" -o -name "*.csv" -o -name "*.txt" \
						-o -name "*.json" -o -name "*.conf" -o -name "*.toml" \) -print0 |
					tar --null -T - -cf - |
					tar -xf - -C "$2"' bash "$evidence_root" "$ITERATION_DIR/$evidence_name" ||
				printf 'failure-evidence copy incomplete (non-fatal)\n' >&2
			printf 'failure evidence preserved in %ss\n' "$(($(date +%s) - COPY_STARTED))"
		done
		# Fail closed on a host-protection breach. The guardian killing the nodes
		# means the load does not fit under the configured ceiling/floor on this
		# host; every further iteration reproduces the breach (30713818751 breached
		# on all three iterations across both providers), and each one is another
		# spin of a workload known to endanger the host. Preserve evidence above,
		# then end the whole soak: the early-exit marker makes every remaining
		# segment a no-op, and the job still reaches its completion marker so
		# retry_within_window does not relaunch the same doomed run on a fresh VM.
		#
		# Three channels, most authoritative first: the orchestrator guardian's
		# own marker, the harness monitor's marker file, and — for harness
		# versions predating the marker — the breach message in the pytest log.
		BREACH_LINE=""
		if [ -s "$HOST_GUARDIAN_BREACH" ]; then
			BREACH_LINE="$(head -1 "$HOST_GUARDIAN_BREACH")"
		else
			HARNESS_MARKER="$(find "${HARNESS_TELEMETRY_DIRS[@]}" \
				-name host-protection-breach.txt -newer "$ITERATION_DIR/.started" 2>/dev/null |
				head -1 || true)"
			if [ -n "$HARNESS_MARKER" ]; then
				BREACH_LINE="$(head -1 "$HARNESS_MARKER")"
			else
				BREACH_LINE="$(grep -m1 -E \
					'Host-protection guardian breach|Resource ceiling breached|host-protection watchdog killed' \
					"$ITERATION_DIR/pytest.log" 2>/dev/null || true)"
			fi
		fi
		# Fourth channel (issue #378): an iteration that fails while free
		# disk is under the floor is an infrastructure failure, whatever the
		# assertion text says. Run 33254400407's last iteration reported
		# "121 deploy(s) not finalized within 45s" — nodes writing to a full
		# disk, not a finalization regression. Label it and fail closed.
		if [ -z "$BREACH_LINE" ] && [ "$DISK_FREE_FLOOR_MB" -gt 0 ]; then
			DISK_MB="$(disk_free_mb)"
			if [ -n "$DISK_MB" ] && [ "$DISK_MB" -lt "$DISK_FREE_FLOOR_MB" ]; then
				disk_usage_snapshot >"$ITERATION_DIR/disk-floor-breach.txt" 2>/dev/null || true
				BREACH_LINE="iteration $ITERATIONS failed with free disk ${DISK_MB}MB < floor ${DISK_FREE_FLOOR_MB}MB; infrastructure, not a workload verdict"
			fi
		fi
		if [ -n "$BREACH_LINE" ]; then
			EARLY_EXIT_REASON="host_protection_breach"
			printf 'host-protection breach in iteration %s; ending soak (fail-closed)\n' "$ITERATIONS"
			publish_record -t "$OUTPUT_DIR/protection-breach.txt" printf '%s\n' "$BREACH_LINE"
			publish_record "$OUTPUT_DIR/early-exit.txt" printf 'host_protection_breach: iteration %s: %s\n' "$ITERATIONS" "$BREACH_LINE"
			break
		fi
		sleep 30
	fi
	persist_soak_state || exit 2

	if target_ref_moved; then
		EARLY_EXIT_REASON="target_advanced"
		publish_record -t "$OUTPUT_DIR/early-exit.txt" printf '%s advanced past %s; ending soak after iteration %s\n' \
			"$TARGET_REF" "$TARGET_SHA" "$ITERATIONS"
		break
	fi

	if [ "$RUN_BENCHMARKS" = "true" ] && [ "$((ITERATIONS % BENCH_EVERY))" -eq 0 ]; then
		run_bench_segment
		persist_soak_state
	fi

done

# A breach during the final iteration (or one that still exited 0) ends the
# loop by deadline without passing the top-of-loop check, which would let the
# run finish green with the host guardian's marker never surfaced.
if [ -z "$EARLY_EXIT_REASON" ] && [ -s "$HOST_GUARDIAN_BREACH" ]; then
	EARLY_EXIT_REASON="host_protection_breach"
	printf 'orchestrator host guardian fired during the final iteration; recording fail-closed exit\n'
	publish_record -t "$OUTPUT_DIR/protection-breach.txt" head -1 "$HOST_GUARDIAN_BREACH"
	publish_record "$OUTPUT_DIR/early-exit.txt" printf 'host_protection_breach: %s\n' "$(head -1 "$HOST_GUARDIAN_BREACH")"
	FAILURES="$((FAILURES + 1))"
fi

if [ "${EARLY_EXIT_REASON:-}" = host_protection_breach ]; then
	emergency_start
fi
FINISHED_AT="$(date +%s)"

# Written before the rollup so a later segment resumes from accurate counters
# even if the rollup below fails.
persist_soak_state

emit_soak_summary() {
	printf 'started_at=%s\n' "$STARTED_AT"
	printf 'segments=%s\n' "$SEGMENT"
	printf 'finished_at=%s\n' "$FINISHED_AT"
	printf 'target_ref=%s\n' "$TARGET_REF"
	printf 'target_sha=%s\n' "$TARGET_SHA"
	printf 'requested_seconds=%s\n' "$DURATION_SECONDS"
	printf 'elapsed_seconds=%s\n' "$((FINISHED_AT - STARTED_AT))"
	printf 'iterations=%s\n' "$ITERATIONS"
	printf 'failures=%s\n' "$FAILURES"
	printf 'bench_segments=%s\n' "$BENCH_SEGMENTS"
	printf 'bench_failures=%s\n' "$BENCH_FAILURES"
	printf 'early_exit_reason=%s\n' "${EARLY_EXIT_REASON:-none}"
}
publish_record -t "$OUTPUT_DIR/summary.txt" emit_soak_summary

summary_budget() {
	local remaining
	remaining="$(emergency_remaining)"
	[ "$remaining" -ge 5 ] || remaining=5
	printf '%s\n' "$remaining"
}
if command -v jq >/dev/null; then
	SOAK_OUTPUT_DIR="$OUTPUT_DIR" \
		SOAK_METRICS_REGISTRY="$SCRIPT_DIR/bench/soak-metrics.json" \
		SOAK_TARGET_REF="$TARGET_REF" \
		SOAK_TARGET_SHA="$TARGET_SHA" \
		SOAK_TRIGGER_SOURCE="$TRIGGER_SOURCE" \
		SOAK_SLOT_DELAY_SECONDS="$SLOT_DELAY_SECONDS" \
		SOAK_VERSION="$VERSION" \
		SOAK_STARTED_AT="$STARTED_AT" \
		SOAK_FINISHED_AT="$FINISHED_AT" \
		SOAK_DURATION_SECONDS="$DURATION_SECONDS" \
		SOAK_ITERATIONS="$ITERATIONS" \
		SOAK_FAILURES="$FAILURES" \
		SOAK_BENCH_SEGMENTS="$BENCH_SEGMENTS" \
		SOAK_BENCH_FAILURES="$BENCH_FAILURES" \
		session_bounded "$(summary_budget)" "$SCRIPT_DIR/bench/write-soak-summary.sh" ||
		{
			# The full rollup failing must not leave the run without passive data:
			# aggregate-perf-report.sh then emits started_at/elapsed_seconds as
			# null, and Soak Checkpoint Publish rejects that checkpoint outright
			# ("metadata does not match"). Fall back to the counters this script
			# already holds — nulls for the sampled metrics, real values for the
			# run identity and timing the publish contract validates.
			printf 'summary.json emission failed; writing minimal fallback summary\n' >&2
			publish_record "$OUTPUT_DIR/summary.json" jq -n \
				--arg target_ref "$TARGET_REF" \
				--arg target_sha "$TARGET_SHA" \
				--arg trigger_source "$TRIGGER_SOURCE" \
				--argjson slot_delay "$SLOT_DELAY_SECONDS" \
				--arg version "$VERSION" \
				--argjson started "$STARTED_AT" \
				--argjson finished "$FINISHED_AT" \
				--argjson requested "$DURATION_SECONDS" \
				--argjson iterations "$ITERATIONS" \
				--argjson failures "$FAILURES" \
				--argjson bench_segments "$BENCH_SEGMENTS" \
				--argjson bench_failures "$BENCH_FAILURES" \
				'{target_ref: $target_ref, target_sha: $target_sha, version: $version,
          trigger_source: $trigger_source, slot_delay_seconds: $slot_delay,
          started_at: $started, finished_at: $finished,
          requested_seconds: $requested,
          elapsed_seconds: ($finished - $started),
          iterations: $iterations, failures: $failures,
          failure_rate: (if $iterations > 0 then ($failures / $iterations) else 0 end),
          bench_segments: $bench_segments, bench_failures: $bench_failures,
          degraded: "full summary emission failed; sampled metrics missing"}' ||
				printf 'fallback summary emission failed too (non-fatal)\n' >&2
		}
fi

if [ "$CASPER_RUNTIME" -eq 1 ]; then
	if [ "${EARLY_EXIT_REASON:-}" = host_protection_breach ]; then CASPER_TERMINATION=resource_stop;
	elif [ -e "$OUTPUT_DIR/finalize-requested" ]; then CASPER_TERMINATION=cancelled;
	elif [ "$(date +%s)" -ge "$CASPER_DEADLINE" ]; then CASPER_TERMINATION=deadline; fi
	publish_record "$OUTPUT_DIR/casper-result.json" casper_runtime publish --termination "$CASPER_TERMINATION" || exit 2
fi

# Durability is a bounded step so a stalled storage sync never blocks the
# writer stop or the failure publication. A sync that exceeds the budget
# records an explicit unconfirmed result and is not confirmed termination.
reap_publication || true

if [ "$FAILURES" -ne 0 ]; then
	exit 1
fi
