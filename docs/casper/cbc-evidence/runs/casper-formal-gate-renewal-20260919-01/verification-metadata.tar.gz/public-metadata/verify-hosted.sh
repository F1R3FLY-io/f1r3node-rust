#!/usr/bin/env bash
set -euo pipefail
R=target/formal-gate-hosted-35473280388
sha() { shasum -a 256 "$1" | awk '{print $1}'; }
HEAD_SHA=191e184be556c1f190748143377ab369586c53b6
TESTED_SHA=c6db95ceb950ad8ebfcd31c0411964b71ff31387
WORKFLOW_REF=F1R3FLY-io/f1r3node-rust/.github/workflows/slashing-tests.yml@refs/pull/436/merge
[[ "$(git rev-parse HEAD)" == "$HEAD_SHA" ]]
jq -e --arg head "$HEAD_SHA" '.head_sha==$head and .event=="pull_request" and .run_attempt==1 and .repository.full_name=="F1R3FLY-io/f1r3node-rust" and .id==35473280388' "$R/run-initial.json" >/dev/null
jq -e --arg head "$HEAD_SHA" --arg tested "$TESTED_SHA" '.sha==$tested and (.parents|length)==2 and .parents[1].sha==$head' "$R/tested-commit.json" >/dev/null
jq -e '.truncated==false' "$R/tested-tree.json" >/dev/null
for id in 105978029786 105978029962 105978459517 105978576163; do
 jq -e --argjson id "$id" '.jobs[]|select(.id==$id)|.conclusion=="success" and .status=="completed" and all(.steps[]; .conclusion=="success" or .conclusion=="skipped")' "$R/jobs.json" >/dev/null
 if [[ "$id" != 105978459517 ]]; then grep -F "ref: $TESTED_SHA" "$R/job-$id.txt" >/dev/null; fi
 grep -F "HEAD is now at c6db95c Merge $HEAD_SHA into 4ce87b0bb751653a750049934f91318667a265c8" "$R/job-$id.txt" >/dev/null
 done
paths=(.github/workflows/slashing-tests.yml scripts/ci/check-formal-gate.sh scripts/ci/test-check-formal-gate.sh scripts/ci/check-tla-invariants.sh scripts/ci/check-formal-invariants.sh scripts/ci/check-casper-soak-models.sh scripts/bench/casper-soak.sh scripts/casper-soak formal/tlaplus formal/rocq/slashing formal/rocq/fork_choice formal/rocq/rspace_guards Cargo.toml Cargo.lock rust-toolchain.toml .cargo/config.toml)
git ls-files -- "${paths[@]}" | LC_ALL=C sort > "$R/expected-paths.txt"
: > "$R/source-validation.tsv"
while IFS= read -r path; do
 remote_blob=$(jq -er --arg path "$path" '.tree[]|select(.path==$path and .type=="blob" and (.mode=="100644" or .mode=="100755"))|.sha' "$R/tested-tree.json")
 local_blob=$(git rev-parse "$HEAD_SHA:$path")
 [[ "$remote_blob" == "$local_blob" ]] || { printf 'Source differs: %s\n' "$path" >&2; exit 1; }
 digest=$(git show "$HEAD_SHA:$path" | shasum -a 256 | awk '{print $1}')
 printf '%s\t%s\t%s\n' "$path" "$digest" "$local_blob" >> "$R/source-validation.tsv"
done < "$R/expected-paths.txt"
jq -Rn '[inputs|split("\t")|{path:.[0],sha256:.[1]}]|sort_by(.path)' < "$R/source-validation.tsv" > "$R/expected-sources.json"
for kind in tla rocq; do
 job=tla-model-check; [[ "$kind" != rocq ]] || job=rocq-build
 directory="$R/formal-provenance-$kind-35473280388-1"
 jq -Sn --arg job "$job" --arg tested "$TESTED_SHA" --arg ref "$WORKFLOW_REF" --arg workflow "$(sha .github/workflows/slashing-tests.yml)" --slurpfile sources "$R/expected-sources.json" '{schema_version:1,job:$job,repository:"F1R3FLY-io/f1r3node-rust",event:"pull_request",run_id:"35473280388",attempt:"1",tested_sha:$tested,workflow_sha:$tested,workflow_ref:$ref,workflow_control_sha256:$workflow,sources:$sources[0]}' > "$R/expected-$kind-inputs.json"
 cmp "$R/expected-$kind-inputs.json" "$directory/inputs.json"
 jq -S '. + {result:"success"}' "$R/expected-$kind-inputs.json" > "$R/expected-$kind-receipt.json"
 cmp "$R/expected-$kind-receipt.json" "$directory/receipt.json"
done
while IFS=$'\t' read -r id name digest; do
 [[ "sha256:$(sha "$R/$name.zip")" == "$digest" ]]
done < <(jq -r '.artifacts[]|[.id,.name,.digest]|@tsv' "$R/artifacts-initial.json")
printf 'PASS: four hosted jobs, four artifact digests, two exact provenance pairs, and %s source identities.\n' "$(wc -l < "$R/source-validation.tsv" | tr -d ' ')"
