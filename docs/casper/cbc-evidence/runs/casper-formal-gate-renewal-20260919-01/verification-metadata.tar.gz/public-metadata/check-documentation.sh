#!/usr/bin/env bash
set -euo pipefail
R=target/formal-gate-hosted-35473280388
PLAN=${1:-formal/tlaplus/casper_soak/verification-plan.jsonc}
sha() { shasum -a 256 "$1" | awk '{print $1}'; }
jq -e --slurpfile before "$R/prior/verification-plan.jsonc" '
 def operational: del(.evidence_report,.documentation_review);
 (operational)==($before[0]|operational) and
 .status=="bounded-pre-merge-binding-accepted" and .soak=="pending" and .live_adapter_qualification=="pending" and .post_merge_verification=="blocked" and
 .binding.status=="passed" and .binding.registered_cases==48 and .binding.required_invocations==91 and
 (.profile_verification.claims|length)==7' "$PLAN" >/dev/null
jq -er '[.binding.fixture_digest,.binding.fixtures]|@tsv' "$PLAN" | while IFS=$'\t' read -r digest path; do test "$(sha "$path")" = "$digest"; done
jq -er '.profile_verification.claims[]|[.id,.specification,.verification_plan,.accepted_report]|@tsv' "$PLAN" | while IFS=$'\t' read -r id spec profile report; do
 for required in "$spec" "$profile" "$report"; do test -f "$required"; done
 expected=$(jq -er --arg report "$report" '.accepted_reports[]|select(.ref==$report)|.sha256' docs/casper/cbc-evidence/runs/casper-pre-merge-review-20260919-01/report.json)
 test "$(sha "$report")" = "$expected"
 grep -Fxq "claim_id: $id" "$spec"
 grep -Fxq 'status: discharged' "$spec"
 grep -Fxq 'binding: passed' "$spec"
 grep -Fxq 'soak: pending' "$spec"
 jq -e --arg id "$id" '.claim==$id and .positive_control.expected_exit==0 and (.negative_controls|length)==3 and all(.negative_controls[];.expected_exit==12)' "$profile" >/dev/null
 jq -e --arg spec "$spec" --arg digest "$(sha "$spec")" '.claim_digests[$spec]==$digest and .tiers.refutation=="bounded-safety-pass" and .tiers.construction=="not-applicable" and .tiers.binding=="passed"' "$report" >/dev/null
 while IFS=$'\t' read -r digest source; do test "$(sha "$source")" = "$digest"; done < <(jq -er '.source_digests|to_entries[]|[.value,.key]|@tsv' "$report")
 jq -e --slurpfile root "$PLAN" '.bounds==$root[0].profile_verification.bounds' "$profile" >/dev/null
done
report=$(jq -er '.evidence_report' "$PLAN")
test "$report" = docs/casper/cbc-evidence/runs/casper-formal-gate-renewal-20260919-01/report.json
test -f "$report"
jq -e --arg digest "$(sha docs/claims/casper-soak-harness.md)" '.claim_digests["docs/claims/casper-soak-harness.md"]==$digest and .claim_discharge=="discharged" and .tiers.binding=="passed" and .soak=="pending" and .governance_claim.status=="pending"' "$report" >/dev/null
while IFS=$'\t' read -r digest source; do test "$(sha "$source")" = "$digest"; done < <(jq -er '.source_digests|to_entries[]|[.value,.key]|@tsv' "$report")
jq -e --arg plan_sha "$(sha formal/tlaplus/casper_soak/verification-plan.jsonc)" '.plan_sha256==$plan_sha and .status=="passed" and (.results|length)==11 and all(.results[];.outcome=="passed") and .results[0].exit==0 and .results[0].states_generated==66208 and .results[0].distinct_states==43424 and all(.results[1:][];.exit==12)' "$R/documentation-models/report.json" >/dev/null
while IFS=$'\t' read -r digest log; do test "$(sha "$R/documentation-models/$log")" = "$digest"; done < <(jq -er '.results[]|[.log_sha256,.log]|@tsv' "$R/documentation-models/report.json")
printf 'Documentation consistency passed with unchanged executable plan inputs.\n'
