#!/usr/bin/env bash
set -euo pipefail
OUT=target/claim001-inventory-renewal
IMAGE="$(jq -r .image "$OUT/isolated/report.json")"
TEST="$(jq -rs '[.[]|select(.reason=="compiler-artifact" and .target.name=="casper-soak" and .profile.test==true and .executable!=null)|.executable]|last' "$OUT/isolated/build.jsonl")"
[[ -x "$TEST" ]]
CONTAINER="$(docker create --pull=never --network none --cap-drop ALL --security-opt no-new-privileges --pids-limit 64 --memory 256m --cpus 2 --user 0:0 --entrypoint timeout "$IMAGE" --signal=TERM --kill-after=5 60 /case/root-test --include-ignored --test-threads=1)"
finish() { status=$?; trap - EXIT; docker inspect "$CONTAINER" > "$OUT/root-finished.json"; docker rm -f "$CONTAINER" > "$OUT/root-cleanup.txt"; exit "$status"; }
trap finish EXIT
docker inspect "$CONTAINER" > "$OUT/root-container.json"
jq -e '.[0]|(.Mounts|length)==0 and .Config.User=="0:0" and .HostConfig.NetworkMode=="none" and .HostConfig.Privileged==false and .HostConfig.PidMode==""' "$OUT/root-container.json" >/dev/null
docker cp "$TEST" "$CONTAINER:/case/root-test" >/dev/null
shasum -a 256 "$TEST" > "$OUT/root-test.sha256"
timeout --kill-after=5 75 docker start -a "$CONTAINER" > "$OUT/root-tests.txt" 2>&1
grep -F 'test result: ok. 8 passed; 0 failed; 0 ignored;' "$OUT/root-tests.txt" >/dev/null
