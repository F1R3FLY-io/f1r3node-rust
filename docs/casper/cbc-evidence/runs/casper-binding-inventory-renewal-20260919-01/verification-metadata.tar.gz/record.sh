#!/usr/bin/env bash
set -euo pipefail
OUT=target/claim001-inventory-renewal
NEW=docs/casper/cbc-evidence/runs/casper-binding-inventory-renewal-20260919-01
SPEC=docs/claims/casper-soak-harness.md
OLD=docs/casper/cbc-evidence/runs/casper-driver-refresh-acceptance-20260919-01/report.json
sha() { shasum -a 256 "$1" | awk '{print $1}'; }
[[ ! -e "$NEW" && "$(git rev-parse HEAD)" == "$(<"$OUT/base-revision.txt")" ]]
[[ "$(<"$OUT/isolated.exit")" == 0 && "$(<"$OUT/models.exit")" == 0 && "$(<"$OUT/root.exit")" == 0 ]]
shasum -a 256 -c "$OUT/current-artifacts.sha256" > "$OUT/artifact-recheck.txt"
shasum -a 256 -c "$OUT/protected.sha256" > "$OUT/protected-before-record.txt"
jq -e '.status=="passed" and .exit_code==0 and .node_execution==false' "$OUT/isolated/report.json" >/dev/null
jq -e '.driver_invocations==91 and .registered_cases==48 and .matched_exits==true' "$OUT/isolated/evidence/counts.json" >/dev/null
for file in "$OUT/isolated/finished.json" "$OUT/root-finished.json"; do jq -e '.[0].State|.Running==false and .OOMKilled==false and .ExitCode==0' "$file" >/dev/null; done
jq -e '.[0]|(.Mounts|length)==0 and .HostConfig.NetworkMode=="none" and .HostConfig.Privileged==false and .Config.User=="65534:65534" and .HostConfig.PidsLimit==192 and .HostConfig.Memory==536870912 and .HostConfig.NanoCpus==2000000000 and (.HostConfig.CapDrop|index("ALL")!=null) and (.HostConfig.SecurityOpt|index("no-new-privileges")!=null)' "$OUT/isolated/container.json" >/dev/null
jq -e '.status=="passed" and (.results|length)==11 and .results[0].exit==0 and .results[0].states_generated==66208 and .results[0].distinct_states==43424 and all(.results[1:][]; .exit==12 and .outcome=="passed")' "$OUT/models/report.json" >/dev/null
jq -r '.results[]|[.configuration,.configuration_sha256,.model_sha256,.log,.log_sha256,(.expected_property // "clean")]|@tsv' "$OUT/models/report.json" > "$OUT/model-checks.tsv"
while IFS=$'\t' read -r config cfg_sha model_sha log log_sha property; do
 [[ "$(sha "formal/tlaplus/casper_soak/$config")" == "$cfg_sha" && "$(sha formal/tlaplus/casper_soak/CasperSoakHarness.tla)" == "$model_sha" && "$(sha "$OUT/models/$log")" == "$log_sha" ]]
 if [[ "$property" == clean ]]; then
  grep -F 'Model checking completed. No error has been found.' "$OUT/models/$log" >/dev/null
  ! grep -q '^Error:' "$OUT/models/$log"
 else
  grep -Fx "Error: Invariant $property is violated." "$OUT/models/$log" >/dev/null
  grep -F 'State 1: <Initial predicate>' "$OUT/models/$log" >/dev/null
  awk -v expected="Error: Invariant $property is violated." '/^Error:/ && $0!=expected && $0!="Error: The behavior up to this point is:" {bad=1} END {exit bad}' "$OUT/models/$log"
 fi
done < "$OUT/model-checks.tsv"
[[ "$(<"$OUT/red-audit.exit")" == 2 && "$(<"$OUT/green-audit.exit")" == 0 && "$(<"$OUT/green-strict.exit")" == 4 ]]
for file in "$OUT"/omissions/*.exit; do [[ "$(<"$file")" == 2 ]]; done
[[ "$(find "$OUT/omissions" -name '*.exit' | wc -l | tr -d ' ')" == 7 ]]
mkdir "$NEW" "$OUT/renewed-ledgers"
COPYFILE_DISABLE=1 tar -czf "$NEW/previous-metadata.tar.gz" -C "$OUT" previous-ledgers prior
SPEC_SHA="$(sha "$SPEC")"
PREVIOUS_SHA="$(sha "$NEW/previous-metadata.tar.gz")"
TIME="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
jq -Rn '[inputs|capture("^(?<sha>[0-9a-f]{64})  (?<path>.+)$")]|map({key:.path,value:.sha})|from_entries' < "$OUT/current-artifacts.sha256" > "$OUT/source-digests.json"
jq -n --slurpfile sources "$OUT/source-digests.json" --slurpfile models "$OUT/models/report.json" --slurpfile binding "$OUT/isolated/report.json" --slurpfile counts "$OUT/isolated/evidence/counts.json" --slurpfile accepted "$OLD" --arg spec "$SPEC" --arg spec_sha "$SPEC_SHA" --arg old_spec "$(sha "$OUT/prior/claim.md")" --arg base "$(git rev-parse HEAD)" --arg time "$TIME" --arg old "$OLD" --arg old_sha "$(sha "$OLD")" --arg previous "$NEW/previous-metadata.tar.gz" --arg previous_sha "$PREVIOUS_SHA" --arg patch_sha "$(sha "$OUT/inventory-repair.patch")" --arg inventory_sha "$(sha "$OUT/isolated/sources.sha256")" '{schema_version:1,status:"renewed-bounded-harness-binding",claim_ids:["CLAIM-CASPER-SOAK-001"],claim_discharge:"discharged",scope:"bounded-harness-only",phase:"pre_pr216_merge",base_commit:$base,working_tree:true,recorded_at:$time,source_digests:$sources[0],claim_digests:{($spec):$spec_sha},tiers:{refutation:"bounded-safety-pass",construction:"not-applicable",binding:"passed"},authorization:{request:"it is commited. Complete Claim001 renewal",scope:"Renew the existing bounded H01-H10 binding after the profile-workflow inventory repair.",recorded_at:$time},previous_acceptance:{ref:$old,sha256:$old_sha},previous_metadata:{path:$previous,sha256:$previous_sha,ledgers:39,pre_renewal_specification_sha256:$old_spec},change:{path:"scripts/ci/check-casper-soak-bindings.sh",before:$accepted[0].source_digests["scripts/ci/check-casper-soak-bindings.sh"],after:$sources[0]["scripts/ci/check-casper-soak-bindings.sh"],patch_sha256:$patch_sha,added_line:"FILES+=(.github/workflows/casper-*.yml)",unchanged_other_artifacts:38,runtime_changed:false,assertions_changed:false},copy_controls:{missing_all_seven_exit:2,missing_individual_workflow_exits:[2,2,2,2,2,2,2],restored_plain_audit_exit:0,pre_renewal_strict_exit:4,profile_workflow_count:7},verification:{isolated:$binding[0],inventory:$counts[0],isolated_passed_tests:29,unprivileged_root_test_ignored:1,separate_root_passed_tests:8,source_inventory_sha256:$inventory_sha,model:$models[0]},bounds:{candidates:2,segments:2,iterations_total:4,active_children:1},retained_limitations:$accepted[0].limits,hosted_execution:"not-rerun-for-this-renewal",other_claims:"unchanged-independent-discharges",soak:"pending",live_adapters:"unqualified",node_execution:false,policy_activation:false,post_merge_execution:"blocked",waiver:null}' > "$NEW/report.json"
REPORT_SHA="$(sha "$NEW/report.json")"
: > "$OUT/ledgers.patch"
for prior in "$OUT"/previous-ledgers/*.md; do
 name="${prior##*/}"; current="docs/casper/cbc-evidence/$name"
 cmp "$prior" "$current"
 body="$(awk '/^```json$/{a=1;next} /^```$/{a=0} a{print}' "$current")"
 path="$(jq -r .artifact.path <<< "$body")"
 {
  printf '# CbC Evidence: %s\n\nThe user authorized renewal of the existing bounded H01–H10 binding after the workflow inventory repair. This discharge covers only the pre-merge harness.\n\nPrevious evidence and containment limitations remain preserved. Node execution and post-merge work remain outside this renewal.\n\n```json\n' "$path"
  jq --arg spec "$SPEC" --arg spec_sha "$SPEC_SHA" --arg source_sha "$(sha "$path")" --arg base "$(git rev-parse HEAD)" --arg report "$NEW/report.json" --arg report_sha "$REPORT_SHA" --arg time "$TIME" --arg previous "$NEW/previous-metadata.tar.gz" --arg previous_sha "$PREVIOUS_SHA" --arg name "$name" --arg member_sha "$(sha "$prior")" '.artifact.commit=$base | .artifact.commit_is_base=true | .artifact.working_tree=true | .artifact.sha256=$source_sha | .claim_digests[$spec]=$spec_sha | .status="discharged" | .evidence={kind:"renewed-bounded-inventory-binding",ref:$report,sha256:$report_sha} | .verified_at=$time | .previous_ledger={path:$previous,sha256:$previous_sha,member:("previous-ledgers/"+$name),member_sha256:$member_sha}' <<< "$body"
  printf '```\n'
 } > "$OUT/renewed-ledgers/$name"
 code=0
 diff -u --label "a/$current" --label "b/$current" "$current" "$OUT/renewed-ledgers/$name" >> "$OUT/ledgers.patch" || code=$?
 [[ "$code" == 1 ]]
done
git apply --check "$OUT/ledgers.patch"
git apply "$OUT/ledgers.patch"
target/release/check-casper-claims --root . --output "$OUT/renewed-claim001.json" --strict --claim CLAIM-CASPER-SOAK-001
target/release/check-casper-claims --root . --output "$OUT/renewed-bundle.json" --strict
jq -e '.claim_discharge=="discharged" and (.claims|length)==8 and all(.claims[]; .status=="discharged" and .soak=="pending")' "$OUT/renewed-bundle.json" >/dev/null
printf 'Claim001 and all eight claims pass strict source-bound audits.\n'
