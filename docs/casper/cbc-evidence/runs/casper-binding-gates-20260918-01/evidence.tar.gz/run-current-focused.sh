#!/usr/bin/env bash
set -euo pipefail
OUT="$1"
mkdir "$OUT"
OUT="$(cd "$OUT" && pwd)"
RUSTFLAGS='-C linker=rust-lld -C link-self-contained=yes -C target-feature=+crt-static' cargo test --locked --offline -p casper-soak --target aarch64-unknown-linux-musl --no-run --message-format=json >"$OUT/build.jsonl" 2>"$OUT/build.txt"
ID="$(docker create --pull=never --network none --cap-drop ALL --security-opt no-new-privileges --pids-limit 192 --memory 512m --cpus 2 --user 65534:65534 --entrypoint timeout sha256:7d402dd7f1922bcdbdbeb90d14cecf398fdd36bc5105242fa4a4dc1d1cd596c5 --signal=TERM --kill-after=5 80 bash -euc 'mkdir /case/evidence; export SOAK_SOURCE_ROOT=/case/repo SOAK_HARNESS_BIN=/case/casper-soak SOAK_TEST_ARTIFACTS=/case/evidence SOAK_BINDING_CHECKER_BIN=/case/check-casper-bindings; for suite in bindings interruption; do /case/test-$suite --test-threads=1 >/case/evidence/$suite.txt 2>&1; done; /case/test-driver linux::terminal_between_admission_and_executor --exact --test-threads=1 >/case/evidence/driver.txt 2>&1')"
trap 'docker rm -f "$ID" >"$OUT/cleanup.txt" 2>&1' EXIT
gtar -cf - Cargo.toml Cargo.lock scripts/run-merge-recovery-soak.sh scripts/casper-soak scripts/ci/check-casper-soak-bindings.sh scripts/bench docs/casper/cbc-evidence/runs/casper-rust-migration-20260917-01/bindings.tar.gz | docker cp - "$ID:/case/repo/"
for name in casper-soak check-casper-bindings; do
  BIN="$(jq -rs --arg name "$name" '[.[]|select(.reason=="compiler-artifact" and .target.name==$name and .profile.test==false and .executable!=null)|.executable]|last' "$OUT/build.jsonl")"
  docker cp "$BIN" "$ID:/case/$name" >/dev/null
done
for name in driver bindings interruption; do
  BIN="$(jq -rs --arg name "$name" '[.[]|select(.reason=="compiler-artifact" and .target.name==$name and .profile.test==true and .executable!=null)|.executable]|last' "$OUT/build.jsonl")"
  docker cp "$BIN" "$ID:/case/test-$name" >/dev/null
done
status=0
timeout --signal=TERM --kill-after=5 100 docker start -a "$ID" >"$OUT/run.txt" 2>&1 || status=$?
printf '%s\n' "$status" >"$OUT/exit.txt"
docker inspect --format '{{json .State}}' "$ID" >"$OUT/state.json"
docker cp "$ID:/case/evidence" "$OUT/evidence" >/dev/null
exit "$status"
