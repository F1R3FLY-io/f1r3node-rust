#!/usr/bin/env bash
set -euo pipefail
OUT="$1"
mkdir "$OUT"
OUT="$(cd "$OUT" && pwd)"
RUSTFLAGS='-C linker=rust-lld -C link-self-contained=yes -C target-feature=+crt-static' cargo test --locked --offline -p casper-soak --target aarch64-unknown-linux-musl --no-run --message-format=json >"$OUT/build.jsonl" 2>"$OUT/build.txt"
BIN="$(jq -rs '[.[]|select(.reason=="compiler-artifact" and .target.name=="casper-soak" and .profile.test==false and .executable!=null)|.executable]|last' "$OUT/build.jsonl")"
TEST="$(jq -rs '[.[]|select(.reason=="compiler-artifact" and .target.name=="driver" and .profile.test==true and .executable!=null)|.executable]|last' "$OUT/build.jsonl")"
ID="$(docker create --pull=never --network none --cap-drop ALL --security-opt no-new-privileges --pids-limit 192 --memory 512m --cpus 2 --user 65534:65534 --entrypoint bash sha256:7d402dd7f1922bcdbdbeb90d14cecf398fdd36bc5105242fa4a4dc1d1cd596c5 -euc 'mkdir /case/evidence; export SOAK_SOURCE_ROOT=/case/repo SOAK_HARNESS_BIN=/case/casper-soak SOAK_TEST_ARTIFACTS=/case/evidence; /case/test-driver linux::terminal_between_admission_and_executor --exact --test-threads=1')"
trap 'docker rm -f "$ID" >"$OUT/cleanup.txt" 2>&1' EXIT
gtar -cf - Cargo.toml Cargo.lock scripts/run-merge-recovery-soak.sh scripts/casper-soak scripts/bench | docker cp - "$ID:/case/repo/"
docker cp "$BIN" "$ID:/case/casper-soak" >/dev/null
docker cp "$TEST" "$ID:/case/test-driver" >/dev/null
status=0
timeout --signal=TERM --kill-after=5 90 docker start -a "$ID" >"$OUT/run.txt" 2>&1 || status=$?
printf '%s\n' "$status" >"$OUT/exit.txt"
docker inspect --format '{{json .State}}' "$ID" >"$OUT/state.json"
docker cp "$ID:/case/evidence" "$OUT/evidence" >/dev/null
exit "$status"
