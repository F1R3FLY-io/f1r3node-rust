#!/usr/bin/env bash
set -euo pipefail
OUT="$PWD/target/task-017-8/linux-final"
[[ ! -e "$OUT" ]]
mkdir "$OUT"
IMAGE=sha256:7d402dd7f1922bcdbdbeb90d14cecf398fdd36bc5105242fa4a4dc1d1cd596c5
C="$(docker create --pull=never --network none --cap-drop ALL --security-opt no-new-privileges --pids-limit 128 --memory 512m --cpus 2 --user 65534:65534 --entrypoint timeout "$IMAGE" --kill-after=5 240 bash -c '
export SOAK_ACCOUNTING_EVIDENCE=/case/evidence/fixtures
mkdir /case/evidence
/case/test-accounting --test-threads=1 > /case/evidence/tests.txt 2>&1
')"
trap 'docker stop --time 2 "$C" >/dev/null 2>&1 || true; docker cp "$C:/case/evidence" "$OUT/interrupted-evidence" >/dev/null 2>&1 || true; docker rm -f "$C" >/dev/null 2>&1 || true' EXIT
docker inspect "$C" >"$OUT/container.json"
TEST="$(jq -rs '[.[] | select(.reason=="compiler-artifact" and .target.name=="merge_accounting" and .profile.test==true and .executable!=null) | .executable] | last' target/task-017-8/linux-build.jsonl)"
docker cp "$TEST" "$C:/case/test-accounting" >/dev/null
shasum -a 256 "$TEST" >"$OUT/binaries.sha256"
COPYFILE_DISABLE=1 gtar --owner=0 --group=0 --numeric-owner --mode=a+rX --transform "s|^|${PWD#/}/|" -cf - target/aarch64-unknown-linux-musl/debug/casper-merge-accounting | docker cp - "$C:/"
shasum -a 256 target/aarch64-unknown-linux-musl/debug/casper-merge-accounting >>"$OUT/binaries.sha256"
status=0
timeout --kill-after=5 250 docker start -a "$C" >"$OUT/run.txt" 2>&1 || status=$?
printf '%s\n' "$status" >"$OUT/exit.txt"
docker inspect "$C" >"$OUT/finished.json"
docker cp "$C:/case/evidence" "$OUT/evidence" >/dev/null
docker rm -f "$C" >"$OUT/cleanup.txt"
trap - EXIT
shasum -a 256 -c "$OUT/binaries.sha256" >"$OUT/binary-check.txt"
exit "$status"
