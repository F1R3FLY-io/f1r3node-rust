#!/usr/bin/env bash
set -euo pipefail
ROOT="$PWD"
WORK=target/task-017-7
STAGE=target/task-017-7-retention
PKG=docs/casper/cbc-evidence/runs/casper-recovery-20260918-01
BASE=a94c5655ee2284e228667a02e357a6ef6cd10ebf
SPEC=docs/claims/casper-soak-recovery.md
[[ ! -e "$STAGE" && ! -e "$PKG" ]]
mkdir -p "$STAGE/source" "$STAGE/support" "$PKG"
shasum -a 256 -c "$WORK/final-source/source-before.sha256" >"$WORK/final-source-check.txt"
git status --porcelain >"$WORK/git-status.txt"
git rev-parse HEAD >"$WORK/head.txt"
git diff --name-only "$BASE" >"$WORK/changed-tracked.txt"
bash -n scripts/casper-soak/check-recovery.sh
rustfmt --edition 2021 --check scripts/casper-soak/src/bin/casper-recovery.rs scripts/casper-soak/src/profiles/recovery.rs scripts/casper-soak/tests/recovery.rs >"$WORK/final-format.txt" 2>&1
git diff --check >"$WORK/final-diff.txt" 2>&1
cp "$WORK/final-source/source-before.sha256" "$PKG/source-files.sha256"
shasum -a 256 docs/work-logs/task-017-7-recovery.md >>"$PKG/source-files.sha256"
while read -r digest path; do mkdir -p "$STAGE/source/$(dirname "$path")"; cp "$path" "$STAGE/source/$path"; done <"$PKG/source-files.sha256"
cp -R "$WORK" "$STAGE/evidence"
cp target/casper-task-017-4-finish/redact.rs "$STAGE/support/redact.rs"
cp "$0" "$STAGE/support/retain.sh"
cp docs/ToDos.md "$STAGE/support/ToDos.md"
cp scripts/run-merge-recovery-soak.sh "$STAGE/support/current-driver.sh"
git show b5c24da0217465eeef5fb07e3d9126fb759a5b59:scripts/run-merge-recovery-soak.sh >"$STAGE/support/prior-driver.sh"
[[ "$(shasum -a 256 "$STAGE/support/prior-driver.sh" | awk '{print $1}')" == 7f4ba9b1c9078c984251317a4cb5032772a092645bfb83d07f6950c0b43542b2 ]]
find "$STAGE/evidence" -type f -exec chmod u+w {} +
target/casper-task-017-4-finish/redact-bin "$STAGE/evidence" "$ROOT" "$HOME" >"$PKG/redactions.tsv"
find "$STAGE/evidence" -type l | sort | while read -r path; do printf '%s\t%s\n' "${path#"$STAGE/evidence/"}" "$(readlink "$path")"; done >"$PKG/symlinks.tsv"
(cd "$STAGE/evidence" && find . -type f -print0 | sort -z | xargs -0 shasum -a 256) >"$PKG/evidence-files.sha256"
for part in source evidence support; do gtar --owner=0 --group=0 --numeric-owner --no-xattrs --no-acls --sort=name -czf "$PKG/$part.tar.gz" -C "$STAGE/$part" .; done
cp "$STAGE/evidence/final-source/models/report.json" "$PKG/models.json"
cp "$STAGE/evidence/final-source/models/profile-model.json" "$PKG/model-layout.json"
cp "$STAGE/evidence/claim-audit-attempts.json" "$PKG/claim-audit-attempts.json"
cp "$WORK/lsp.json" "$PKG/lsp.json"
find "$STAGE/evidence/final-source/fixtures" -name 'invocation-*.json' -exec jq -c '{arguments,expected_exit,actual_exit,expected_verdict,observed_verdict:(.stdout|fromjson|.scenario_verdict)}' {} \; | jq -s 'sort_by(.arguments,.expected_verdict)' >"$PKG/fixture-inventory.json"
awk '{printf "{\"path\":\"%s\",\"sha256\":\"%s\"}\n",$2,$1}' "$PKG/source-files.sha256" | jq -s 'map({key:.path,value:.sha256})|from_entries' >"$STAGE/source-digests.json"
STAMP="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
SPEC_SHA="$(shasum -a 256 "$SPEC" | awk '{print $1}')"
LINUX_SHA="$(shasum -a 256 target/aarch64-unknown-linux-musl/debug/casper-recovery | awk '{print $1}')"
jq -n --arg stamp "$STAMP" --arg base "$BASE" --arg spec "$SPEC" --arg spec_sha "$SPEC_SHA" --arg linux "$LINUX_SHA" --arg source "$(shasum -a 256 "$PKG/source.tar.gz" | awk '{print $1}')" --arg evidence "$(shasum -a 256 "$PKG/evidence.tar.gz" | awk '{print $1}')" --arg support "$(shasum -a 256 "$PKG/support.tar.gz" | awk '{print $1}')" --slurpfile source_digests "$STAGE/source-digests.json" --slurpfile identity "$WORK/final-source/identity.json" --slurpfile audits "$PKG/claim-audit-attempts.json" '{schema_version:1,run_id:"casper-recovery-20260918-01",claim_ids:["CLAIM-CASPER-SOAK-004"],status:"profile-checks-passed-shared-gate-blocked",phase:"pre_pr216_merge",implementation_base:$base,commit_is_base:true,worktree_dirty:true,verified_at:$stamp,scope:"controlled-transcript-profile-and-bounded-refutation",node_execution:false,proof_execution:false,unbounded_proof:false,refutation_executed:true,source_digests:$source_digests[0],claim_digests:{($spec):$spec_sha},executables:{native_sha256:$identity[0].executable_sha256,linux_musl_sha256:$linux},archives:{"source.tar.gz":$source,"evidence.tar.gz":$evidence,"support.tar.gz":$support},tiers:{refutation:"bounded-safety-pass",construction:"not-applicable",binding:"pending-review",soak:"pending"},checks:{rust_tests:7,fixture_cases:52,profile_invocations:55,clean_distinct_states:441,clean_generated_states:841,negative_controls:3,regressions:{passed:24,failed:1,command_exit:101,failing_test:"pending_claims_are_visible_and_strict_discharge_refuses"},linux_cross_build:"passed",linux_execution:"not-run-docker-unavailable",native_test_optimization:0,linux_test_optimization:1,java:"26.0.2.1",tlc:"2.19",tlc_jar_sha256:"936a262061c914694dfd669a543be24573c45d5aa0ff20a8b96b23d01e050e88",rustfmt:"passed",bash_syntax:"passed",ste_check:"passed",strict_claim_001_exit:2,strict_claim_004_exit:2},shared_gate_blocker:$audits[0].cause,final_evidence:"evidence.tar.gz:final-source",failure_history:["initial-check: helper argument-count compilation failure","unknown-count-red: missing terminal values became zero, exit 101","capture-order-red: early snapshot passed, exit 101","independent-red: tool timeout after 120 seconds, final test status unknown","independent-red-retry: missing occurrences erased a telemetry failure, exit 101","schema-copy-red: wrong schema and conflicting-copy tests failed, exit 101","regressions and complete retry: shared source audit failed, exit 101","strict CLAIM-001 and CLAIM-004 audits: upstream source mismatch, exit 2","Docker socket unavailable"],red_source_snapshots:["unknown-count-red-source.tar.gz","capture-order-red-source.tar.gz","independent-red-source.tar.gz","schema-copy-red-source.tar.gz"],retention_transformations:["Exact workspace and home prefixes replaced in text with recorded before/after hashes.","Numeric archive owners, no xattrs, and no ACLs.","Evidence staging files have owner-write permission. Original filesystem modes are not claimed."],limits:["Human binding acceptance remains pending.","The shared discharged driver source changed outside this task and requires separate verification.","The new workflow mandatory tag remains unratified and unapplied.","Linux and hosted CI execution remain unverified.","All live, experimental-policy, and post-merge requests remain blocked.","D-07 occurrence and reason-join availability remains unresolved for dev.","Cross-clock duration normalization is unsupported.","The model assumes valid auxiliary fields and excludes independent failures.","The initial arity error has no complete source snapshot.","Publication receipt-conflict ordering requires separate review before CLAIM-003 acceptance.","External index changes were preserved."],waiver:null}' >"$PKG/report.json"
REPORT_SHA="$(shasum -a 256 "$PKG/report.json" | awk '{print $1}')"
awk '/^artifacts:/{inside=1;next} inside && /^  - /{sub(/^  - /,""); print;next} inside {exit}' "$SPEC" >"$STAGE/artifacts.txt"
while read -r path; do
    slug="$(printf '%s' "${path#.}" | tr '/._' '---')"
    ledger="docs/casper/cbc-evidence/$slug.md"
    link="docs/cbc-evidence/$slug.md"
    [[ ! -e "$ledger" && ! -L "$ledger" && ! -e "$link" && ! -L "$link" ]]
    {
        printf '# CbC Evidence: %s\n\nThe bounded model and controlled fixtures pass. Human binding acceptance remains pending. The shared audit remains blocked by driver source changes. This record does not discharge the claim.\n\n```json\n' "$path"
        jq -n --arg path "$path" --arg slug "$slug" --arg base "$BASE" --arg digest "$(shasum -a 256 "$path" | awk '{print $1}')" --arg spec "$SPEC" --arg spec_sha "$SPEC_SHA" --arg report "$PKG/report.json" --arg report_sha "$REPORT_SHA" --arg stamp "$STAMP" '{artifact:{path:$path,id:$slug,commit:$base,commit_is_base:true,sha256:$digest},claim:$spec,claim_ids:["CLAIM-CASPER-SOAK-004"],claim_digests:{($spec):$spec_sha},adapter:"embedded",status:"pending",scope:"bounded-recovery-profile",evidence:{kind:"bounded-refutation-and-executable-fixtures",ref:$report,sha256:$report_sha},tiers:{refutation:"bounded-safety-pass",construction:"not-applicable",binding:"pending-review"},phase_status:{pre_pr216_merge:"pending",post_pr216_merge:"blocked"},soak:"pending",waiver:null,verified_at:$stamp}'
        printf '```\n'
    } >"$ledger"
    ln -s "../casper/cbc-evidence/$slug.md" "$link"
done <"$STAGE/artifacts.txt"
(cd "$PKG" && find . -maxdepth 1 -type f ! -name artifacts.sha256 -print0 | sort -z | xargs -0 shasum -a 256) >"$PKG/artifacts.sha256"
printf '%s\n' "$REPORT_SHA"
