#!/usr/bin/env bash
set -euo pipefail
OUT="$PWD/target/casper-profile-completion/linux"
[[ ! -e "$OUT" ]]
mkdir "$OUT"
IMAGE=sha256:7d402dd7f1922bcdbdbeb90d14cecf398fdd36bc5105242fa4a4dc1d1cd596c5
C="$(docker create --pull=never --network none --cap-drop ALL --security-opt no-new-privileges --pids-limit 128 --memory 512m --cpus 2 --user 65534:65534 --entrypoint timeout "$IMAGE" --kill-after=5 240 bash -c '
export SOAK_SOURCE_ROOT=/case/repo
export SOAK_AUTHORITY_EVIDENCE=/case/evidence/authority-fixtures
export SOAK_PUBLICATION_EVIDENCE=/case/evidence/publication-fixtures
export SOAK_RECOVERY_EVIDENCE=/case/evidence/recovery-fixtures
status=0
mkdir /case/evidence
for name in authority_finality publication recovery authority-unit; do
 /case/test-$name --test-threads=1 >"/case/evidence/$name.txt" 2>&1 || status=1
done
exit "$status"
')"
trap 'docker stop --time 2 "$C" >/dev/null 2>&1 || true; docker cp "$C:/case/evidence" "$OUT/interrupted-evidence" >/dev/null 2>&1 || true; docker rm -f "$C" >/dev/null 2>&1 || true' EXIT

docker inspect "$C" >"$OUT/container.json"
COPYFILE_DISABLE=1 gtar -cf - Cargo.toml Cargo.lock scripts/casper-soak scripts/run-merge-recovery-soak.sh scripts/bench/casper-soak.sh scripts/bench/write-soak-summary.sh scripts/bench/collect-soak-metrics.sh scripts/bench/soak-metrics.json formal/tlaplus/casper_soak | docker cp - "$C:/case/repo/"
for name in authority_finality publication recovery authority-unit; do
 target="$name"
 [[ "$name" != authority-unit ]] || target=casper-authority-finality
 TEST="$(jq -rs --arg target "$target" '[.[] | select(.reason=="compiler-artifact" and .target.name==$target and .profile.test==true and .executable!=null) | .executable] | last' target/casper-profile-completion/linux-build.jsonl)"
 docker cp "$TEST" "$C:/case/test-$name" >/dev/null
 shasum -a 256 "$TEST" >>"$OUT/binaries.sha256"
done
COPYFILE_DISABLE=1 gtar --owner=0 --group=0 --numeric-owner --mode=a+rX --transform "s|^|${PWD#/}/|" -cf - target/aarch64-unknown-linux-musl/debug/casper-{authority-finality,publication,recovery} | docker cp - "$C:/"
shasum -a 256 target/aarch64-unknown-linux-musl/debug/casper-{authority-finality,publication,recovery} >>"$OUT/binaries.sha256"
status=0
timeout --kill-after=5 250 docker start -a "$C" >"$OUT/run.txt" 2>&1 || status=$?
printf '%s\n' "$status" >"$OUT/exit.txt"
docker inspect "$C" >"$OUT/finished.json"
docker cp "$C:/case/evidence" "$OUT/evidence" >/dev/null
docker rm -f "$C" >"$OUT/cleanup.txt"
trap - EXIT
shasum -a 256 -c "$OUT/binaries.sha256" >"$OUT/binary-check.txt"
exit "$status"
