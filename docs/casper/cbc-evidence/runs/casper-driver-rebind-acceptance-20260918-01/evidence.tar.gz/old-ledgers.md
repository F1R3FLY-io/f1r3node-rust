
FILE: docs/casper/cbc-evidence/formal-tlaplus-casper-soak-CasperSoakHarness-tla.md
# CbC Evidence: formal/tlaplus/casper_soak/CasperSoakHarness.tla

The user accepted the bounded H01–H10 binding review. This record discharges only CLAIM-CASPER-SOAK-001 in the pre-merge phase.

Profile verification, node soaks, post-merge work, and inherited containment limits remain separate. Earlier ledger bytes remain in the linked archive.

```json
{
  "artifact": {
    "path": "formal/tlaplus/casper_soak/CasperSoakHarness.tla",
    "id": "formal-tlaplus-casper-soak-CasperSoakHarness-tla",
    "commit": "946743a7740e5dd3c0816263c3347e501f2d50d7",
    "sha256": "e08ce354f1e09b9f0873e6f730e509c4be6b394acc0bce7ff5ef53805d91b0c4",
    "commit_is_base": false
  },
  "claim": "docs/claims/casper-soak-harness.md",
  "claim_ids": [
    "CLAIM-CASPER-SOAK-001"
  ],
  "claim_digests": {
    "docs/claims/casper-soak-harness.md": "c711fdc42bfed34ce28a6cd5da407e27d2e4745037b0eb250d8e760bee24a071"
  },
  "adapter": "embedded",
  "status": "discharged",
  "scope": "bounded-harness-only",
  "evidence": {
    "kind": "accepted-bounded-refutation-and-binding",
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/report.json",
    "sha256": "c510e4e393daf52f5a3d2e3affa908897ab0a574484de807939354d5ad8c5ec1"
  },
  "previous_ledger": {
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/prior-ledgers.tar.gz",
    "sha256": "4869ed3996b96dda70f84cc666ceb6f86d529f982f8c847b260287738d333e52",
    "member": "docs/casper/cbc-evidence/formal-tlaplus-casper-soak-CasperSoakHarness-tla.md"
  },
  "tiers": {
    "refutation": "bounded-safety-pass",
    "construction": "not-applicable",
    "binding": "passed"
  },
  "phase_status": {
    "pre_pr216_merge": "discharged",
    "post_pr216_merge": "blocked"
  },
  "soak": "pending",
  "waiver": null,
  "verified_at": "2026-09-18T04:31:12Z"
}
```

FILE: docs/casper/cbc-evidence/formal-tlaplus-casper-soak-MC-CasperSoakHarness-cfg.md
# CbC Evidence: formal/tlaplus/casper_soak/MC_CasperSoakHarness.cfg

The user accepted the bounded H01–H10 binding review. This record discharges only CLAIM-CASPER-SOAK-001 in the pre-merge phase.

Profile verification, node soaks, post-merge work, and inherited containment limits remain separate. Earlier ledger bytes remain in the linked archive.

```json
{
  "artifact": {
    "path": "formal/tlaplus/casper_soak/MC_CasperSoakHarness.cfg",
    "id": "formal-tlaplus-casper-soak-MC-CasperSoakHarness-cfg",
    "commit": "946743a7740e5dd3c0816263c3347e501f2d50d7",
    "sha256": "cc4438b578ccc5c898897e7b66b7472253d2532093f8a5338bf8d924002e197b",
    "commit_is_base": false
  },
  "claim": "docs/claims/casper-soak-harness.md",
  "claim_ids": [
    "CLAIM-CASPER-SOAK-001"
  ],
  "claim_digests": {
    "docs/claims/casper-soak-harness.md": "c711fdc42bfed34ce28a6cd5da407e27d2e4745037b0eb250d8e760bee24a071"
  },
  "adapter": "embedded",
  "status": "discharged",
  "scope": "bounded-harness-only",
  "evidence": {
    "kind": "accepted-bounded-refutation-and-binding",
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/report.json",
    "sha256": "c510e4e393daf52f5a3d2e3affa908897ab0a574484de807939354d5ad8c5ec1"
  },
  "previous_ledger": {
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/prior-ledgers.tar.gz",
    "sha256": "4869ed3996b96dda70f84cc666ceb6f86d529f982f8c847b260287738d333e52",
    "member": "docs/casper/cbc-evidence/formal-tlaplus-casper-soak-MC-CasperSoakHarness-cfg.md"
  },
  "tiers": {
    "refutation": "bounded-safety-pass",
    "construction": "not-applicable",
    "binding": "passed"
  },
  "phase_status": {
    "pre_pr216_merge": "discharged",
    "post_pr216_merge": "blocked"
  },
  "soak": "pending",
  "waiver": null,
  "verified_at": "2026-09-18T04:31:12Z"
}
```

FILE: docs/casper/cbc-evidence/formal-tlaplus-casper-soak-MC-CasperSoakHarness-cleanup-unsafe-cfg.md
# CbC Evidence: formal/tlaplus/casper_soak/MC_CasperSoakHarness_cleanup_unsafe.cfg

The user accepted the bounded H01–H10 binding review. This record discharges only CLAIM-CASPER-SOAK-001 in the pre-merge phase.

Profile verification, node soaks, post-merge work, and inherited containment limits remain separate. Earlier ledger bytes remain in the linked archive.

```json
{
  "artifact": {
    "path": "formal/tlaplus/casper_soak/MC_CasperSoakHarness_cleanup_unsafe.cfg",
    "id": "formal-tlaplus-casper-soak-MC-CasperSoakHarness-cleanup-unsafe-cfg",
    "commit": "946743a7740e5dd3c0816263c3347e501f2d50d7",
    "sha256": "94510f73bec2b328dc9ccebe5d0d97b6ef3af93570991dfee557a37c3ba5a3a0",
    "commit_is_base": false
  },
  "claim": "docs/claims/casper-soak-harness.md",
  "claim_ids": [
    "CLAIM-CASPER-SOAK-001"
  ],
  "claim_digests": {
    "docs/claims/casper-soak-harness.md": "c711fdc42bfed34ce28a6cd5da407e27d2e4745037b0eb250d8e760bee24a071"
  },
  "adapter": "embedded",
  "status": "discharged",
  "scope": "bounded-harness-only",
  "evidence": {
    "kind": "accepted-bounded-refutation-and-binding",
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/report.json",
    "sha256": "c510e4e393daf52f5a3d2e3affa908897ab0a574484de807939354d5ad8c5ec1"
  },
  "previous_ledger": {
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/prior-ledgers.tar.gz",
    "sha256": "4869ed3996b96dda70f84cc666ceb6f86d529f982f8c847b260287738d333e52",
    "member": "docs/casper/cbc-evidence/formal-tlaplus-casper-soak-MC-CasperSoakHarness-cleanup-unsafe-cfg.md"
  },
  "tiers": {
    "refutation": "bounded-safety-pass",
    "construction": "not-applicable",
    "binding": "passed"
  },
  "phase_status": {
    "pre_pr216_merge": "discharged",
    "post_pr216_merge": "blocked"
  },
  "soak": "pending",
  "waiver": null,
  "verified_at": "2026-09-18T04:31:12Z"
}
```

FILE: docs/casper/cbc-evidence/formal-tlaplus-casper-soak-MC-CasperSoakHarness-control-unsafe-cfg.md
# CbC Evidence: formal/tlaplus/casper_soak/MC_CasperSoakHarness_control_unsafe.cfg

The user accepted the bounded H01–H10 binding review. This record discharges only CLAIM-CASPER-SOAK-001 in the pre-merge phase.

Profile verification, node soaks, post-merge work, and inherited containment limits remain separate. Earlier ledger bytes remain in the linked archive.

```json
{
  "artifact": {
    "path": "formal/tlaplus/casper_soak/MC_CasperSoakHarness_control_unsafe.cfg",
    "id": "formal-tlaplus-casper-soak-MC-CasperSoakHarness-control-unsafe-cfg",
    "commit": "946743a7740e5dd3c0816263c3347e501f2d50d7",
    "sha256": "4fcf3c1b1b609a7a557a28da8daa7e908911a669d51bbb4abb1affeb5f2f90d9",
    "commit_is_base": false
  },
  "claim": "docs/claims/casper-soak-harness.md",
  "claim_ids": [
    "CLAIM-CASPER-SOAK-001"
  ],
  "claim_digests": {
    "docs/claims/casper-soak-harness.md": "c711fdc42bfed34ce28a6cd5da407e27d2e4745037b0eb250d8e760bee24a071"
  },
  "adapter": "embedded",
  "status": "discharged",
  "scope": "bounded-harness-only",
  "evidence": {
    "kind": "accepted-bounded-refutation-and-binding",
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/report.json",
    "sha256": "c510e4e393daf52f5a3d2e3affa908897ab0a574484de807939354d5ad8c5ec1"
  },
  "previous_ledger": {
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/prior-ledgers.tar.gz",
    "sha256": "4869ed3996b96dda70f84cc666ceb6f86d529f982f8c847b260287738d333e52",
    "member": "docs/casper/cbc-evidence/formal-tlaplus-casper-soak-MC-CasperSoakHarness-control-unsafe-cfg.md"
  },
  "tiers": {
    "refutation": "bounded-safety-pass",
    "construction": "not-applicable",
    "binding": "passed"
  },
  "phase_status": {
    "pre_pr216_merge": "discharged",
    "post_pr216_merge": "blocked"
  },
  "soak": "pending",
  "waiver": null,
  "verified_at": "2026-09-18T04:31:12Z"
}
```

FILE: docs/casper/cbc-evidence/formal-tlaplus-casper-soak-MC-CasperSoakHarness-evidence-unsafe-cfg.md
# CbC Evidence: formal/tlaplus/casper_soak/MC_CasperSoakHarness_evidence_unsafe.cfg

The user accepted the bounded H01–H10 binding review. This record discharges only CLAIM-CASPER-SOAK-001 in the pre-merge phase.

Profile verification, node soaks, post-merge work, and inherited containment limits remain separate. Earlier ledger bytes remain in the linked archive.

```json
{
  "artifact": {
    "path": "formal/tlaplus/casper_soak/MC_CasperSoakHarness_evidence_unsafe.cfg",
    "id": "formal-tlaplus-casper-soak-MC-CasperSoakHarness-evidence-unsafe-cfg",
    "commit": "946743a7740e5dd3c0816263c3347e501f2d50d7",
    "sha256": "08524a7d33f9f1fe35e6a070fd3e1257319223868af006854bc596314f12e4a4",
    "commit_is_base": false
  },
  "claim": "docs/claims/casper-soak-harness.md",
  "claim_ids": [
    "CLAIM-CASPER-SOAK-001"
  ],
  "claim_digests": {
    "docs/claims/casper-soak-harness.md": "c711fdc42bfed34ce28a6cd5da407e27d2e4745037b0eb250d8e760bee24a071"
  },
  "adapter": "embedded",
  "status": "discharged",
  "scope": "bounded-harness-only",
  "evidence": {
    "kind": "accepted-bounded-refutation-and-binding",
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/report.json",
    "sha256": "c510e4e393daf52f5a3d2e3affa908897ab0a574484de807939354d5ad8c5ec1"
  },
  "previous_ledger": {
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/prior-ledgers.tar.gz",
    "sha256": "4869ed3996b96dda70f84cc666ceb6f86d529f982f8c847b260287738d333e52",
    "member": "docs/casper/cbc-evidence/formal-tlaplus-casper-soak-MC-CasperSoakHarness-evidence-unsafe-cfg.md"
  },
  "tiers": {
    "refutation": "bounded-safety-pass",
    "construction": "not-applicable",
    "binding": "passed"
  },
  "phase_status": {
    "pre_pr216_merge": "discharged",
    "post_pr216_merge": "blocked"
  },
  "soak": "pending",
  "waiver": null,
  "verified_at": "2026-09-18T04:31:12Z"
}
```

FILE: docs/casper/cbc-evidence/formal-tlaplus-casper-soak-MC-CasperSoakHarness-failure-unsafe-cfg.md
# CbC Evidence: formal/tlaplus/casper_soak/MC_CasperSoakHarness_failure_unsafe.cfg

The user accepted the bounded H01–H10 binding review. This record discharges only CLAIM-CASPER-SOAK-001 in the pre-merge phase.

Profile verification, node soaks, post-merge work, and inherited containment limits remain separate. Earlier ledger bytes remain in the linked archive.

```json
{
  "artifact": {
    "path": "formal/tlaplus/casper_soak/MC_CasperSoakHarness_failure_unsafe.cfg",
    "id": "formal-tlaplus-casper-soak-MC-CasperSoakHarness-failure-unsafe-cfg",
    "commit": "946743a7740e5dd3c0816263c3347e501f2d50d7",
    "sha256": "a8dcf9479e5087738f503ac87c5b425e0c3dbca339924ce56fa7806e8446718a",
    "commit_is_base": false
  },
  "claim": "docs/claims/casper-soak-harness.md",
  "claim_ids": [
    "CLAIM-CASPER-SOAK-001"
  ],
  "claim_digests": {
    "docs/claims/casper-soak-harness.md": "c711fdc42bfed34ce28a6cd5da407e27d2e4745037b0eb250d8e760bee24a071"
  },
  "adapter": "embedded",
  "status": "discharged",
  "scope": "bounded-harness-only",
  "evidence": {
    "kind": "accepted-bounded-refutation-and-binding",
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/report.json",
    "sha256": "c510e4e393daf52f5a3d2e3affa908897ab0a574484de807939354d5ad8c5ec1"
  },
  "previous_ledger": {
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/prior-ledgers.tar.gz",
    "sha256": "4869ed3996b96dda70f84cc666ceb6f86d529f982f8c847b260287738d333e52",
    "member": "docs/casper/cbc-evidence/formal-tlaplus-casper-soak-MC-CasperSoakHarness-failure-unsafe-cfg.md"
  },
  "tiers": {
    "refutation": "bounded-safety-pass",
    "construction": "not-applicable",
    "binding": "passed"
  },
  "phase_status": {
    "pre_pr216_merge": "discharged",
    "post_pr216_merge": "blocked"
  },
  "soak": "pending",
  "waiver": null,
  "verified_at": "2026-09-18T04:31:12Z"
}
```

FILE: docs/casper/cbc-evidence/formal-tlaplus-casper-soak-MC-CasperSoakHarness-identity-unsafe-cfg.md
# CbC Evidence: formal/tlaplus/casper_soak/MC_CasperSoakHarness_identity_unsafe.cfg

The user accepted the bounded H01–H10 binding review. This record discharges only CLAIM-CASPER-SOAK-001 in the pre-merge phase.

Profile verification, node soaks, post-merge work, and inherited containment limits remain separate. Earlier ledger bytes remain in the linked archive.

```json
{
  "artifact": {
    "path": "formal/tlaplus/casper_soak/MC_CasperSoakHarness_identity_unsafe.cfg",
    "id": "formal-tlaplus-casper-soak-MC-CasperSoakHarness-identity-unsafe-cfg",
    "commit": "946743a7740e5dd3c0816263c3347e501f2d50d7",
    "sha256": "25c5689dee8138b46406741b6f4a74ed41dddc2c43824c810c7670bc9af3186e",
    "commit_is_base": false
  },
  "claim": "docs/claims/casper-soak-harness.md",
  "claim_ids": [
    "CLAIM-CASPER-SOAK-001"
  ],
  "claim_digests": {
    "docs/claims/casper-soak-harness.md": "c711fdc42bfed34ce28a6cd5da407e27d2e4745037b0eb250d8e760bee24a071"
  },
  "adapter": "embedded",
  "status": "discharged",
  "scope": "bounded-harness-only",
  "evidence": {
    "kind": "accepted-bounded-refutation-and-binding",
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/report.json",
    "sha256": "c510e4e393daf52f5a3d2e3affa908897ab0a574484de807939354d5ad8c5ec1"
  },
  "previous_ledger": {
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/prior-ledgers.tar.gz",
    "sha256": "4869ed3996b96dda70f84cc666ceb6f86d529f982f8c847b260287738d333e52",
    "member": "docs/casper/cbc-evidence/formal-tlaplus-casper-soak-MC-CasperSoakHarness-identity-unsafe-cfg.md"
  },
  "tiers": {
    "refutation": "bounded-safety-pass",
    "construction": "not-applicable",
    "binding": "passed"
  },
  "phase_status": {
    "pre_pr216_merge": "discharged",
    "post_pr216_merge": "blocked"
  },
  "soak": "pending",
  "waiver": null,
  "verified_at": "2026-09-18T04:31:12Z"
}
```

FILE: docs/casper/cbc-evidence/formal-tlaplus-casper-soak-MC-CasperSoakHarness-merge-unsafe-cfg.md
# CbC Evidence: formal/tlaplus/casper_soak/MC_CasperSoakHarness_merge_unsafe.cfg

The user accepted the bounded H01–H10 binding review. This record discharges only CLAIM-CASPER-SOAK-001 in the pre-merge phase.

Profile verification, node soaks, post-merge work, and inherited containment limits remain separate. Earlier ledger bytes remain in the linked archive.

```json
{
  "artifact": {
    "path": "formal/tlaplus/casper_soak/MC_CasperSoakHarness_merge_unsafe.cfg",
    "id": "formal-tlaplus-casper-soak-MC-CasperSoakHarness-merge-unsafe-cfg",
    "commit": "946743a7740e5dd3c0816263c3347e501f2d50d7",
    "sha256": "f71a9822b0499a7a115e20c30076da785e997fa636ca0605adc54ee6003ac9f1",
    "commit_is_base": false
  },
  "claim": "docs/claims/casper-soak-harness.md",
  "claim_ids": [
    "CLAIM-CASPER-SOAK-001"
  ],
  "claim_digests": {
    "docs/claims/casper-soak-harness.md": "c711fdc42bfed34ce28a6cd5da407e27d2e4745037b0eb250d8e760bee24a071"
  },
  "adapter": "embedded",
  "status": "discharged",
  "scope": "bounded-harness-only",
  "evidence": {
    "kind": "accepted-bounded-refutation-and-binding",
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/report.json",
    "sha256": "c510e4e393daf52f5a3d2e3affa908897ab0a574484de807939354d5ad8c5ec1"
  },
  "previous_ledger": {
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/prior-ledgers.tar.gz",
    "sha256": "4869ed3996b96dda70f84cc666ceb6f86d529f982f8c847b260287738d333e52",
    "member": "docs/casper/cbc-evidence/formal-tlaplus-casper-soak-MC-CasperSoakHarness-merge-unsafe-cfg.md"
  },
  "tiers": {
    "refutation": "bounded-safety-pass",
    "construction": "not-applicable",
    "binding": "passed"
  },
  "phase_status": {
    "pre_pr216_merge": "discharged",
    "post_pr216_merge": "blocked"
  },
  "soak": "pending",
  "waiver": null,
  "verified_at": "2026-09-18T04:31:12Z"
}
```

FILE: docs/casper/cbc-evidence/formal-tlaplus-casper-soak-MC-CasperSoakHarness-policy-unsafe-cfg.md
# CbC Evidence: formal/tlaplus/casper_soak/MC_CasperSoakHarness_policy_unsafe.cfg

The user accepted the bounded H01–H10 binding review. This record discharges only CLAIM-CASPER-SOAK-001 in the pre-merge phase.

Profile verification, node soaks, post-merge work, and inherited containment limits remain separate. Earlier ledger bytes remain in the linked archive.

```json
{
  "artifact": {
    "path": "formal/tlaplus/casper_soak/MC_CasperSoakHarness_policy_unsafe.cfg",
    "id": "formal-tlaplus-casper-soak-MC-CasperSoakHarness-policy-unsafe-cfg",
    "commit": "946743a7740e5dd3c0816263c3347e501f2d50d7",
    "sha256": "f051c46dbdcb9ba8854043ac84bb74866f42b3c73aaa387fa9962ac212c1c131",
    "commit_is_base": false
  },
  "claim": "docs/claims/casper-soak-harness.md",
  "claim_ids": [
    "CLAIM-CASPER-SOAK-001"
  ],
  "claim_digests": {
    "docs/claims/casper-soak-harness.md": "c711fdc42bfed34ce28a6cd5da407e27d2e4745037b0eb250d8e760bee24a071"
  },
  "adapter": "embedded",
  "status": "discharged",
  "scope": "bounded-harness-only",
  "evidence": {
    "kind": "accepted-bounded-refutation-and-binding",
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/report.json",
    "sha256": "c510e4e393daf52f5a3d2e3affa908897ab0a574484de807939354d5ad8c5ec1"
  },
  "previous_ledger": {
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/prior-ledgers.tar.gz",
    "sha256": "4869ed3996b96dda70f84cc666ceb6f86d529f982f8c847b260287738d333e52",
    "member": "docs/casper/cbc-evidence/formal-tlaplus-casper-soak-MC-CasperSoakHarness-policy-unsafe-cfg.md"
  },
  "tiers": {
    "refutation": "bounded-safety-pass",
    "construction": "not-applicable",
    "binding": "passed"
  },
  "phase_status": {
    "pre_pr216_merge": "discharged",
    "post_pr216_merge": "blocked"
  },
  "soak": "pending",
  "waiver": null,
  "verified_at": "2026-09-18T04:31:12Z"
}
```

FILE: docs/casper/cbc-evidence/formal-tlaplus-casper-soak-MC-CasperSoakHarness-resume-unsafe-cfg.md
# CbC Evidence: formal/tlaplus/casper_soak/MC_CasperSoakHarness_resume_unsafe.cfg

The user accepted the bounded H01–H10 binding review. This record discharges only CLAIM-CASPER-SOAK-001 in the pre-merge phase.

Profile verification, node soaks, post-merge work, and inherited containment limits remain separate. Earlier ledger bytes remain in the linked archive.

```json
{
  "artifact": {
    "path": "formal/tlaplus/casper_soak/MC_CasperSoakHarness_resume_unsafe.cfg",
    "id": "formal-tlaplus-casper-soak-MC-CasperSoakHarness-resume-unsafe-cfg",
    "commit": "946743a7740e5dd3c0816263c3347e501f2d50d7",
    "sha256": "fa2f527570a3687de48dcac826538e3aa6a9edb2332d5051a936fa34c3c4ca63",
    "commit_is_base": false
  },
  "claim": "docs/claims/casper-soak-harness.md",
  "claim_ids": [
    "CLAIM-CASPER-SOAK-001"
  ],
  "claim_digests": {
    "docs/claims/casper-soak-harness.md": "c711fdc42bfed34ce28a6cd5da407e27d2e4745037b0eb250d8e760bee24a071"
  },
  "adapter": "embedded",
  "status": "discharged",
  "scope": "bounded-harness-only",
  "evidence": {
    "kind": "accepted-bounded-refutation-and-binding",
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/report.json",
    "sha256": "c510e4e393daf52f5a3d2e3affa908897ab0a574484de807939354d5ad8c5ec1"
  },
  "previous_ledger": {
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/prior-ledgers.tar.gz",
    "sha256": "4869ed3996b96dda70f84cc666ceb6f86d529f982f8c847b260287738d333e52",
    "member": "docs/casper/cbc-evidence/formal-tlaplus-casper-soak-MC-CasperSoakHarness-resume-unsafe-cfg.md"
  },
  "tiers": {
    "refutation": "bounded-safety-pass",
    "construction": "not-applicable",
    "binding": "passed"
  },
  "phase_status": {
    "pre_pr216_merge": "discharged",
    "post_pr216_merge": "blocked"
  },
  "soak": "pending",
  "waiver": null,
  "verified_at": "2026-09-18T04:31:12Z"
}
```

FILE: docs/casper/cbc-evidence/formal-tlaplus-casper-soak-MC-CasperSoakHarness-samples-unsafe-cfg.md
# CbC Evidence: formal/tlaplus/casper_soak/MC_CasperSoakHarness_samples_unsafe.cfg

The user accepted the bounded H01–H10 binding review. This record discharges only CLAIM-CASPER-SOAK-001 in the pre-merge phase.

Profile verification, node soaks, post-merge work, and inherited containment limits remain separate. Earlier ledger bytes remain in the linked archive.

```json
{
  "artifact": {
    "path": "formal/tlaplus/casper_soak/MC_CasperSoakHarness_samples_unsafe.cfg",
    "id": "formal-tlaplus-casper-soak-MC-CasperSoakHarness-samples-unsafe-cfg",
    "commit": "946743a7740e5dd3c0816263c3347e501f2d50d7",
    "sha256": "6937418bcfafd33557d27359f34e5e53e78fcfd68b43e68bfb3617d86cb6022b",
    "commit_is_base": false
  },
  "claim": "docs/claims/casper-soak-harness.md",
  "claim_ids": [
    "CLAIM-CASPER-SOAK-001"
  ],
  "claim_digests": {
    "docs/claims/casper-soak-harness.md": "c711fdc42bfed34ce28a6cd5da407e27d2e4745037b0eb250d8e760bee24a071"
  },
  "adapter": "embedded",
  "status": "discharged",
  "scope": "bounded-harness-only",
  "evidence": {
    "kind": "accepted-bounded-refutation-and-binding",
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/report.json",
    "sha256": "c510e4e393daf52f5a3d2e3affa908897ab0a574484de807939354d5ad8c5ec1"
  },
  "previous_ledger": {
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/prior-ledgers.tar.gz",
    "sha256": "4869ed3996b96dda70f84cc666ceb6f86d529f982f8c847b260287738d333e52",
    "member": "docs/casper/cbc-evidence/formal-tlaplus-casper-soak-MC-CasperSoakHarness-samples-unsafe-cfg.md"
  },
  "tiers": {
    "refutation": "bounded-safety-pass",
    "construction": "not-applicable",
    "binding": "passed"
  },
  "phase_status": {
    "pre_pr216_merge": "discharged",
    "post_pr216_merge": "blocked"
  },
  "soak": "pending",
  "waiver": null,
  "verified_at": "2026-09-18T04:31:12Z"
}
```

FILE: docs/casper/cbc-evidence/formal-tlaplus-casper-soak-MC-CasperSoakHarness-stop-unsafe-cfg.md
# CbC Evidence: formal/tlaplus/casper_soak/MC_CasperSoakHarness_stop_unsafe.cfg

The user accepted the bounded H01–H10 binding review. This record discharges only CLAIM-CASPER-SOAK-001 in the pre-merge phase.

Profile verification, node soaks, post-merge work, and inherited containment limits remain separate. Earlier ledger bytes remain in the linked archive.

```json
{
  "artifact": {
    "path": "formal/tlaplus/casper_soak/MC_CasperSoakHarness_stop_unsafe.cfg",
    "id": "formal-tlaplus-casper-soak-MC-CasperSoakHarness-stop-unsafe-cfg",
    "commit": "946743a7740e5dd3c0816263c3347e501f2d50d7",
    "sha256": "5d7947fadd81556a4cfea4f4dae3a9cf3893dc3b360889c3938aff047a0c5f4b",
    "commit_is_base": false
  },
  "claim": "docs/claims/casper-soak-harness.md",
  "claim_ids": [
    "CLAIM-CASPER-SOAK-001"
  ],
  "claim_digests": {
    "docs/claims/casper-soak-harness.md": "c711fdc42bfed34ce28a6cd5da407e27d2e4745037b0eb250d8e760bee24a071"
  },
  "adapter": "embedded",
  "status": "discharged",
  "scope": "bounded-harness-only",
  "evidence": {
    "kind": "accepted-bounded-refutation-and-binding",
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/report.json",
    "sha256": "c510e4e393daf52f5a3d2e3affa908897ab0a574484de807939354d5ad8c5ec1"
  },
  "previous_ledger": {
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/prior-ledgers.tar.gz",
    "sha256": "4869ed3996b96dda70f84cc666ceb6f86d529f982f8c847b260287738d333e52",
    "member": "docs/casper/cbc-evidence/formal-tlaplus-casper-soak-MC-CasperSoakHarness-stop-unsafe-cfg.md"
  },
  "tiers": {
    "refutation": "bounded-safety-pass",
    "construction": "not-applicable",
    "binding": "passed"
  },
  "phase_status": {
    "pre_pr216_merge": "discharged",
    "post_pr216_merge": "blocked"
  },
  "soak": "pending",
  "waiver": null,
  "verified_at": "2026-09-18T04:31:12Z"
}
```

FILE: docs/casper/cbc-evidence/github-workflows-merge-recovery-soak-yml.md
# CbC Evidence: .github/workflows/merge-recovery-soak.yml

The user accepted the bounded H01–H10 binding review. This record discharges only CLAIM-CASPER-SOAK-001 in the pre-merge phase.

Profile verification, node soaks, post-merge work, and inherited containment limits remain separate. Earlier ledger bytes remain in the linked archive.

```json
{
  "artifact": {
    "path": ".github/workflows/merge-recovery-soak.yml",
    "id": "github-workflows-merge-recovery-soak-yml",
    "commit": "946743a7740e5dd3c0816263c3347e501f2d50d7",
    "sha256": "c35090112ef47303dd8b3dfd334dcf5a5c86bbaa233bdb79b27654d685559238",
    "commit_is_base": false
  },
  "claim": "docs/claims/casper-soak-harness.md",
  "claim_ids": [
    "CLAIM-CASPER-SOAK-001"
  ],
  "claim_digests": {
    "docs/claims/casper-soak-harness.md": "c711fdc42bfed34ce28a6cd5da407e27d2e4745037b0eb250d8e760bee24a071"
  },
  "adapter": "embedded",
  "status": "discharged",
  "scope": "bounded-harness-only",
  "evidence": {
    "kind": "accepted-bounded-refutation-and-binding",
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/report.json",
    "sha256": "c510e4e393daf52f5a3d2e3affa908897ab0a574484de807939354d5ad8c5ec1"
  },
  "previous_ledger": null,
  "tiers": {
    "refutation": "bounded-safety-pass",
    "construction": "not-applicable",
    "binding": "passed"
  },
  "phase_status": {
    "pre_pr216_merge": "discharged",
    "post_pr216_merge": "blocked"
  },
  "soak": "pending",
  "waiver": null,
  "verified_at": "2026-09-18T04:31:12Z"
}
```

FILE: docs/casper/cbc-evidence/github-workflows-slashing-tests-yml.md
# CbC Evidence: .github/workflows/slashing-tests.yml

The user accepted the bounded H01–H10 binding review. This record discharges only CLAIM-CASPER-SOAK-001 in the pre-merge phase.

Profile verification, node soaks, post-merge work, and inherited containment limits remain separate. Earlier ledger bytes remain in the linked archive.

```json
{
  "artifact": {
    "path": ".github/workflows/slashing-tests.yml",
    "id": "github-workflows-slashing-tests-yml",
    "commit": "946743a7740e5dd3c0816263c3347e501f2d50d7",
    "sha256": "b040baafa3723c789aa762fef0e925702504e1a70c7a0a47ccc2d2a39b25c336",
    "commit_is_base": false
  },
  "claim": "docs/claims/casper-soak-harness.md",
  "claim_ids": [
    "CLAIM-CASPER-SOAK-001"
  ],
  "claim_digests": {
    "docs/claims/casper-soak-harness.md": "c711fdc42bfed34ce28a6cd5da407e27d2e4745037b0eb250d8e760bee24a071"
  },
  "adapter": "embedded",
  "status": "discharged",
  "scope": "bounded-harness-only",
  "evidence": {
    "kind": "accepted-bounded-refutation-and-binding",
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/report.json",
    "sha256": "c510e4e393daf52f5a3d2e3affa908897ab0a574484de807939354d5ad8c5ec1"
  },
  "previous_ledger": {
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/prior-ledgers.tar.gz",
    "sha256": "4869ed3996b96dda70f84cc666ceb6f86d529f982f8c847b260287738d333e52",
    "member": "docs/casper/cbc-evidence/github-workflows-slashing-tests-yml.md"
  },
  "tiers": {
    "refutation": "bounded-safety-pass",
    "construction": "not-applicable",
    "binding": "passed"
  },
  "phase_status": {
    "pre_pr216_merge": "discharged",
    "post_pr216_merge": "blocked"
  },
  "soak": "pending",
  "waiver": null,
  "verified_at": "2026-09-18T04:31:12Z"
}
```

FILE: docs/casper/cbc-evidence/scripts-bench-casper-soak-sh.md
# CbC Evidence: scripts/bench/casper-soak.sh

The user accepted the bounded H01–H10 binding review. This record discharges only CLAIM-CASPER-SOAK-001 in the pre-merge phase.

Profile verification, node soaks, post-merge work, and inherited containment limits remain separate. Earlier ledger bytes remain in the linked archive.

```json
{
  "artifact": {
    "path": "scripts/bench/casper-soak.sh",
    "id": "scripts-bench-casper-soak-sh",
    "commit": "946743a7740e5dd3c0816263c3347e501f2d50d7",
    "sha256": "19b6e0c9ff481428955c68631fc1224ec2506502d01a3c3f1bf6634d8a64f353",
    "commit_is_base": false
  },
  "claim": "docs/claims/casper-soak-harness.md",
  "claim_ids": [
    "CLAIM-CASPER-SOAK-001"
  ],
  "claim_digests": {
    "docs/claims/casper-soak-harness.md": "c711fdc42bfed34ce28a6cd5da407e27d2e4745037b0eb250d8e760bee24a071"
  },
  "adapter": "embedded",
  "status": "discharged",
  "scope": "bounded-harness-only",
  "evidence": {
    "kind": "accepted-bounded-refutation-and-binding",
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/report.json",
    "sha256": "c510e4e393daf52f5a3d2e3affa908897ab0a574484de807939354d5ad8c5ec1"
  },
  "previous_ledger": {
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/prior-ledgers.tar.gz",
    "sha256": "4869ed3996b96dda70f84cc666ceb6f86d529f982f8c847b260287738d333e52",
    "member": "docs/casper/cbc-evidence/scripts-bench-casper-soak-sh.md"
  },
  "tiers": {
    "refutation": "bounded-safety-pass",
    "construction": "not-applicable",
    "binding": "passed"
  },
  "phase_status": {
    "pre_pr216_merge": "discharged",
    "post_pr216_merge": "blocked"
  },
  "soak": "pending",
  "waiver": null,
  "verified_at": "2026-09-18T04:31:12Z"
}
```

FILE: docs/casper/cbc-evidence/scripts-bench-fixtures-casper-lifecycle-executor-sh.md
# CbC Evidence: scripts/bench/fixtures/casper-lifecycle-executor.sh

The user accepted the bounded H01–H10 binding review. This record discharges only CLAIM-CASPER-SOAK-001 in the pre-merge phase.

Profile verification, node soaks, post-merge work, and inherited containment limits remain separate. Earlier ledger bytes remain in the linked archive.

```json
{
  "artifact": {
    "path": "scripts/bench/fixtures/casper-lifecycle-executor.sh",
    "id": "scripts-bench-fixtures-casper-lifecycle-executor-sh",
    "commit": "946743a7740e5dd3c0816263c3347e501f2d50d7",
    "sha256": "a2af2205b89c03b7ab503ca5c312e9b2300040540781ada37c33c849a3b94704",
    "commit_is_base": false
  },
  "claim": "docs/claims/casper-soak-harness.md",
  "claim_ids": [
    "CLAIM-CASPER-SOAK-001"
  ],
  "claim_digests": {
    "docs/claims/casper-soak-harness.md": "c711fdc42bfed34ce28a6cd5da407e27d2e4745037b0eb250d8e760bee24a071"
  },
  "adapter": "embedded",
  "status": "discharged",
  "scope": "bounded-harness-only",
  "evidence": {
    "kind": "accepted-bounded-refutation-and-binding",
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/report.json",
    "sha256": "c510e4e393daf52f5a3d2e3affa908897ab0a574484de807939354d5ad8c5ec1"
  },
  "previous_ledger": {
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/prior-ledgers.tar.gz",
    "sha256": "4869ed3996b96dda70f84cc666ceb6f86d529f982f8c847b260287738d333e52",
    "member": "docs/casper/cbc-evidence/scripts-bench-fixtures-casper-lifecycle-executor-sh.md"
  },
  "tiers": {
    "refutation": "bounded-safety-pass",
    "construction": "not-applicable",
    "binding": "passed"
  },
  "phase_status": {
    "pre_pr216_merge": "discharged",
    "post_pr216_merge": "blocked"
  },
  "soak": "pending",
  "waiver": null,
  "verified_at": "2026-09-18T04:31:12Z"
}
```

FILE: docs/casper/cbc-evidence/scripts-bench-test-run-merge-recovery-soak-sh.md
# CbC Evidence: scripts/bench/test-run-merge-recovery-soak.sh

The user accepted the bounded H01–H10 binding review. This record discharges only CLAIM-CASPER-SOAK-001 in the pre-merge phase.

Profile verification, node soaks, post-merge work, and inherited containment limits remain separate. Earlier ledger bytes remain in the linked archive.

```json
{
  "artifact": {
    "path": "scripts/bench/test-run-merge-recovery-soak.sh",
    "id": "scripts-bench-test-run-merge-recovery-soak-sh",
    "commit": "946743a7740e5dd3c0816263c3347e501f2d50d7",
    "sha256": "c5089c13fa8cf127cae071a515409e8d23c45c3441f2d973563e379d6406a030",
    "commit_is_base": false
  },
  "claim": "docs/claims/casper-soak-harness.md",
  "claim_ids": [
    "CLAIM-CASPER-SOAK-001"
  ],
  "claim_digests": {
    "docs/claims/casper-soak-harness.md": "c711fdc42bfed34ce28a6cd5da407e27d2e4745037b0eb250d8e760bee24a071"
  },
  "adapter": "embedded",
  "status": "discharged",
  "scope": "bounded-harness-only",
  "evidence": {
    "kind": "accepted-bounded-refutation-and-binding",
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/report.json",
    "sha256": "c510e4e393daf52f5a3d2e3affa908897ab0a574484de807939354d5ad8c5ec1"
  },
  "previous_ledger": null,
  "tiers": {
    "refutation": "bounded-safety-pass",
    "construction": "not-applicable",
    "binding": "passed"
  },
  "phase_status": {
    "pre_pr216_merge": "discharged",
    "post_pr216_merge": "blocked"
  },
  "soak": "pending",
  "waiver": null,
  "verified_at": "2026-09-18T04:31:12Z"
}
```

FILE: docs/casper/cbc-evidence/scripts-bench-write-soak-summary-sh.md
# CbC Evidence: scripts/bench/write-soak-summary.sh

The user accepted the bounded H01–H10 binding review. This record discharges only CLAIM-CASPER-SOAK-001 in the pre-merge phase.

Profile verification, node soaks, post-merge work, and inherited containment limits remain separate. Earlier ledger bytes remain in the linked archive.

```json
{
  "artifact": {
    "path": "scripts/bench/write-soak-summary.sh",
    "id": "scripts-bench-write-soak-summary-sh",
    "commit": "946743a7740e5dd3c0816263c3347e501f2d50d7",
    "sha256": "4ae6cf85bddd0f1e96a7b50da1db7e1033952d40244f697ab584846b857ff3e1",
    "commit_is_base": false
  },
  "claim": "docs/claims/casper-soak-harness.md",
  "claim_ids": [
    "CLAIM-CASPER-SOAK-001"
  ],
  "claim_digests": {
    "docs/claims/casper-soak-harness.md": "c711fdc42bfed34ce28a6cd5da407e27d2e4745037b0eb250d8e760bee24a071"
  },
  "adapter": "embedded",
  "status": "discharged",
  "scope": "bounded-harness-only",
  "evidence": {
    "kind": "accepted-bounded-refutation-and-binding",
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/report.json",
    "sha256": "c510e4e393daf52f5a3d2e3affa908897ab0a574484de807939354d5ad8c5ec1"
  },
  "previous_ledger": null,
  "tiers": {
    "refutation": "bounded-safety-pass",
    "construction": "not-applicable",
    "binding": "passed"
  },
  "phase_status": {
    "pre_pr216_merge": "discharged",
    "post_pr216_merge": "blocked"
  },
  "soak": "pending",
  "waiver": null,
  "verified_at": "2026-09-18T04:31:12Z"
}
```

FILE: docs/casper/cbc-evidence/scripts-casper-soak-cargo-toml.md
# CbC Evidence: scripts/casper-soak/Cargo.toml

The user accepted the bounded H01–H10 binding review. This record discharges only CLAIM-CASPER-SOAK-001 in the pre-merge phase.

Profile verification, node soaks, post-merge work, and inherited containment limits remain separate. Earlier ledger bytes remain in the linked archive.

```json
{
  "artifact": {
    "path": "scripts/casper-soak/Cargo.toml",
    "id": "scripts-casper-soak-Cargo-toml",
    "commit": "946743a7740e5dd3c0816263c3347e501f2d50d7",
    "sha256": "f6082e839d8bb20e5b2988a9ed92ffe5d1cd79a0e578e10d68582593ea3d13cb",
    "commit_is_base": false
  },
  "claim": "docs/claims/casper-soak-harness.md",
  "claim_ids": [
    "CLAIM-CASPER-SOAK-001"
  ],
  "claim_digests": {
    "docs/claims/casper-soak-harness.md": "c711fdc42bfed34ce28a6cd5da407e27d2e4745037b0eb250d8e760bee24a071"
  },
  "adapter": "embedded",
  "status": "discharged",
  "scope": "bounded-harness-only",
  "evidence": {
    "kind": "accepted-bounded-refutation-and-binding",
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/report.json",
    "sha256": "c510e4e393daf52f5a3d2e3affa908897ab0a574484de807939354d5ad8c5ec1"
  },
  "previous_ledger": {
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/prior-ledgers.tar.gz",
    "sha256": "4869ed3996b96dda70f84cc666ceb6f86d529f982f8c847b260287738d333e52",
    "member": "docs/casper/cbc-evidence/scripts-casper-soak-Cargo-toml.md"
  },
  "tiers": {
    "refutation": "bounded-safety-pass",
    "construction": "not-applicable",
    "binding": "passed"
  },
  "phase_status": {
    "pre_pr216_merge": "discharged",
    "post_pr216_merge": "blocked"
  },
  "soak": "pending",
  "waiver": null,
  "verified_at": "2026-09-18T04:31:12Z"
}
```

FILE: docs/casper/cbc-evidence/scripts-casper-soak-src-bin-check-casper-bindings-rs.md
# CbC Evidence: scripts/casper-soak/src/bin/check-casper-bindings.rs

The user accepted the bounded H01–H10 binding review. This record discharges only CLAIM-CASPER-SOAK-001 in the pre-merge phase.

Profile verification, node soaks, post-merge work, and inherited containment limits remain separate. Earlier ledger bytes remain in the linked archive.

```json
{
  "artifact": {
    "path": "scripts/casper-soak/src/bin/check-casper-bindings.rs",
    "id": "scripts-casper-soak-src-bin-check-casper-bindings-rs",
    "commit": "946743a7740e5dd3c0816263c3347e501f2d50d7",
    "sha256": "73f02925700815dddaecd3a5353b4a5a161cb77955ada1f06b76626dcb1e6c0a",
    "commit_is_base": false
  },
  "claim": "docs/claims/casper-soak-harness.md",
  "claim_ids": [
    "CLAIM-CASPER-SOAK-001"
  ],
  "claim_digests": {
    "docs/claims/casper-soak-harness.md": "c711fdc42bfed34ce28a6cd5da407e27d2e4745037b0eb250d8e760bee24a071"
  },
  "adapter": "embedded",
  "status": "discharged",
  "scope": "bounded-harness-only",
  "evidence": {
    "kind": "accepted-bounded-refutation-and-binding",
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/report.json",
    "sha256": "c510e4e393daf52f5a3d2e3affa908897ab0a574484de807939354d5ad8c5ec1"
  },
  "previous_ledger": {
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/prior-ledgers.tar.gz",
    "sha256": "4869ed3996b96dda70f84cc666ceb6f86d529f982f8c847b260287738d333e52",
    "member": "docs/casper/cbc-evidence/scripts-casper-soak-src-bin-check-casper-bindings-rs.md"
  },
  "tiers": {
    "refutation": "bounded-safety-pass",
    "construction": "not-applicable",
    "binding": "passed"
  },
  "phase_status": {
    "pre_pr216_merge": "discharged",
    "post_pr216_merge": "blocked"
  },
  "soak": "pending",
  "waiver": null,
  "verified_at": "2026-09-18T04:31:12Z"
}
```

FILE: docs/casper/cbc-evidence/scripts-casper-soak-src-bin-check-casper-claims-rs.md
# CbC Evidence: scripts/casper-soak/src/bin/check-casper-claims.rs

The user accepted the bounded H01–H10 binding review. This record discharges only CLAIM-CASPER-SOAK-001 in the pre-merge phase.

Profile verification, node soaks, post-merge work, and inherited containment limits remain separate. Earlier ledger bytes remain in the linked archive.

```json
{
  "artifact": {
    "path": "scripts/casper-soak/src/bin/check-casper-claims.rs",
    "id": "scripts-casper-soak-src-bin-check-casper-claims-rs",
    "commit": "946743a7740e5dd3c0816263c3347e501f2d50d7",
    "sha256": "3a5f28efc587b0306a9b49eb6b7e5e97be74cd91e405520e9cf63d923d5c1e55",
    "commit_is_base": true
  },
  "claim": "docs/claims/casper-soak-harness.md",
  "claim_ids": [
    "CLAIM-CASPER-SOAK-001"
  ],
  "claim_digests": {
    "docs/claims/casper-soak-harness.md": "c711fdc42bfed34ce28a6cd5da407e27d2e4745037b0eb250d8e760bee24a071"
  },
  "adapter": "embedded",
  "status": "discharged",
  "scope": "bounded-harness-only",
  "evidence": {
    "kind": "accepted-bounded-refutation-and-binding",
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/report.json",
    "sha256": "c510e4e393daf52f5a3d2e3affa908897ab0a574484de807939354d5ad8c5ec1"
  },
  "previous_ledger": {
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/prior-ledgers.tar.gz",
    "sha256": "4869ed3996b96dda70f84cc666ceb6f86d529f982f8c847b260287738d333e52",
    "member": "docs/casper/cbc-evidence/scripts-casper-soak-src-bin-check-casper-claims-rs.md"
  },
  "tiers": {
    "refutation": "bounded-safety-pass",
    "construction": "not-applicable",
    "binding": "passed"
  },
  "phase_status": {
    "pre_pr216_merge": "discharged",
    "post_pr216_merge": "blocked"
  },
  "soak": "pending",
  "waiver": null,
  "verified_at": "2026-09-18T04:31:12Z"
}
```

FILE: docs/casper/cbc-evidence/scripts-casper-soak-src-lib-rs.md
# CbC Evidence: scripts/casper-soak/src/lib.rs

The user accepted the bounded H01–H10 binding review. This record discharges only CLAIM-CASPER-SOAK-001 in the pre-merge phase.

Profile verification, node soaks, post-merge work, and inherited containment limits remain separate. Earlier ledger bytes remain in the linked archive.

```json
{
  "artifact": {
    "path": "scripts/casper-soak/src/lib.rs",
    "id": "scripts-casper-soak-src-lib-rs",
    "commit": "946743a7740e5dd3c0816263c3347e501f2d50d7",
    "sha256": "2dc948c0a4450b0ba3bd994af7b676e4874992f46dbe5653f7eeb0e27c99c6fe",
    "commit_is_base": false
  },
  "claim": "docs/claims/casper-soak-harness.md",
  "claim_ids": [
    "CLAIM-CASPER-SOAK-001"
  ],
  "claim_digests": {
    "docs/claims/casper-soak-harness.md": "c711fdc42bfed34ce28a6cd5da407e27d2e4745037b0eb250d8e760bee24a071"
  },
  "adapter": "embedded",
  "status": "discharged",
  "scope": "bounded-harness-only",
  "evidence": {
    "kind": "accepted-bounded-refutation-and-binding",
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/report.json",
    "sha256": "c510e4e393daf52f5a3d2e3affa908897ab0a574484de807939354d5ad8c5ec1"
  },
  "previous_ledger": {
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/prior-ledgers.tar.gz",
    "sha256": "4869ed3996b96dda70f84cc666ceb6f86d529f982f8c847b260287738d333e52",
    "member": "docs/casper/cbc-evidence/scripts-casper-soak-src-lib-rs.md"
  },
  "tiers": {
    "refutation": "bounded-safety-pass",
    "construction": "not-applicable",
    "binding": "passed"
  },
  "phase_status": {
    "pre_pr216_merge": "discharged",
    "post_pr216_merge": "blocked"
  },
  "soak": "pending",
  "waiver": null,
  "verified_at": "2026-09-18T04:31:12Z"
}
```

FILE: docs/casper/cbc-evidence/scripts-casper-soak-src-main-rs.md
# CbC Evidence: scripts/casper-soak/src/main.rs

The user accepted the bounded H01–H10 binding review. This record discharges only CLAIM-CASPER-SOAK-001 in the pre-merge phase.

Profile verification, node soaks, post-merge work, and inherited containment limits remain separate. Earlier ledger bytes remain in the linked archive.

```json
{
  "artifact": {
    "path": "scripts/casper-soak/src/main.rs",
    "id": "scripts-casper-soak-src-main-rs",
    "commit": "946743a7740e5dd3c0816263c3347e501f2d50d7",
    "sha256": "1e804854893d964b60e64864d7115f6b11a55ea169887a886f031c75eb63d9e8",
    "commit_is_base": false
  },
  "claim": "docs/claims/casper-soak-harness.md",
  "claim_ids": [
    "CLAIM-CASPER-SOAK-001"
  ],
  "claim_digests": {
    "docs/claims/casper-soak-harness.md": "c711fdc42bfed34ce28a6cd5da407e27d2e4745037b0eb250d8e760bee24a071"
  },
  "adapter": "embedded",
  "status": "discharged",
  "scope": "bounded-harness-only",
  "evidence": {
    "kind": "accepted-bounded-refutation-and-binding",
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/report.json",
    "sha256": "c510e4e393daf52f5a3d2e3affa908897ab0a574484de807939354d5ad8c5ec1"
  },
  "previous_ledger": {
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/prior-ledgers.tar.gz",
    "sha256": "4869ed3996b96dda70f84cc666ceb6f86d529f982f8c847b260287738d333e52",
    "member": "docs/casper/cbc-evidence/scripts-casper-soak-src-main-rs.md"
  },
  "tiers": {
    "refutation": "bounded-safety-pass",
    "construction": "not-applicable",
    "binding": "passed"
  },
  "phase_status": {
    "pre_pr216_merge": "discharged",
    "post_pr216_merge": "blocked"
  },
  "soak": "pending",
  "waiver": null,
  "verified_at": "2026-09-18T04:31:12Z"
}
```

FILE: docs/casper/cbc-evidence/scripts-casper-soak-src-manifest-rs.md
# CbC Evidence: scripts/casper-soak/src/manifest.rs

The user accepted the bounded H01–H10 binding review. This record discharges only CLAIM-CASPER-SOAK-001 in the pre-merge phase.

Profile verification, node soaks, post-merge work, and inherited containment limits remain separate. Earlier ledger bytes remain in the linked archive.

```json
{
  "artifact": {
    "path": "scripts/casper-soak/src/manifest.rs",
    "id": "scripts-casper-soak-src-manifest-rs",
    "commit": "946743a7740e5dd3c0816263c3347e501f2d50d7",
    "sha256": "d9606d542cfb9bc058f691196244ae2e6055e6c84c02b5c2581ee07e70c03000",
    "commit_is_base": false
  },
  "claim": "docs/claims/casper-soak-harness.md",
  "claim_ids": [
    "CLAIM-CASPER-SOAK-001"
  ],
  "claim_digests": {
    "docs/claims/casper-soak-harness.md": "c711fdc42bfed34ce28a6cd5da407e27d2e4745037b0eb250d8e760bee24a071"
  },
  "adapter": "embedded",
  "status": "discharged",
  "scope": "bounded-harness-only",
  "evidence": {
    "kind": "accepted-bounded-refutation-and-binding",
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/report.json",
    "sha256": "c510e4e393daf52f5a3d2e3affa908897ab0a574484de807939354d5ad8c5ec1"
  },
  "previous_ledger": {
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/prior-ledgers.tar.gz",
    "sha256": "4869ed3996b96dda70f84cc666ceb6f86d529f982f8c847b260287738d333e52",
    "member": "docs/casper/cbc-evidence/scripts-casper-soak-src-manifest-rs.md"
  },
  "tiers": {
    "refutation": "bounded-safety-pass",
    "construction": "not-applicable",
    "binding": "passed"
  },
  "phase_status": {
    "pre_pr216_merge": "discharged",
    "post_pr216_merge": "blocked"
  },
  "soak": "pending",
  "waiver": null,
  "verified_at": "2026-09-18T04:31:12Z"
}
```

FILE: docs/casper/cbc-evidence/scripts-casper-soak-src-models-rs.md
# CbC Evidence: scripts/casper-soak/src/models.rs

The user accepted the bounded H01–H10 binding review. This record discharges only CLAIM-CASPER-SOAK-001 in the pre-merge phase.

Profile verification, node soaks, post-merge work, and inherited containment limits remain separate. Earlier ledger bytes remain in the linked archive.

```json
{
  "artifact": {
    "path": "scripts/casper-soak/src/models.rs",
    "id": "scripts-casper-soak-src-models-rs",
    "commit": "946743a7740e5dd3c0816263c3347e501f2d50d7",
    "sha256": "99e3f736aa9e753b73edced77049ab206f993d612870bb1d866f6d5c0655983f",
    "commit_is_base": false
  },
  "claim": "docs/claims/casper-soak-harness.md",
  "claim_ids": [
    "CLAIM-CASPER-SOAK-001"
  ],
  "claim_digests": {
    "docs/claims/casper-soak-harness.md": "c711fdc42bfed34ce28a6cd5da407e27d2e4745037b0eb250d8e760bee24a071"
  },
  "adapter": "embedded",
  "status": "discharged",
  "scope": "bounded-harness-only",
  "evidence": {
    "kind": "accepted-bounded-refutation-and-binding",
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/report.json",
    "sha256": "c510e4e393daf52f5a3d2e3affa908897ab0a574484de807939354d5ad8c5ec1"
  },
  "previous_ledger": {
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/prior-ledgers.tar.gz",
    "sha256": "4869ed3996b96dda70f84cc666ceb6f86d529f982f8c847b260287738d333e52",
    "member": "docs/casper/cbc-evidence/scripts-casper-soak-src-models-rs.md"
  },
  "tiers": {
    "refutation": "bounded-safety-pass",
    "construction": "not-applicable",
    "binding": "passed"
  },
  "phase_status": {
    "pre_pr216_merge": "discharged",
    "post_pr216_merge": "blocked"
  },
  "soak": "pending",
  "waiver": null,
  "verified_at": "2026-09-18T04:31:12Z"
}
```

FILE: docs/casper/cbc-evidence/scripts-casper-soak-src-runtime-rs.md
# CbC Evidence: scripts/casper-soak/src/runtime.rs

The user accepted the bounded H01–H10 binding review. This record discharges only CLAIM-CASPER-SOAK-001 in the pre-merge phase.

Profile verification, node soaks, post-merge work, and inherited containment limits remain separate. Earlier ledger bytes remain in the linked archive.

```json
{
  "artifact": {
    "path": "scripts/casper-soak/src/runtime.rs",
    "id": "scripts-casper-soak-src-runtime-rs",
    "commit": "946743a7740e5dd3c0816263c3347e501f2d50d7",
    "sha256": "e54942a4557a0f9eb03509a92921a017c7143b3da2942c10d4931bbfe6ec761a",
    "commit_is_base": false
  },
  "claim": "docs/claims/casper-soak-harness.md",
  "claim_ids": [
    "CLAIM-CASPER-SOAK-001"
  ],
  "claim_digests": {
    "docs/claims/casper-soak-harness.md": "c711fdc42bfed34ce28a6cd5da407e27d2e4745037b0eb250d8e760bee24a071"
  },
  "adapter": "embedded",
  "status": "discharged",
  "scope": "bounded-harness-only",
  "evidence": {
    "kind": "accepted-bounded-refutation-and-binding",
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/report.json",
    "sha256": "c510e4e393daf52f5a3d2e3affa908897ab0a574484de807939354d5ad8c5ec1"
  },
  "previous_ledger": {
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/prior-ledgers.tar.gz",
    "sha256": "4869ed3996b96dda70f84cc666ceb6f86d529f982f8c847b260287738d333e52",
    "member": "docs/casper/cbc-evidence/scripts-casper-soak-src-runtime-rs.md"
  },
  "tiers": {
    "refutation": "bounded-safety-pass",
    "construction": "not-applicable",
    "binding": "passed"
  },
  "phase_status": {
    "pre_pr216_merge": "discharged",
    "post_pr216_merge": "blocked"
  },
  "soak": "pending",
  "waiver": null,
  "verified_at": "2026-09-18T04:31:12Z"
}
```

FILE: docs/casper/cbc-evidence/scripts-casper-soak-task-complete-sh.md
# CbC Evidence: scripts/casper-soak/task-complete.sh

The user accepted the bounded H01–H10 binding review. This record discharges only CLAIM-CASPER-SOAK-001 in the pre-merge phase.

Profile verification, node soaks, post-merge work, and inherited containment limits remain separate. Earlier ledger bytes remain in the linked archive.

```json
{
  "artifact": {
    "path": "scripts/casper-soak/task-complete.sh",
    "id": "scripts-casper-soak-task-complete-sh",
    "commit": "946743a7740e5dd3c0816263c3347e501f2d50d7",
    "sha256": "89245a31460c48bf066e58c1329538baa57791ced13a01c4761aa2c62afdb912",
    "commit_is_base": false
  },
  "claim": "docs/claims/casper-soak-harness.md",
  "claim_ids": [
    "CLAIM-CASPER-SOAK-001"
  ],
  "claim_digests": {
    "docs/claims/casper-soak-harness.md": "c711fdc42bfed34ce28a6cd5da407e27d2e4745037b0eb250d8e760bee24a071"
  },
  "adapter": "embedded",
  "status": "discharged",
  "scope": "bounded-harness-only",
  "evidence": {
    "kind": "accepted-bounded-refutation-and-binding",
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/report.json",
    "sha256": "c510e4e393daf52f5a3d2e3affa908897ab0a574484de807939354d5ad8c5ec1"
  },
  "previous_ledger": {
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/prior-ledgers.tar.gz",
    "sha256": "4869ed3996b96dda70f84cc666ceb6f86d529f982f8c847b260287738d333e52",
    "member": "docs/casper/cbc-evidence/scripts-casper-soak-task-complete-sh.md"
  },
  "tiers": {
    "refutation": "bounded-safety-pass",
    "construction": "not-applicable",
    "binding": "passed"
  },
  "phase_status": {
    "pre_pr216_merge": "discharged",
    "post_pr216_merge": "blocked"
  },
  "soak": "pending",
  "waiver": null,
  "verified_at": "2026-09-18T04:31:12Z"
}
```

FILE: docs/casper/cbc-evidence/scripts-casper-soak-tests-bindings-rs.md
# CbC Evidence: scripts/casper-soak/tests/bindings.rs

The user accepted the bounded H01–H10 binding review. This record discharges only CLAIM-CASPER-SOAK-001 in the pre-merge phase.

Profile verification, node soaks, post-merge work, and inherited containment limits remain separate. Earlier ledger bytes remain in the linked archive.

```json
{
  "artifact": {
    "path": "scripts/casper-soak/tests/bindings.rs",
    "id": "scripts-casper-soak-tests-bindings-rs",
    "commit": "946743a7740e5dd3c0816263c3347e501f2d50d7",
    "sha256": "c2d593f6c6a9ddb5c9f5aa769d6f8b884256a5cecef4fc30afdec3bb0c50eab5",
    "commit_is_base": false
  },
  "claim": "docs/claims/casper-soak-harness.md",
  "claim_ids": [
    "CLAIM-CASPER-SOAK-001"
  ],
  "claim_digests": {
    "docs/claims/casper-soak-harness.md": "c711fdc42bfed34ce28a6cd5da407e27d2e4745037b0eb250d8e760bee24a071"
  },
  "adapter": "embedded",
  "status": "discharged",
  "scope": "bounded-harness-only",
  "evidence": {
    "kind": "accepted-bounded-refutation-and-binding",
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/report.json",
    "sha256": "c510e4e393daf52f5a3d2e3affa908897ab0a574484de807939354d5ad8c5ec1"
  },
  "previous_ledger": {
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/prior-ledgers.tar.gz",
    "sha256": "4869ed3996b96dda70f84cc666ceb6f86d529f982f8c847b260287738d333e52",
    "member": "docs/casper/cbc-evidence/scripts-casper-soak-tests-bindings-rs.md"
  },
  "tiers": {
    "refutation": "bounded-safety-pass",
    "construction": "not-applicable",
    "binding": "passed"
  },
  "phase_status": {
    "pre_pr216_merge": "discharged",
    "post_pr216_merge": "blocked"
  },
  "soak": "pending",
  "waiver": null,
  "verified_at": "2026-09-18T04:31:12Z"
}
```

FILE: docs/casper/cbc-evidence/scripts-casper-soak-tests-claims-rs.md
# CbC Evidence: scripts/casper-soak/tests/claims.rs

The user accepted the bounded H01–H10 binding review. This record discharges only CLAIM-CASPER-SOAK-001 in the pre-merge phase.

Profile verification, node soaks, post-merge work, and inherited containment limits remain separate. Earlier ledger bytes remain in the linked archive.

```json
{
  "artifact": {
    "path": "scripts/casper-soak/tests/claims.rs",
    "id": "scripts-casper-soak-tests-claims-rs",
    "commit": "946743a7740e5dd3c0816263c3347e501f2d50d7",
    "sha256": "8813eba982f56f4fd45e339e61f5ee4b70c29e67bc28b1b2e85c0633b5eeb7d2",
    "commit_is_base": false
  },
  "claim": "docs/claims/casper-soak-harness.md",
  "claim_ids": [
    "CLAIM-CASPER-SOAK-001"
  ],
  "claim_digests": {
    "docs/claims/casper-soak-harness.md": "c711fdc42bfed34ce28a6cd5da407e27d2e4745037b0eb250d8e760bee24a071"
  },
  "adapter": "embedded",
  "status": "discharged",
  "scope": "bounded-harness-only",
  "evidence": {
    "kind": "accepted-bounded-refutation-and-binding",
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/report.json",
    "sha256": "c510e4e393daf52f5a3d2e3affa908897ab0a574484de807939354d5ad8c5ec1"
  },
  "previous_ledger": {
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/prior-ledgers.tar.gz",
    "sha256": "4869ed3996b96dda70f84cc666ceb6f86d529f982f8c847b260287738d333e52",
    "member": "docs/casper/cbc-evidence/scripts-casper-soak-tests-claims-rs.md"
  },
  "tiers": {
    "refutation": "bounded-safety-pass",
    "construction": "not-applicable",
    "binding": "passed"
  },
  "phase_status": {
    "pre_pr216_merge": "discharged",
    "post_pr216_merge": "blocked"
  },
  "soak": "pending",
  "waiver": null,
  "verified_at": "2026-09-18T04:31:12Z"
}
```

FILE: docs/casper/cbc-evidence/scripts-casper-soak-tests-driver-rs.md
# CbC Evidence: scripts/casper-soak/tests/driver.rs

The user accepted the bounded H01–H10 binding review. This record discharges only CLAIM-CASPER-SOAK-001 in the pre-merge phase.

Profile verification, node soaks, post-merge work, and inherited containment limits remain separate. Earlier ledger bytes remain in the linked archive.

```json
{
  "artifact": {
    "path": "scripts/casper-soak/tests/driver.rs",
    "id": "scripts-casper-soak-tests-driver-rs",
    "commit": "946743a7740e5dd3c0816263c3347e501f2d50d7",
    "sha256": "8e4bc9c2b58f0613a164b48caeb1dd74c1d6c480d58af5c5dfaf3fe426c73fa5",
    "commit_is_base": false
  },
  "claim": "docs/claims/casper-soak-harness.md",
  "claim_ids": [
    "CLAIM-CASPER-SOAK-001"
  ],
  "claim_digests": {
    "docs/claims/casper-soak-harness.md": "c711fdc42bfed34ce28a6cd5da407e27d2e4745037b0eb250d8e760bee24a071"
  },
  "adapter": "embedded",
  "status": "discharged",
  "scope": "bounded-harness-only",
  "evidence": {
    "kind": "accepted-bounded-refutation-and-binding",
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/report.json",
    "sha256": "c510e4e393daf52f5a3d2e3affa908897ab0a574484de807939354d5ad8c5ec1"
  },
  "previous_ledger": {
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/prior-ledgers.tar.gz",
    "sha256": "4869ed3996b96dda70f84cc666ceb6f86d529f982f8c847b260287738d333e52",
    "member": "docs/casper/cbc-evidence/scripts-casper-soak-tests-driver-rs.md"
  },
  "tiers": {
    "refutation": "bounded-safety-pass",
    "construction": "not-applicable",
    "binding": "passed"
  },
  "phase_status": {
    "pre_pr216_merge": "discharged",
    "post_pr216_merge": "blocked"
  },
  "soak": "pending",
  "waiver": null,
  "verified_at": "2026-09-18T04:31:12Z"
}
```

FILE: docs/casper/cbc-evidence/scripts-casper-soak-tests-interruption-rs.md
# CbC Evidence: scripts/casper-soak/tests/interruption.rs

The user accepted the bounded H01–H10 binding review. This record discharges only CLAIM-CASPER-SOAK-001 in the pre-merge phase.

Profile verification, node soaks, post-merge work, and inherited containment limits remain separate. Earlier ledger bytes remain in the linked archive.

```json
{
  "artifact": {
    "path": "scripts/casper-soak/tests/interruption.rs",
    "id": "scripts-casper-soak-tests-interruption-rs",
    "commit": "946743a7740e5dd3c0816263c3347e501f2d50d7",
    "sha256": "222e7f8ace6a4c70d207130590d6cecab54140117bda36671ea558b25273963d",
    "commit_is_base": false
  },
  "claim": "docs/claims/casper-soak-harness.md",
  "claim_ids": [
    "CLAIM-CASPER-SOAK-001"
  ],
  "claim_digests": {
    "docs/claims/casper-soak-harness.md": "c711fdc42bfed34ce28a6cd5da407e27d2e4745037b0eb250d8e760bee24a071"
  },
  "adapter": "embedded",
  "status": "discharged",
  "scope": "bounded-harness-only",
  "evidence": {
    "kind": "accepted-bounded-refutation-and-binding",
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/report.json",
    "sha256": "c510e4e393daf52f5a3d2e3affa908897ab0a574484de807939354d5ad8c5ec1"
  },
  "previous_ledger": {
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/prior-ledgers.tar.gz",
    "sha256": "4869ed3996b96dda70f84cc666ceb6f86d529f982f8c847b260287738d333e52",
    "member": "docs/casper/cbc-evidence/scripts-casper-soak-tests-interruption-rs.md"
  },
  "tiers": {
    "refutation": "bounded-safety-pass",
    "construction": "not-applicable",
    "binding": "passed"
  },
  "phase_status": {
    "pre_pr216_merge": "discharged",
    "post_pr216_merge": "blocked"
  },
  "soak": "pending",
  "waiver": null,
  "verified_at": "2026-09-18T04:31:12Z"
}
```

FILE: docs/casper/cbc-evidence/scripts-casper-soak-tests-manifest-rs.md
# CbC Evidence: scripts/casper-soak/tests/manifest.rs

The user accepted the bounded H01–H10 binding review. This record discharges only CLAIM-CASPER-SOAK-001 in the pre-merge phase.

Profile verification, node soaks, post-merge work, and inherited containment limits remain separate. Earlier ledger bytes remain in the linked archive.

```json
{
  "artifact": {
    "path": "scripts/casper-soak/tests/manifest.rs",
    "id": "scripts-casper-soak-tests-manifest-rs",
    "commit": "946743a7740e5dd3c0816263c3347e501f2d50d7",
    "sha256": "0a7d2add0978931c2656cb667690f5d959487c4f2afbe3f0545ee00021b575b0",
    "commit_is_base": false
  },
  "claim": "docs/claims/casper-soak-harness.md",
  "claim_ids": [
    "CLAIM-CASPER-SOAK-001"
  ],
  "claim_digests": {
    "docs/claims/casper-soak-harness.md": "c711fdc42bfed34ce28a6cd5da407e27d2e4745037b0eb250d8e760bee24a071"
  },
  "adapter": "embedded",
  "status": "discharged",
  "scope": "bounded-harness-only",
  "evidence": {
    "kind": "accepted-bounded-refutation-and-binding",
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/report.json",
    "sha256": "c510e4e393daf52f5a3d2e3affa908897ab0a574484de807939354d5ad8c5ec1"
  },
  "previous_ledger": {
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/prior-ledgers.tar.gz",
    "sha256": "4869ed3996b96dda70f84cc666ceb6f86d529f982f8c847b260287738d333e52",
    "member": "docs/casper/cbc-evidence/scripts-casper-soak-tests-manifest-rs.md"
  },
  "tiers": {
    "refutation": "bounded-safety-pass",
    "construction": "not-applicable",
    "binding": "passed"
  },
  "phase_status": {
    "pre_pr216_merge": "discharged",
    "post_pr216_merge": "blocked"
  },
  "soak": "pending",
  "waiver": null,
  "verified_at": "2026-09-18T04:31:12Z"
}
```

FILE: docs/casper/cbc-evidence/scripts-casper-soak-tests-models-rs.md
# CbC Evidence: scripts/casper-soak/tests/models.rs

The user accepted the bounded H01–H10 binding review. This record discharges only CLAIM-CASPER-SOAK-001 in the pre-merge phase.

Profile verification, node soaks, post-merge work, and inherited containment limits remain separate. Earlier ledger bytes remain in the linked archive.

```json
{
  "artifact": {
    "path": "scripts/casper-soak/tests/models.rs",
    "id": "scripts-casper-soak-tests-models-rs",
    "commit": "946743a7740e5dd3c0816263c3347e501f2d50d7",
    "sha256": "b495e3705c1d38f3c74cea761e69b4f462d32c4fe62921e43e76f461faa36e60",
    "commit_is_base": false
  },
  "claim": "docs/claims/casper-soak-harness.md",
  "claim_ids": [
    "CLAIM-CASPER-SOAK-001"
  ],
  "claim_digests": {
    "docs/claims/casper-soak-harness.md": "c711fdc42bfed34ce28a6cd5da407e27d2e4745037b0eb250d8e760bee24a071"
  },
  "adapter": "embedded",
  "status": "discharged",
  "scope": "bounded-harness-only",
  "evidence": {
    "kind": "accepted-bounded-refutation-and-binding",
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/report.json",
    "sha256": "c510e4e393daf52f5a3d2e3affa908897ab0a574484de807939354d5ad8c5ec1"
  },
  "previous_ledger": {
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/prior-ledgers.tar.gz",
    "sha256": "4869ed3996b96dda70f84cc666ceb6f86d529f982f8c847b260287738d333e52",
    "member": "docs/casper/cbc-evidence/scripts-casper-soak-tests-models-rs.md"
  },
  "tiers": {
    "refutation": "bounded-safety-pass",
    "construction": "not-applicable",
    "binding": "passed"
  },
  "phase_status": {
    "pre_pr216_merge": "discharged",
    "post_pr216_merge": "blocked"
  },
  "soak": "pending",
  "waiver": null,
  "verified_at": "2026-09-18T04:31:12Z"
}
```

FILE: docs/casper/cbc-evidence/scripts-ci-check-casper-soak-bindings-sh.md
# CbC Evidence: scripts/ci/check-casper-soak-bindings.sh

The user accepted the bounded H01–H10 binding review. This record discharges only CLAIM-CASPER-SOAK-001 in the pre-merge phase.

Profile verification, node soaks, post-merge work, and inherited containment limits remain separate. Earlier ledger bytes remain in the linked archive.

```json
{
  "artifact": {
    "path": "scripts/ci/check-casper-soak-bindings.sh",
    "id": "scripts-ci-check-casper-soak-bindings-sh",
    "commit": "946743a7740e5dd3c0816263c3347e501f2d50d7",
    "sha256": "ead062ae9ce443ea503052b466c49d5706b243638dc77c6eca7590a1fba37137",
    "commit_is_base": true
  },
  "claim": "docs/claims/casper-soak-harness.md",
  "claim_ids": [
    "CLAIM-CASPER-SOAK-001"
  ],
  "claim_digests": {
    "docs/claims/casper-soak-harness.md": "c711fdc42bfed34ce28a6cd5da407e27d2e4745037b0eb250d8e760bee24a071"
  },
  "adapter": "embedded",
  "status": "discharged",
  "scope": "bounded-harness-only",
  "evidence": {
    "kind": "accepted-bounded-refutation-and-binding",
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/report.json",
    "sha256": "c510e4e393daf52f5a3d2e3affa908897ab0a574484de807939354d5ad8c5ec1"
  },
  "previous_ledger": {
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/prior-ledgers.tar.gz",
    "sha256": "4869ed3996b96dda70f84cc666ceb6f86d529f982f8c847b260287738d333e52",
    "member": "docs/casper/cbc-evidence/scripts-ci-check-casper-soak-bindings-sh.md"
  },
  "tiers": {
    "refutation": "bounded-safety-pass",
    "construction": "not-applicable",
    "binding": "passed"
  },
  "phase_status": {
    "pre_pr216_merge": "discharged",
    "post_pr216_merge": "blocked"
  },
  "soak": "pending",
  "waiver": null,
  "verified_at": "2026-09-18T04:31:12Z"
}
```

FILE: docs/casper/cbc-evidence/scripts-ci-check-casper-soak-models-sh.md
# CbC Evidence: scripts/ci/check-casper-soak-models.sh

The user accepted the bounded H01–H10 binding review. This record discharges only CLAIM-CASPER-SOAK-001 in the pre-merge phase.

Profile verification, node soaks, post-merge work, and inherited containment limits remain separate. Earlier ledger bytes remain in the linked archive.

```json
{
  "artifact": {
    "path": "scripts/ci/check-casper-soak-models.sh",
    "id": "scripts-ci-check-casper-soak-models-sh",
    "commit": "946743a7740e5dd3c0816263c3347e501f2d50d7",
    "sha256": "2fdebbbd283fa26cb6a69f90ad651971db1d3f6c694ef39b9c21ab476e2c5342",
    "commit_is_base": false
  },
  "claim": "docs/claims/casper-soak-harness.md",
  "claim_ids": [
    "CLAIM-CASPER-SOAK-001"
  ],
  "claim_digests": {
    "docs/claims/casper-soak-harness.md": "c711fdc42bfed34ce28a6cd5da407e27d2e4745037b0eb250d8e760bee24a071"
  },
  "adapter": "embedded",
  "status": "discharged",
  "scope": "bounded-harness-only",
  "evidence": {
    "kind": "accepted-bounded-refutation-and-binding",
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/report.json",
    "sha256": "c510e4e393daf52f5a3d2e3affa908897ab0a574484de807939354d5ad8c5ec1"
  },
  "previous_ledger": {
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/prior-ledgers.tar.gz",
    "sha256": "4869ed3996b96dda70f84cc666ceb6f86d529f982f8c847b260287738d333e52",
    "member": "docs/casper/cbc-evidence/scripts-ci-check-casper-soak-models-sh.md"
  },
  "tiers": {
    "refutation": "bounded-safety-pass",
    "construction": "not-applicable",
    "binding": "passed"
  },
  "phase_status": {
    "pre_pr216_merge": "discharged",
    "post_pr216_merge": "blocked"
  },
  "soak": "pending",
  "waiver": null,
  "verified_at": "2026-09-18T04:31:12Z"
}
```

FILE: docs/casper/cbc-evidence/scripts-ci-check-tla-invariants-sh.md
# CbC Evidence: scripts/ci/check-tla-invariants.sh

The user accepted the bounded H01–H10 binding review. This record discharges only CLAIM-CASPER-SOAK-001 in the pre-merge phase.

Profile verification, node soaks, post-merge work, and inherited containment limits remain separate. Earlier ledger bytes remain in the linked archive.

```json
{
  "artifact": {
    "path": "scripts/ci/check-tla-invariants.sh",
    "id": "scripts-ci-check-tla-invariants-sh",
    "commit": "946743a7740e5dd3c0816263c3347e501f2d50d7",
    "sha256": "41849481aeafbf7b98ec690fc44d209139c8b1749cd99e8de43ebb5ffc876baf",
    "commit_is_base": false
  },
  "claim": "docs/claims/casper-soak-harness.md",
  "claim_ids": [
    "CLAIM-CASPER-SOAK-001"
  ],
  "claim_digests": {
    "docs/claims/casper-soak-harness.md": "c711fdc42bfed34ce28a6cd5da407e27d2e4745037b0eb250d8e760bee24a071"
  },
  "adapter": "embedded",
  "status": "discharged",
  "scope": "bounded-harness-only",
  "evidence": {
    "kind": "accepted-bounded-refutation-and-binding",
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/report.json",
    "sha256": "c510e4e393daf52f5a3d2e3affa908897ab0a574484de807939354d5ad8c5ec1"
  },
  "previous_ledger": null,
  "tiers": {
    "refutation": "bounded-safety-pass",
    "construction": "not-applicable",
    "binding": "passed"
  },
  "phase_status": {
    "pre_pr216_merge": "discharged",
    "post_pr216_merge": "blocked"
  },
  "soak": "pending",
  "waiver": null,
  "verified_at": "2026-09-18T04:31:12Z"
}
```

FILE: docs/casper/cbc-evidence/scripts-run-merge-recovery-soak-sh.md
# CbC Evidence: scripts/run-merge-recovery-soak.sh

The user accepted the bounded H01–H10 binding review. This record discharges only CLAIM-CASPER-SOAK-001 in the pre-merge phase.

Profile verification, node soaks, post-merge work, and inherited containment limits remain separate. Earlier ledger bytes remain in the linked archive.

```json
{
  "artifact": {
    "path": "scripts/run-merge-recovery-soak.sh",
    "id": "scripts-run-merge-recovery-soak-sh",
    "commit": "946743a7740e5dd3c0816263c3347e501f2d50d7",
    "sha256": "7f4ba9b1c9078c984251317a4cb5032772a092645bfb83d07f6950c0b43542b2",
    "commit_is_base": false
  },
  "claim": "docs/claims/casper-soak-harness.md",
  "claim_ids": [
    "CLAIM-CASPER-SOAK-001"
  ],
  "claim_digests": {
    "docs/claims/casper-soak-harness.md": "c711fdc42bfed34ce28a6cd5da407e27d2e4745037b0eb250d8e760bee24a071"
  },
  "adapter": "embedded",
  "status": "discharged",
  "scope": "bounded-harness-only",
  "evidence": {
    "kind": "accepted-bounded-refutation-and-binding",
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/report.json",
    "sha256": "c510e4e393daf52f5a3d2e3affa908897ab0a574484de807939354d5ad8c5ec1"
  },
  "previous_ledger": {
    "ref": "docs/casper/cbc-evidence/runs/casper-task-017-4-acceptance-01/prior-ledgers.tar.gz",
    "sha256": "4869ed3996b96dda70f84cc666ceb6f86d529f982f8c847b260287738d333e52",
    "member": "docs/casper/cbc-evidence/scripts-run-merge-recovery-soak-sh.md"
  },
  "tiers": {
    "refutation": "bounded-safety-pass",
    "construction": "not-applicable",
    "binding": "passed"
  },
  "phase_status": {
    "pre_pr216_merge": "discharged",
    "post_pr216_merge": "blocked"
  },
  "soak": "pending",
  "waiver": null,
  "verified_at": "2026-09-18T04:31:12Z"
}
```
