use std::{fs, process::Command, thread, time::Duration};
fn main() {
    assert!(std::path::Path::new("/.dockerenv").is_file());
    let marker = "SOAK_PROCESS_OWNER=startup-fixture";
    let mut missing = 0;
    let mut subsequently_visible = 0;
    for _ in 0..1000 {
        let mut child = Command::new("sleep").arg("60").env("SOAK_PROCESS_OWNER", "startup-fixture").spawn().unwrap();
        let path = format!("/proc/{}/environ", child.id());
        let before = fs::read(&path).unwrap();
        if !before.split(|v| *v == 0).any(|v| v == marker.as_bytes()) {
            missing += 1;
            thread::sleep(Duration::from_millis(5));
            let after = fs::read(&path).unwrap();
            if after.split(|v| *v == 0).any(|v| v == marker.as_bytes()) { subsequently_visible += 1; }
        }
        child.kill().unwrap(); child.wait().unwrap();
    }
    println!("samples=1000 missing_immediately={missing} visible_after_delay={subsequently_visible}");
}
