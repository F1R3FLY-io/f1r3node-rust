#!/usr/bin/env bash
set -euo pipefail
OUT=target/casper-driver-acceptance/host-repeat
mkdir "$OUT"
TEST="$(jq -rs '[.[] | select(.reason=="compiler-artifact" and .target.name=="casper-soak" and .profile.test==true and .executable!=null) | .executable] | last' target/casper-driver-acceptance/host-build.jsonl)"
shasum -a 256 "$TEST" scripts/casper-soak/src/host_control.rs >"$OUT/inputs.sha256"
for uid in 65534 0; do
 repeats=50
 extra=''
 if [[ "$uid" == 0 ]]; then repeats=1; extra=--include-ignored; fi
 C="$(docker create --pull=never --network none --cap-drop ALL --security-opt no-new-privileges --pids-limit 128 --memory 256m --cpus 1 --user "$uid:$uid" --env "REPEATS=$repeats" --env "EXTRA=$extra" --entrypoint timeout sha256:7d402dd7f1922bcdbdbeb90d14cecf398fdd36bc5105242fa4a4dc1d1cd596c5 --kill-after=5 90 bash -euc 'for ((i=1;i<=REPEATS;i++)); do echo "iteration=$i"; /case/test --test-threads=1 $EXTRA; done')"
 docker inspect "$C" >"$OUT/$uid-container.json"
 docker cp "$TEST" "$C:/case/test" >/dev/null
 status=0
 timeout --kill-after=5 100 docker start -a "$C" >"$OUT/$uid-tests.txt" 2>&1 || status=$?
 printf '%s\n' "$status" >"$OUT/$uid.exit"
 docker inspect "$C" >"$OUT/$uid-finished.json"
 docker rm -f "$C" >"$OUT/$uid-cleanup.txt"
 [[ "$status" == 0 ]]
done
shasum -a 256 -c "$OUT/inputs.sha256" >"$OUT/input-check.txt"
